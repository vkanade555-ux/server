#!/usr/bin/env python3
# ============================================================
#  एक जोडी तपासणी — "त्या मेणबत्तीत setup होता का? alert का आला नाही?"
# ============================================================
#  हे साधन फक्त *वाचते*. चालू स्कॅनरला हात लागत नाही, कुठेही लिहित नाही,
#  alert मोजणी बदलत नाही. नियम तपासण्यासाठी स्कॅनरचेच functions वापरतो —
#  म्हणजे निकाल तंतोतंत तोच येतो.
#
#  वापर :
#     python3 ek_jodi_tapas.py AUDUSD 1h          # शेवटच्या 6 मेणबत्त्या
#     python3 ek_jodi_tapas.py GBPAUD 30m 10      # 10 मेणबत्त्या
#     python3 ek_jodi_tapas.py AUDUSD 1h 24
#     python3 ek_jodi_tapas.py --demo             # चाचणी (internet नाही)
#
#  आकार : 10m · 30m · 1h · 2h · 4h · 8h
# ============================================================

import os
import sys
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, "/home/ubuntu/trading-bot-forex", os.getcwd()):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)

MODULE_NAMES = ("forex_scanner", "forex_scanner_v7", "forex_scanner_biquote")

# भारतीय वेळा दाखवायला (स्कॅनरचीच वेळ मिळाली तर तीच वापरतो)
IST_TZ = timezone(timedelta(hours=5, minutes=30))
TIMFRAMES = ("10m", "30m", "1h", "2h", "4h", "8h")

REQUIRED = (
    "TIMEFRAMES", "final_minutes", "aggregate_candles", "scanner_result",
    "momentum_ok", "momentum_sticks", "momentum_ratio", "close_position",
    "candle_body_ratio", "biquote_candles", "now_ms", "KLINE_LIMIT",
)


def load_scanner():
    """योग्य स्कॅनर फाइल शोधतो — v7 नियमांची functions असलेलीच घेतो."""

    problems = []

    for name in MODULE_NAMES:
        try:
            module = __import__(name)
        except Exception as e:
            problems.append(f"{name}: {type(e).__name__} {e}")
            continue

        missing = [a for a in REQUIRED if not hasattr(module, a)]

        if missing:
            problems.append(f"{name}: जुनी फाइल ({', '.join(missing[:3])} नाही)")
            continue

        global IST_TZ
        IST_TZ = getattr(module, "IST", None) or IST_TZ

        return module

    print("❌ v7 नियमांची स्कॅनर फाइल सापडली नाही.")
    print("   हे सादन ~/trading-bot-forex मध्ये ठेवा आणि तिथूनच चालवा :")
    print("     cd ~/trading-bot-forex && python3 ek_jodi_tapas.py AUDUSD 1h")
    for p in problems:
        print(f"   · {p}")
    sys.exit(2)


def fmt(ms):
    return datetime.fromtimestamp(ms / 1000, IST_TZ).strftime("%d-%m-%Y %H:%M")


def hm(ms):
    return datetime.fromtimestamp(ms / 1000, IST_TZ).strftime("%H:%M")


def num(x):
    return f"{x:.5f}"


def pts(x):
    return f"{abs(x):.5f}"


def breakdown(fx, first, second, final_candle, previous):
    """प्रत्येक Scanner च्या अटी — कोणती पास, कोणती फेल (फक्त समजण्यासाठी)."""

    body_min = getattr(fx, "BODY_THRESHOLD", 0.50)
    lo_max = getattr(fx, "CLOSE_LOW_THRESHOLD", 0.50)
    hi_min = getattr(fx, "CLOSE_HIGH_THRESHOLD", 0.50)
    mult = getattr(fx, "MOMENTUM_MULTIPLIER", 3.0)

    c1g = first["close"] > first["open"]
    c1r = first["close"] < first["open"]
    c2g = second["close"] > second["open"]
    c2r = second["close"] < second["open"]

    body1 = fx.candle_body_ratio(first)
    body1_ok = body1 >= body_min
    pos = fx.close_position(final_candle)

    s1, s2 = fx.momentum_sticks(previous, first, second)
    ratio = fx.momentum_ratio(previous, first, second)

    mom_opp = (s1 > 0) != (s2 > 0)
    mom_size = ratio is not None and ratio >= mult
    mom_ok = bool(fx.momentum_ok(previous, first, second))

    checks = {
        "Scanner 1": [
            ("1ली हिरवी", c1g),
            (f"1लीचा body ≥ {body_min:.0%}", body1_ok),
            ("2री लाल", c2r),
            ("2रीचा high 1लीपेक्षा खाली", second["high"] < first["high"]),
            ("2रीचा low 1लीपेक्षा वर", second["low"] > first["low"]),
            (f"एकत्र close खालच्या {lo_max:.0%} भागात", pos is not None and pos <= lo_max),
            (f"खांब {mult:.1f}× + उलट दिशा", mom_ok),
        ],
        "Scanner 2": [
            ("1ली लाल", c1r),
            (f"1लीचा body ≥ {body_min:.0%}", body1_ok),
            ("2री हिरवी", c2g),
            ("2रीचा high 1लीपेक्षा खाली", second["high"] < first["high"]),
            ("2रीचा low 1लीपेक्षा वर", second["low"] > first["low"]),
            (f"एकत्र close वरच्या {1 - hi_min:.0%} भागात", pos is not None and pos >= hi_min),
            (f"खांब {mult:.1f}× + उलट दिशा", mom_ok),
        ],
        "Scanner 3": [
            ("1ली हिरवी", c1g),
            (f"1लीचा body ≥ {body_min:.0%}", body1_ok),
            ("2री लाल", c2r),
            ("2रीचा high 1लीपेक्षा वर (तोड)", second["high"] > first["high"]),
            ("2रीचा low 1लीपेक्षा वर", second["low"] > first["low"]),
            (f"एकत्र close खालच्या {lo_max:.0%} भागात", pos is not None and pos <= lo_max),
            (f"खांब {mult:.1f}× + उलट दिशा", mom_ok),
        ],
        "Scanner 4": [
            ("1ली लाल", c1r),
            (f"1लीचा body ≥ {body_min:.0%}", body1_ok),
            ("2री हिरवी", c2g),
            ("2रीचा low 1लीपेक्षा खाली (तोड)", second["low"] < first["low"]),
            ("2रीचा high 1लीपेक्षा खाली", second["high"] < first["high"]),
            (f"एकत्र close वरच्या {1 - hi_min:.0%} भागात", pos is not None and pos >= hi_min),
            (f"खांब {mult:.1f}× + उलट दिशा", mom_ok),
        ],
    }

    return {
        "checks": checks,
        "body1": body1,
        "pos": pos,
        "s1": s1,
        "s2": s2,
        "ratio": ratio,
        "mom_opp": mom_opp,
        "mom_size": mom_size,
        "c1": "हिरवी" if c1g else ("लाल" if c1r else "सपाट"),
        "c2": "हिरवी" if c2g else ("लाल" if c2r else "सपाट"),
    }


def analyse(fx, base_candles, timeframe, count):
    """शेवटच्या 'count' पूर्ण झालेल्या मेणबत्त्या तपासतो."""

    comp_min = fx.TIMEFRAMES[timeframe]
    fin_min = fx.final_minutes(timeframe)
    comp_ms = comp_min * 60 * 1000
    fin_ms = fin_min * 60 * 1000

    comps = fx.aggregate_candles(base_candles, comp_min)
    finals = fx.aggregate_candles(base_candles, fin_min)

    now = fx.now_ms()
    closed = [c for c in finals if c["open_time"] + fin_ms <= now]
    closed = closed[-count:]

    out = []

    for fc in closed:

        rec = {
            "start": fc["open_time"],
            "end": fc["open_time"] + fin_ms,
            "final": fc,
            "verdict": None,
            "note": None,
        }

        parts = [c for c in comps if rec["start"] <= c["open_time"] < rec["end"]]
        parts.sort(key=lambda x: x["open_time"])

        if len(parts) != 2:
            rec["note"] = f"घटक मेणबत्त्या {len(parts)} — डेटा अपूर्ण"
            out.append(rec)
            continue

        first, second = parts

        previous = None
        for c in comps:
            if c["open_time"] == first["open_time"] - comp_ms:
                previous = c
                break

        rec["first"] = first
        rec["second"] = second
        rec["previous"] = previous
        rec["info"] = breakdown(fx, first, second, fc, previous)
        rec["verdict"] = fx.scanner_result(first, second, fc, previous)

        if rec["verdict"]:

            bearish = "Bearish" in rec["verdict"]["direction"]
            rec["bearish"] = bearish
            rec["level"] = second["low"] if bearish else second["high"]
            rec["window"] = (rec["end"], rec["end"] + comp_ms)

            nxt = None
            for c in comps:
                if c["open_time"] == rec["end"]:
                    nxt = c
                    break

            rec["next"] = nxt

            if nxt is None:
                rec["touch"] = None
            elif bearish:
                rec["touch"] = nxt["low"] <= rec["level"]
                rec["nxt_extreme"] = nxt["low"]
            else:
                rec["touch"] = nxt["high"] >= rec["level"]
                rec["nxt_extreme"] = nxt["high"]

        out.append(rec)

    return out


def print_report(fx, symbol, timeframe, recs):

    comp_min = fx.TIMEFRAMES[timeframe]

    print()
    print(f"📊  {symbol} · {timeframe}   (biquote · v7 'stick' नियम)")
    print("=" * 60)

    setups = 0
    fired = 0

    for rec in recs:

        print()
        print(f"🕒 {fmt(rec['start'])}  →  {fmt(rec['end'])} IST")

        if rec["note"]:
            print(f"   ⚠️ {rec['note']}")
            continue

        fc = rec["final"]
        info = rec["info"]

        print(f"   एकत्र: उघड {num(fc['open'])} · उच्च {num(fc['high'])} · "
              f"नीच {num(fc['low'])} · बंद {num(fc['close'])}")
        print(f"   1ली {hm(rec['first']['open_time'])}–{hm(rec['second']['open_time'])}: "
              f"{info['c1']} · body {info['body1']:.0%}")
        print(f"   2री {hm(rec['second']['open_time'])}–{hm(rec['end'])}: "
              f"{info['c2']} · body {fx.candle_body_ratio(rec['second']):.0%}")
        print(f"   खांब: 1ला {info['s1']:+.5f} · 2रा {info['s2']:+.5f} "
              f"→ {('%.2f पट' % info['ratio']) if info['ratio'] is not None else '—'} "
              f"(उलट दिशा: {'हो' if info['mom_opp'] else 'नाही'})")

        if rec["verdict"]:

            setups += 1
            pos_pct = max(0.0, min(1.0, info["pos"])) * 100 if info["pos"] is not None else 0
            print(f"   एकत्र close ची जागा: {'खालच्या' if rec.get('bearish') else 'वरच्या'} "
                  f"टोकाकडे ({pos_pct:.0f}%)")
            print(f"   ✅ SETUP होता — {rec['verdict']['scanner']} ({rec['verdict']['direction']})")
            print(f"      हद्द (2रीचा {'low' if rec.get('bearish') else 'high'}) : {num(rec['level'])}")

            w0, w1 = rec["window"]
            print(f"      खिडकी ({comp_min} मिनिटांची) : {hm(w0)} → {hm(w1)} IST")

            if rec["touch"] is True:
                fired += 1
                print(f"      🔔 भाव त्या खिडकीत {num(rec['nxt_extreme'])} पर्यंत गेला — "
                      f"हद्द तोडली → alert जायचा ✅")
                print(f"         (मग Telegram आला नसेल तर alerts-file/Telegram बाजू तपासावी)")
            elif rec["touch"] is False:
                print(f"      ⛔ भाव खिडकीत फक्त {num(rec['nxt_extreme'])} पर्यंत आला — "
                      f"हद्द गाठली नाही")
                print(f"         म्हणून alert जायचा नाही — यंत्र नियमानुसार बरोबर ✅")
            else:
                print(f"      ⏳ खिडकीचा डेटा अजून नाही (खिडकी चालू किंवा डेटा अपूर्ण)")

        else:

            best, best_pass, best_fail = None, -1, []

            for name, items in info["checks"].items():
                passed = sum(1 for _, ok in items if ok)
                if passed > best_pass:
                    best, best_pass, best_fail = name, passed, [lab for lab, ok in items if not ok]

            print(f"   ❌ setup नाही")
            if best_fail:
                why = " · ".join(best_fail[:3])
                if len(best_fail) > 3:
                    why += f" · +{len(best_fail) - 3} अटी"
                print(f"      जवळचा: {best} ({best_pass}/7) — ✗ {why}")

    print()
    print("=" * 60)
    print(f"एकूण : {len(recs)} मेणबत्त्या · {setups} setup · {fired} वेळा हद्द तोडली (alert जायचा)")
    if setups and not fired:
        print("➡️  setup होता पण भाव हद्दीपर्यंत पोहोचला नाही = Telegram न येणे नियमानुसार बरोबर.")
    print("=" * 60)


# ============================================================
#  चाचणी (internet नाही) — बनावट मेणबत्त्यांवर नियम तपासतो
# ============================================================

def build_demo_base(start_ms, touch=True):
    """3 तासांचा 5m डेटा.

    तासाच्या ठोक्यावर आधारित 3 मेणबत्त्या (प्रत्येकी 2 × 30m घटक) :
      H0 = comp0 + comp1        -> setup नाही
      H1 = comp2 + comp3        -> ✅ Scanner 3 setup (खरा)
      H2 = comp4 + comp5        -> setup नाही (व खिडकीचा घटक comp4)
    H1 साठी 'previous' (m0) = comp1.
    """

    comps = [
        (1.00000, 1.00050, 0.99950, 0.99980),                          # comp0 (छोटी लाल)
        (1.00000, 1.00320, 0.99980, 1.00300),                          # comp1 = m0 (m0 = +0.0030)
        (1.00000, 1.00650, 0.99550, 1.00600),                          # comp2 = 1ली (m = +0.0060, body 55%)
        (1.00100, 1.00700, 0.99560, 0.99580),                          # comp3 = 2री (m = -0.0052, high तोड)
        (1.00000, 1.00100, 0.99600 if not touch else 0.99500, 0.99950),  # comp4 = खिडकीचा घटक
        (0.99700, 0.99900, 0.99650, 0.99800),                          # comp5
    ]

    for o, h, l, c in comps:
        assert l <= min(o, c) + 1e-12 and h >= max(o, c) - 1e-12, (o, h, l, c)

    base = []

    for ci, (o, h, l, c) in enumerate(comps):

        t0 = start_ms + ci * 6 * 300 * 1000

        for k in range(6):

            if k == 0:
                candle = (o, o, o, o)          # उघड
            elif k == 3:
                candle = (l, l, l, l)          # नीच
            elif k == 4:
                candle = (h, h, h, h)          # उच्च
            elif k == 5:
                candle = (c, c, c, c)          # बंद
            else:
                candle = (o, o, o, o)          # सपाट (काही बदल नाही)

            base.append({
                "open_time": t0 + k * 300 * 1000,
                "open": candle[0],
                "high": candle[1],
                "low": candle[2],
                "close": candle[3],
                "volume": 0,
            })

    return base


def demo():
    fx = load_scanner()
    START = 1759060800 * 1000        # 5m + 1h जाळीवर बसणारी वेळ
    now = START + 36 * 300 * 1000 + 60 * 1000

    ok_all = True

    for touch, want in ((True, True), (False, False)):

        base = build_demo_base(START, touch=touch)
        fx.biquote_candles = lambda *a, **k: base
        fx.now_ms = lambda: now

        recs = analyse(fx, base, "1h", 6)
        got = [r for r in recs if r["verdict"]]

        ok = (len(recs) == 3 and len(got) == 1
              and got[0]["verdict"]["scanner"] == "Scanner 3"
              and got[0]["start"] == START + 12 * 300 * 1000
              and got[0]["level"] == 0.9956
              and got[0]["touch"] is want)
        ok_all = ok_all and ok

        print(f"  {'✅' if ok else '❌'} हद्द तोडली={touch} → {len(got)} setup · "
              f"touch={got[0]['touch'] if got else '—'} · "
              f"level={got[0]['level'] if got else '—'}")

    print()
    print("=" * 60)
    print(f" निकाल : {'सगळ्या चाचण्या पास ✅' if ok_all else 'काहीतरी फसलं ❌'}")
    print("=" * 60)
    return 0 if ok_all else 1


# ============================================================

def main():

    if len(sys.argv) >= 2 and sys.argv[1] == "--demo":
        return demo()

    if len(sys.argv) < 3:
        print(__doc__ or "")
        print("वापर :  python3 ek_jodi_tapas.py AUDUSD 1h [किती मेणबत्त्या]")
        return 2

    symbol = sys.argv[1].upper().replace("/", "")
    timeframe = sys.argv[2].lower()

    try:
        count = int(sys.argv[3]) if len(sys.argv) > 3 else 6
    except ValueError:
        count = 6

    if timeframe not in TIMFRAMES:
        print(f"❌ आकार चुकीचा : {timeframe} — हे वापरा : {', '.join(TIMFRAMES)}")
        return 2

    fx = load_scanner()

    want = getattr(fx, "WANT", None)
    if want and symbol not in want:
        print(f"⚠️  {symbol} स्कॅनरच्या यादीत नाही. यादी : {' '.join(want)}")
        return 2

    print(f"डेटा आणतोय : {symbol} (5m मेणबत्त्या, शेवटच्या {count} × {timeframe})...")

    try:
        base = fx.biquote_candles(symbol, "5m", fx.KLINE_LIMIT, current=fx.now_ms())
    except Exception as e:
        print(f"❌ biquote कडून डेटा आला नाही : {e}")
        return 1

    if not base:
        print("❌ मेणबत्त्या मिळाल्या नाहीत")
        return 1

    recs = analyse(fx, base, timeframe, count)

    if not recs:
        print(f"⚠️  {timeframe} च्या पुरेशा मेणबत्त्या डेटामध्ये नाहीत "
              f"(biquote 5m इतिहास मर्यादित आहे)")
        return 1

    print_report(fx, symbol, timeframe, recs)
    return 0


if __name__ == "__main__":
    sys.exit(main())
