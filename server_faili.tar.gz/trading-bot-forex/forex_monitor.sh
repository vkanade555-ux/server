#!/bin/bash
# ============================================================
#  FOREX MONITOR — बाहेरून तपासणी (scanner code ला हात नाही)
#
#    forex_monitor.sh check    -> दर 5 मिनिटाला : heartbeat आहे का?
#                                 scan झाला का? जागा आहे का?
#    forex_monitor.sh daily    -> रोज 09:00 IST ला Telegram वर अहवाल
#    forex_monitor.sh test     -> एक test message (एकदा हेच चालवा)
#    forex_monitor.sh selftest -> offline चाचणी (network नाही, Telegram नाही)
#
#  फॉरेक्सचे वेळापत्रक :
#    दर 60 सेकंदाला heartbeat journal मध्ये येतो.
#    दर 10 मिनिटांनी scan (10m मेणबत्ती बंद + 20s) ·
#    IST :30 व :00 ला 30m सुद्धा · :30 ला (तासाच्या ठोक्यावर) 1h/2h ·
#    दर 4 तासांनी 4h · दर 8 तासांनी 8h.
#    बाजार बंद (शनि 04:00 → सोम 04:30 IST) असताना scan नसतो —
#    monitor ते heartbeat ओळीवरून ओळखतो आणि scan तपासत नाही.
#
#  हा script पूर्णपणे स्वतंत्र आहे — forex_scanner.py मध्ये काहीच बदलत नाही.
# ============================================================

DIR="${FX_DIR:-/home/ubuntu/trading-bot-forex}"
SVC="${FX_SVC:-forex-scanner.service}"
SCRIPT="${FX_SCRIPT:-$DIR/forex_scanner.py}"
ENV_FILE="$DIR/.env"
STATE_DIR="${FX_MON_STATE_DIR:-/var/lib/forex-monitor}"
STATE_FILE="$STATE_DIR/state"
LOG_FILE="$STATE_DIR/monitor.log"
STRIKE_FILE="$STATE_DIR/strikes"
DAILY_FLAG="$STATE_DIR/daily.flag"
ALERTS_FILE="$DIR/forex_alerts_sent.json"

# ---- आकडे (बदलायचे असल्यास इथे) ----
HEART_SLACK_SEC=300     # इतक्या सेकंदांत heartbeat नाही = शंका (5 मिनिटं)
SCAN_SLACK_SEC=1800     # इतक्यात पूर्ण scan नाही = शंका (30 मिनिटं; अपेक्षा दर 10 मिनिटांनी)
GRACE_SEC=240           # सेवा नुकतीच सुरू झाली असेल तर शांत
LOW_DISK_MB=500         # इतक्यापेक्षा कमी जागा = कळवा
REPEAT_SEC=21600        # एकच त्रुटी 6 तासांत एकदाच कळवा
NEED_STRIKES=2          # 2 वेळा (~10 मिनिटं) शंका आली तरच restart
RESTART_WAIT="${FX_RESTART_WAIT:-30}"
# restart कसा करायचा (चाचणीत 'true' ठेवतो — खऱ्या सेवेला हात लागू नये)
RESTART_CMD="${FX_RESTART_CMD:-systemctl restart $SVC}"
DAILY_WINDOW_SEC=32400  # 09:00 IST (दिवसातले सेकंद) — यानंतर रोजचा अहवाल

mkdir -p "$STATE_DIR" 2>/dev/null

# ---------- वेळ ----------
now_epoch(){ echo "${FX_NOW_EPOCH:-$(date +%s)}"; }
ist_now(){ TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M:%S IST'; }
ist_today(){ TZ=Asia/Kolkata date '+%d-%m-%Y'; }
sod_ist(){ echo $(( ($(now_epoch) + 19800) % 86400 )); }   # दिवसातले सेकंद (IST)

log(){ echo "$(ist_now) $*" >>"$LOG_FILE" 2>/dev/null
       if [ -n "${FX_DRY:-}" ] && [ -z "${FX_LOG_QUIET:-}" ]; then echo "[LOG] $*"; fi ; }

hhmm(){ printf '%02d:%02d' $(( $1 / 3600 )) $(( ($1 % 3600) / 60 )); }

# ---------- .env मधून value ----------
get_env(){
  [ -f "$ENV_FILE" ] || return 1
  grep -E "^[[:space:]]*$1=" "$ENV_FILE" 2>/dev/null | head -1 | cut -d= -f2- \
    | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
          -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//" | tr -d '\r'
}

# ---------- Telegram ----------
send_tg(){
  if [ -n "${FX_DRY:-}" ]; then
    echo "----- TELEGRAM (dry) -----"; echo "$1"; echo "--------------------------"
    return 0
  fi
  TOKEN=$(get_env TELEGRAM_BOT_TOKEN)
  CHAT=$(get_env TELEGRAM_CHAT_ID)
  if [ -z "$TOKEN" ] || [ -z "$CHAT" ]; then
    log "TRUTI: .env madhe TELEGRAM_BOT_TOKEN/CHAT_ID sapadla nahi ($ENV_FILE)"
    return 1
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -s -m 20 -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
         --data-urlencode "chat_id=$CHAT" \
         --data-urlencode "text=$1" >/dev/null 2>&1
  else
    python3 - "$TOKEN" "$CHAT" "$1" <<'PYEOF' >/dev/null 2>&1
import sys, urllib.parse, urllib.request
t, c, m = sys.argv[1], sys.argv[2], sys.argv[3]
d = urllib.parse.urlencode({"chat_id": c, "text": m}).encode()
try:
    urllib.request.urlopen(f"https://api.telegram.org/bot{t}/sendMessage", d, timeout=20)
except Exception:
    pass
PYEOF
  fi
  return 0
}

# ---------- सेवेची माहिती ----------
svc_active(){ [ -n "${FX_FAKE_ACTIVE:-}" ] && { echo "$FX_FAKE_ACTIVE"; return; }
              systemctl is-active "$SVC" 2>/dev/null; }
svc_enabled(){ [ -n "${FX_FAKE_ENABLED:-}" ] && { echo "$FX_FAKE_ENABLED"; return; }
               systemctl is-enabled "$SVC" 2>/dev/null; }
svc_uptime_sec(){
  if [ -n "${FX_FAKE_UPTIME:-}" ]; then echo "$FX_FAKE_UPTIME"; return; fi
  TS=$(systemctl show "$SVC" -p ActiveEnterTimestamp --value 2>/dev/null)
  [ -n "$TS" ] || { echo 0; return; }
  S=$(date -d "$TS" +%s 2>/dev/null) || { echo 0; return; }
  echo $(( $(now_epoch) - S ))
}
svc_restarts(){
  if [ -n "${FX_FAKE_RESTARTS:-}" ]; then echo "$FX_FAKE_RESTARTS"; return; fi
  R=$(systemctl show "$SVC" -p NRestarts --value 2>/dev/null); echo "${R:-0}"
}

# ---------- journal ----------
#  FX_JOURNAL_FILE दिले तर तीच फाइल वाचतो (चाचणीसाठी) — नाहीतर खरा journal
journal_window(){   # $1 = किती सेकंद मागे
  if [ -n "${FX_JOURNAL_FILE:-}" ]; then cat "$FX_JOURNAL_FILE" 2>/dev/null; return; fi
  journalctl -u "$SVC" --since "@$(( $(now_epoch) - $1 ))" --no-pager -o cat 2>/dev/null
}
count_in(){  # $1 = किती सेकंद मागे, $2 = नमुना
  journal_window "$1" | grep -c -F "$2"
}
last_in(){   # $1 = किती सेकंद मागे, $2 = नमुना
  journal_window "$1" | grep -F "$2" | tail -1
}

# ---------- बाजार उघडा आहे का (heartbeat ओळीवरून) ----------
market_state(){
  HB=$(last_in "$HEART_SLACK_SEC" 'HEARTBEAT |')
  case "$HB" in
    *"market CLOSED"*) echo "CLOSED" ;;
    *"market OPEN"*)   echo "OPEN"   ;;
    *)                 echo "?"      ;;
  esac
}

# ---------- पुढचा scan ----------
#  मेणबत्त्या UTC वर आधारित → 10m ठोका = दर 10 मिनिटांनी (IST मध्ये :30/:40/.../:20)
#  तासाच्या ठोक्यावर (UTC :00 = IST :30) 30m/1h/2h सुद्धा; 4h/8h ठरलेल्या तासांना.
next_scan_info(){
  NOW=$(now_epoch)
  NEXT=$(( (NOW / 600 + 1) * 600 + 20 ))        # पुढची 10m जाळी + 20 सेकंद
  NEXT_IST=$(( (NEXT + 19800) % 86400 ))
  UH=$(( (NEXT / 3600) % 24 ))                  # तो UTC तास
  MM=$(( (NEXT_IST % 3600) / 60 ))
  TFS="10m"
  if [ "$MM" = "0" ]; then
    TFS="10m, 30m"
  fi
  if [ "$MM" = "30" ]; then
    TFS="10m, 30m, 1h, 2h"
    [ $(( UH % 4 )) -eq 0 ] && TFS="$TFS, 4h"
    [ $(( UH % 8 )) -eq 0 ] && TFS="$TFS, 8h"
  fi
  echo "$(hhmm "$NEXT_IST") IST ($TFS)"
}

# ---------- state ----------
set_state(){ echo "$1|$(date +%s)" >"$STATE_FILE" 2>/dev/null; }

notify_once(){   # $1 = key, $2 = message (एकच त्रुटी वारंवार नको)
  KEY="$1"
  LAST_KEY=""; LAST_TS=0
  [ -f "$STATE_FILE" ] && IFS='|' read -r LAST_KEY LAST_TS <"$STATE_FILE"
  NOW=$(date +%s)
  if [ "$KEY" = "$LAST_KEY" ] && [ $((NOW - ${LAST_TS:-0})) -lt "$REPEAT_SEC" ]; then
    log "purvicha majkur dila aahe ($KEY) - punha pathvat nahi"
    return 0
  fi
  send_tg "$2"
  set_state "$KEY"
}

# ---------- जागा (disk) ----------
check_disk(){
  FREE_MB=$(df -Pk "$DIR" 2>/dev/null | awk 'NR==2 {print int($4/1024)}')
  case "$FREE_MB" in ''|*[!0-9]*) FREE_MB="" ;; esac
  if [ -n "$FREE_MB" ] && [ "$FREE_MB" -lt "$LOW_DISK_MB" ]; then
    notify_once "disk" "⚠️ JAGAA KAMI AAHE — फॉरेक्स SCANNER

फक्त ${FREE_MB}MB free aahe ($DIR).
Jaga mokli kara (junya backup files kadhun taka).

Tapat kara:  df -h $DIR
Vela: $(ist_now)"
    log "JAGA KAMI: ${FREE_MB}MB free"
  fi
}

# ============================================================
#  CHECK — दर 5 मिनिटाला
# ============================================================
do_check(){

  # ---- 0) रोजच्या अहवालाची वेळ झाली का? (रोज एकदाच) ----
  SOD=$(sod_ist)
  if [ "$SOD" -ge "$DAILY_WINDOW_SEC" ] && [ "$(cat "$DAILY_FLAG" 2>/dev/null)" != "$(ist_today)" ]; then
    ist_today >"$DAILY_FLAG" 2>/dev/null
    do_daily
    log "DAILY (check madhun) pathvla"
    return 0
  fi

  ACTIVE=$(svc_active)

  if [ "$ACTIVE" != "active" ]; then
    notify_once "down" "❌ फॉरेक्स SCANNER BAND AAHE

Seva: $ACTIVE
Monitor swatahun suru kart nahit (jaanun band kelela asu shakto).

Tapat kara:  sudo systemctl status $SVC
Vela: $(ist_now)"
    log "DOWN: seva $ACTIVE"
    return 0
  fi

  UP=$(svc_uptime_sec)

  if [ "$UP" -lt "$GRACE_SEC" ]; then
    log "OK: seva navin suru ($UP sec) - grace madhe"
    return 0
  fi

  # ---- 1) heartbeat (दर 60 सेकंदाला येतो) ----
  HEARTS=$(count_in "$HEART_SLACK_SEC" 'HEARTBEAT |')
  MKT=$(market_state)

  STRUCK=0
  [ "${HEARTS:-0}" -ge 1 ] || { STRUCK=$((STRUCK + 1)); }

  if [ "$MKT" = "CLOSED" ]; then

    # बाजार बंद — scan अपेक्षित नाहीच (शनि 04:00 → सोम 04:30)
    SCANS="-"

    if [ "$STRUCK" -eq 0 ]; then
      rm -f "$STRIKE_FILE" 2>/dev/null
      check_disk
      set_state "ok"
      log "OK: heartbeat $HEARTS (${HEART_SLACK_SEC}s) | bazar BAND - scans apeshit nahit"
      return 0
    fi

  else

    # ---- 2) पूर्ण scan (दर 10 मिनिटांनी) ----
    SCANS=$(count_in "$SCAN_SLACK_SEC" 'Setup scan complete')
    [ "${SCANS:-0}" -ge 1 ] || { STRUCK=$((STRUCK + 1)); }

    if [ "$STRUCK" -eq 0 ]; then
      rm -f "$STRIKE_FILE" 2>/dev/null
      check_disk
      set_state "ok"
      log "OK: heartbeat $HEARTS (${HEART_SLACK_SEC}s) | scans $SCANS (${SCAN_SLACK_SEC}s)"
      return 0
    fi

  fi

  STRIKES=$(cat "$STRIKE_FILE" 2>/dev/null)
  [ -n "$STRIKES" ] || STRIKES=0
  STRIKES=$(( STRIKES + (STRUCK > 0 ? 1 : 0) ))
  echo "$STRIKES" >"$STRIKE_FILE" 2>/dev/null

  if [ "$STRIKES" -lt "$NEED_STRIKES" ]; then
    log "SHANKA: heartbeat=$HEARTS scans=$SCANS bazar=$MKT ($STRIKES/$NEED_STRIKES) - ajun thambto"
    return 0
  fi

  log "TRAS: heartbeat=$HEARTS scans=$SCANS bazar=$MKT ($STRIKES/$NEED_STRIKES) - restart karto..."
  $RESTART_CMD >/dev/null 2>&1
  sleep "$RESTART_WAIT"
  NEW=$(svc_active)

  if [ "$NEW" = "active" ]; then
    MSG="⚠️ फॉरेक्स SCANNER ADKALA HOTA — MONITOR NE PARAT SURU KELA

$(( HEART_SLACK_SEC / 60 )) minit heartbeat nahi aala
aani $(( SCAN_SLACK_SEC / 60 )) minit scan pan zala nahi hota
(donhi velya tapasani kelyavar).

✅ Restart nantar: $NEW
Vela: $(ist_now)"
  else
    MSG="🚨 फॉरेक्स SCANNER PARAT SURU ZALA NAHI!

Monitor ne restart kela, pan seva aata: $NEW

Lagech tapat kara:
  sudo systemctl status $SVC
  sudo journalctl -u $SVC -n 40 --no-pager"
  fi

  send_tg "$MSG"
  set_state "restarted"
  log "RESTART kela -> $NEW"
}

# ============================================================
#  DAILY — रोज 09:00 IST
# ============================================================
do_daily(){

  ACTIVE=$(svc_active)
  ENABLED=$(svc_enabled)
  UP=$(svc_uptime_sec)
  UP_H=$(( UP / 3600 ))
  RESTARTS=$(svc_restarts)
  MKT=$(market_state)

  W=86400                       # गेले 24 तास
  SCANS=$(count_in "$W" 'Setup scan complete')
  SETUPS=$(count_in "$W" 'SETUP REGISTERED:')
  DELIV=$(count_in "$W" 'ALERT DELIVERED')
  HEARTS=$(count_in "$W" 'HEARTBEAT |')

  LAST_ALERT=$(last_in "$W" 'ALERT DELIVERED' | sed 's/^✅ *//; s/^ALERT DELIVERED: *//')
  [ -n "$LAST_ALERT" ] || LAST_ALERT="-(adhi alert nahi)"

  DISK=$(df -h "$DIR" 2>/dev/null | awk 'NR==2 {print $4}')
  [ -n "$DISK" ] || DISK="?"

  AF=""
  if [ -f "$ALERTS_FILE" ]; then
    AF_KB=$(( $(stat -c %s "$ALERTS_FILE" 2>/dev/null || echo 0) / 1024 ))
    AF_KEYS=$(python3 -c "import json,sys
try: print(len(json.load(open(sys.argv[1]))))
except Exception: print('?')" "$ALERTS_FILE" 2>/dev/null)
    AF="
📄 alerts file : ${AF_KB}KB (${AF_KEYS:-?} keys)"
  fi

  if [ "$ACTIVE" = "active" ] && [ "${SCANS:-0}" -gt 0 ]; then
    LIVE="✅ हो — गेल्या 24 तासांत $SCANS scan + $HEARTS heartbeat"
  elif [ "$ACTIVE" = "active" ]; then
    LIVE="⚠️ सेवा चालू आहे, पण scan ची नोंद नाही — पुढच्या तपासणीत कळेल"
  else
    LIVE="❌ नही — सेवा $ACTIVE आहे"
  fi

  EXTRA=""
  if [ "${DELIV:-0}" = "0" ]; then
    EXTRA="
ℹ️ alert आला नाही = नियम पूर्ण झाला नाही (यंत्र ठीक आहे)"
  fi
  if [ "$MKT" = "CLOSED" ]; then
    EXTRA="$EXTRA
🌙 बाजार आत्ता बंद आहे (शनि 04:00 → सोम 04:30 IST) — scans कमी असणं सामान्य."
  fi

  MSG="📊 फॉरेक्स दैनंदिन अहवाल (biquote · v7 नियम)
$(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M') IST

सेवा        : $ACTIVE (enabled: $ENABLED)
चालू        : ${UP_H} तास | restarts: $RESTARTS
जोड्या      : 28 (27 forex + XAUUSD)

गेल्या 24 तासांत (बाजार उघडा असताना दर 10 मिनिटांनी scan):
  🔍 scans झाले      : $SCANS
  🧩 setups सापडले   : $SETUPS
  🚨 alerts पाठवले   : $DELIV
  🕐 शेवटचा alert    : $LAST_ALERT

💓 जिवंत       : $LIVE
🌍 बाजार       : $MKT
⏰ पुढचा scan  : $(next_scan_info)
💾 जागा        : $DISK free$AF$EXTRA"

  send_tg "$MSG"
  log "DAILY pathvla (scans=$SCANS setups=$SETUPS alerts=$DELIV hearts=$HEARTS restarts=$RESTARTS market=$MKT)"
}

# ============================================================
#  SELFTEST — offline (network नाही, Telegram नाही)
# ============================================================
do_selftest(){

  T=$(mktemp -d)
  PASS=0; FAIL=0
  ck(){ if [ "$2" = "$3" ]; then echo "  ✅ $1 ($2)"; PASS=$((PASS+1));
        else echo "  ❌ $1 — मिळाले '$2' पाहिजे होते '$3'"; FAIL=$((FAIL+1)); fi; }

  cat >"$T/journal" <<'EOF'
FOREX SCANNER  (feed: BIQUOTE — MT5 live quotes)
Pairs: 28 instruments (27 forex + XAUUSD sone)
Active symbols loaded: 28
HEARTBEAT | polls 300 | prices 28 | active setups 2 | alerts sent 1 | market OPEN | last poll 0.4s ago | last sweep 12.0s ago
SETUP REGISTERED: EURUSD 30m Scanner 1 Bearish Reversal | Confirmation: 28-09-2026 15:30:00 IST to 28-09-2026 15:45:00 IST
MATCH: EURUSD 30m Scanner 1
HEARTBEAT | polls 315 | prices 28 | active setups 2 | alerts sent 1 | market OPEN | last poll 0.6s ago | last sweep 8.0s ago
🚨 ALERT: EURUSD 30m Scanner 1 1.08910 | 28-09-2026 15:38:11 IST
✅ ALERT DELIVERED: EURUSD 30m Scanner 1
Setup scan complete. New setups: 3
HEARTBEAT | polls 330 | prices 28 | active setups 1 | alerts sent 2 | market OPEN | last poll 0.5s ago | last sweep 5.0s ago
EOF

  cat >"$T/journal_closed" <<'EOF'
HEARTBEAT | polls 900 | prices 28 | active setups 0 | alerts sent 5 | market CLOSED | last poll -1.0s ago | last sweep 60.0s ago
HEARTBEAT | polls 915 | prices 28 | active setups 0 | alerts sent 5 | market CLOSED | last poll -1.0s ago | last sweep 60.0s ago
EOF

  cat >"$T/.env" <<'EOF'
TELEGRAM_BOT_TOKEN=TESTTOKEN
TELEGRAM_CHAT_ID=123456
EOF

  FX_DIR="$T" FX_JOURNAL_FILE="$T/journal" FX_MON_STATE_DIR="$T/state" \
  FX_DRY=1 FX_FAKE_ACTIVE=active FX_FAKE_ENABLED=enabled FX_FAKE_UPTIME=7200 \
  FX_FAKE_RESTARTS=1 FX_NOW_EPOCH=1759060000 \
  bash "$0" _counts >"$T/out" 2>&1

  ck "heartbeat आकडा"  "$(grep '^HEARTS=' "$T/out" | cut -d= -f2)" "3"
  ck "scan आकडा"       "$(grep '^SCANS='  "$T/out" | cut -d= -f2)" "1"
  ck "setups आकडा"     "$(grep '^SETUPS=' "$T/out" | cut -d= -f2)" "1"
  ck "alerts आकडा"     "$(grep '^DELIV='  "$T/out" | cut -d= -f2)" "1"
  ck "शेवटचा alert"    "$(grep '^LAST='   "$T/out" | cut -d= -f2)" "EURUSD 30m Scanner 1"

  # बाजार उघडा/बंद ओळख
  FX_DIR="$T" FX_JOURNAL_FILE="$T/journal" FX_NOW_EPOCH=1759060000 \
    bash "$0" _mkt >"$T/mkt1" 2>&1
  ck "बाजार ओळख (उघडा)" "$(cat "$T/mkt1")" "OPEN"

  FX_DIR="$T" FX_JOURNAL_FILE="$T/journal_closed" FX_NOW_EPOCH=1759060000 \
    bash "$0" _mkt >"$T/mkt2" 2>&1
  ck "बाजार ओळख (बंद)"  "$(cat "$T/mkt2")" "CLOSED"

  # पुढचा scan गणित
  FX_NOW_EPOCH=1759060000 bash "$0" _next >"$T/nx1" 2>&1
  ck "पुढचा scan 10m गाळणीत" "$(grep -c 'IST (10m' "$T/nx1")" "1"
  FX_NOW_EPOCH=1759060700 bash "$0" _next >"$T/nx2" 2>&1   # तासाच्या ठोक्याच्या 100s आधी
  ck "ठोक्यावर अधिक timeframes" "$(grep -c '1h, 2h' "$T/nx2")" "1"

  # daily message + रोज एकदाच
  FX_DIR="$T" FX_JOURNAL_FILE="$T/journal" FX_MON_STATE_DIR="$T/state2" \
  FX_DRY=1 FX_FAKE_ACTIVE=active FX_FAKE_ENABLED=enabled FX_FAKE_UPTIME=7200 \
  FX_FAKE_RESTARTS=1 FX_NOW_EPOCH=1759060000 \
  bash "$0" daily >"$T/daily1" 2>&1

  ck "daily निघतो"              "$(grep -c 'फॉरेक्स दैनंदिन अहवाल' "$T/daily1")" "1"
  ck "daily मध्ये जिवंत ओळ"     "$(grep -c '💓 जिवंत' "$T/daily1")" "1"
  ck "daily मध्ये पुढचा scan"   "$(grep -c '⏰ पुढचा scan' "$T/daily1")" "1"
  ck "daily मध्ये बाजार ओळ"     "$(grep -c '🌍 बाजार' "$T/daily1")" "1"

  # ---- बाजार बंद : scan नसला तरी शंका नको ----
  CLOSED_ENV="FX_DIR=$T FX_JOURNAL_FILE=$T/journal_closed FX_MON_STATE_DIR=$T/state5
FX_DRY=1 FX_FAKE_ACTIVE=active FX_FAKE_UPTIME=99999 FX_FAKE_RESTARTS=0
FX_NOW_EPOCH=1758850000 FX_RESTART_WAIT=0 FX_RESTART_CMD=true"
  env $CLOSED_ENV bash "$0" _strike_log >"$T/c1" 2>&1
  ck "बाजार बंद → OK"          "$(grep -c 'bazar BAND' "$T/c1")" "1"
  ck "बाजार बंद → restart नाही" "$(grep -c 'TRAS' "$T/c1")" "0"

  # ---- journal रिकामा (heartbeat नाही + scan नाही) → 2 वेळा शंका → restart ----
  STRIKE_ENV="FX_DIR=$T FX_JOURNAL_FILE=$T/empty FX_MON_STATE_DIR=$T/state3
FX_DRY=1 FX_FAKE_ACTIVE=active FX_FAKE_UPTIME=99999 FX_FAKE_RESTARTS=0
FX_NOW_EPOCH=1758850000 FX_RESTART_WAIT=0 FX_RESTART_CMD=true"
  env $STRIKE_ENV bash "$0" _strike_log >"$T/s1" 2>&1
  env $STRIKE_ENV bash "$0" _strike_log >"$T/s2" 2>&1

  ck "पहिली शंका थांबते"     "$(grep -c 'SHANKA' "$T/s1")" "1"
  ck "दुसऱ्यावेळी restart"   "$(grep -c 'TRAS' "$T/s2")" "1"
  ck "restart चा Telegram"   "$(grep -c 'ADKALA HOTA' "$T/s2")" "1"

  # ---- सेवा बंद असल्यास कळवतो ----
  DOWN_ENV="FX_DIR=$T FX_JOURNAL_FILE=$T/journal FX_MON_STATE_DIR=$T/state6
FX_DRY=1 FX_FAKE_ACTIVE=failed FX_FAKE_UPTIME=99999 FX_NOW_EPOCH=1758850000"
  env $DOWN_ENV bash "$0" _strike_log >"$T/d1" 2>&1
  ck "सेवा बंद → कळवतो"      "$(grep -c 'BAND AAHE' "$T/d1")" "1"
  ck "सेवा बंद → restart नाही" "$(grep -c 'TRAS' "$T/d1")" "0"

  # ---- रोजचा अहवाल रोज एकदाच ----
  DAILY_ENV="FX_DIR=$T FX_JOURNAL_FILE=$T/journal FX_MON_STATE_DIR=$T/state4
FX_DRY=1 FX_FAKE_ACTIVE=active FX_FAKE_ENABLED=enabled FX_FAKE_UPTIME=7200
FX_FAKE_RESTARTS=1 FX_NOW_EPOCH=1759060000"
  env $DAILY_ENV bash "$0" _maybe_daily >"$T/md1" 2>&1
  env $DAILY_ENV bash "$0" _maybe_daily >"$T/md2" 2>&1

  ck "खिडकीत अहवाल जातो"     "$(grep -c 'दैनंदिन अहवाल' "$T/md1")" "1"
  ck "दुसऱ्यांदा जात नाही"    "$(grep -c 'दैनंदिन अहवाल' "$T/md2")" "0"

  rm -rf "$T"
  echo
  echo "================================================================"
  echo " निकाल : $PASS pass, $FAIL fail"
  echo "================================================================"
  [ "$FAIL" -eq 0 ]
}

# ============================================================
case "${1:-}" in
  check)  do_check ;;
  daily)  ist_today >"$DAILY_FLAG" 2>/dev/null; do_daily ;;
  test)   send_tg "🧪 फॉरेक्स MONITOR TEST

Majkur tech yet aahe - देखरेख barobar jodleli aahe. ✅
Seva: $(svc_active)
Bazar: $(market_state)
Pudhcha scan: $(next_scan_info)
Vela: $(ist_now)" ; log "TEST majkur pathvla" ;;
  selftest) do_selftest ;;
  # ---- चाचणीचे आतले आदेश (नेहमी वापरायचे नाहीत) ----
  _counts) echo "HEARTS=$(count_in 86400 'HEARTBEAT |')"
           echo "SCANS=$(count_in 86400 'Setup scan complete')"
           echo "SETUPS=$(count_in 86400 'SETUP REGISTERED:')"
           echo "DELIV=$(count_in 86400 'ALERT DELIVERED')"
           echo "LAST=$(last_in 86400 'ALERT DELIVERED' | sed 's/^✅ *//; s/^ALERT DELIVERED: *//')" ;;
  _mkt)    market_state ;;
  _next)   next_scan_info ;;
  _maybe_daily) SOD=$(sod_ist)
           if [ "$SOD" -ge "$DAILY_WINDOW_SEC" ] && [ "$(cat "$DAILY_FLAG" 2>/dev/null)" != "$(ist_today)" ]; then
             ist_today >"$DAILY_FLAG"; do_daily
           else
             echo "ajun vel nahi / adhich pathvla"
           fi ;;
  _strike_log) : >"$LOG_FILE"
           FX_LOG_QUIET=1; export FX_LOG_QUIET
           do_check; cat "$LOG_FILE" ;;
  *) echo "Use: $0  check | daily | test | selftest" ; exit 2 ;;
esac
