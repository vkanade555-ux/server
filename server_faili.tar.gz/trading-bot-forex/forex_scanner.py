"""
FOREX SCANNER  —  biquote.io feed (MetaTrader 5)  ·  REST polling
=====================================================================

ही crypto scanner ची (binance-scanner/v2/live_scanner.py) तीच file आहे.
फक्त FEED बदलला आहे — नियम / logic यात एकही बदल नाही.

काय बदललं (आणि काय नाही) :
  BADALLA :
    - feed        : Binance Futures  ->  biquote.io (MT5 live quotes, key नाही)
                    (हे feed एकच — Yahoo चा पर्याय पूर्ण काढून टाकला आहे)
    - symbols     : 20 forex pairs   ->  28 instruments (27 forex + XAUUSD सोने)
    - base candle : 15m              ->  5m
    - timeframes  : finals 1h/2h/4h/8h  ->  10m/30m/1h/2h/4h/8h
                    (5m+5m=10m · 15m+15m=30m · 30m+30m=1h · 1h+1h=2h ·
                     2h+2h=4h · 4h+4h=8h)
    - server time : Binance serverTime ->  स्थानिक घड्याळ (NTP)
    - bazar hours : 24x7               ->  सोम 04:30 IST ते शनि 04:00 IST
                                                        (बंद असताना scanner शांत)
  TASACH (अगदी अक्षरशः) :
    - Scanners 1/2/3/4 चे नियम + **क्रिप्टो v7 "stick" चे नवे नियम**
    - body >= 50%                                   (v7 : 60% -> 50%)
    - close position <= 50% (bearish) / >= 50% (bullish)   (v7 : 30/70 -> 50/50)
    - INDICATOR : momentum (length 1) — खांबाची उंची
                  |2रा खांब| >= 3.00 x |1ला खांब|  आणि दोघे उलट दिशेचे
    - Scanner 1/2 : दुसरी candle STRICTLY पहिल्याच्या आत
    - Scanner 3/4 : दुसरी candle पहिल्याचा high/low तोडते (equality नाही)
    - confirmation = पुढची component candle, RUNNING; breakout = strict (<, >)
    - **तुटण्याची पातळी = 2ऱ्या मेणबत्तीचा** low/high (final चा नाही)
    - 05:30 IST anchor (= 00:00 UTC, forex साठी अगदी नैसर्गिक)
    - एक setup -> एकच alert, forex_alerts_sent.json
    - Telegram retry x3, atomic file write, auto-cleanup, watchdog, heartbeat

FEED बद्दल (प्रामाणिकपणे) :
  - biquote हा MT5 चा खरा bid/ask/mid देतो — ~1 सेकंदाला update. खूप जलद
    आणि स्पष्ट. Key/signup लागत नाही.
  - 1m/5m/15m/30m/1h/4h candles मध्ये खरे High/Low असतात -> नियम तंतोतंत चालतात.
  - मर्यादा : इतिहास फारसा मागे मिळत नाही (5m ~1 दिवस, 1h ~7 दिवस, 4h ~30 दिवस).
    चालू scanner साठी पुरेसा; मोठ्या timeframes च्या जुन्या setups मात्र कमी दिसतील.
  - प्रत्येक pair साठी वेगळी request लागते (biquote वर एकत्र/batch नाही).
    28 pairs x (1 किंमत + 1 candles) प्रति चक्र = भार अगदी कमी.
  - Yahoo चा सगळा कोड काढून टाकला आहे — फीड एकच, आणि तोच biquote.
  - feed तुटल्यास watchdog process restart करतो आणि Telegram वर कळतं.

CHALAVAYCHA :
   ./venv/bin/python forex_scanner.py            (सुरू)
   ./venv/bin/python forex_scanner.py --test     (चाचण्या)
   ./venv/bin/python forex_scanner.py --once --dry   (एक scan, telegram नाही)
   ./venv/bin/python forex_scanner.py --once     (एक scan करून थांबा)
"""
import os
import sys
import json
import time
import threading
from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from dotenv import load_dotenv


# ============================================================
# CONFIG
# ============================================================

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# ---- आपली 28 instruments (27 forex + XAUUSD sone) --------------
# हीच नावं biquote वर आहेत (message / key / log मध्येही हीच दिसतात)
FOREX_PAIRS = [
    "GBPCHF",
    "EURCHF",
    "EURCAD",
    "GBPCAD",
    "GBPNZD",
    "AUDCHF",
    "GBPUSD",
    "AUDCAD",
    "EURUSD",
    "GBPAUD",
    "USDCHF",
    "NZDCHF",
    "EURAUD",
    "NZDCAD",
    "AUDNZD",
    "USDCAD",
    "AUDUSD",
    "CADCHF",
    "NZDUSD",
    "EURGBP",
    "XAUUSD",   # सोने
    "GBPJPY",
    "EURJPY",
    "AUDJPY",
    "USDJPY",
    "NZDJPY",
    "CADJPY",
    "CHFJPY",
]

# गेल्या "MARKET BAND" message ची वेळ (वारंवार message नको)
MARKET_NOTICE = {"ms": 0}

# ---- FEED : biquote.io (एकच feed — MT5 live quotes, key नाही) ----
BIQUOTE_BASE = "https://biquote.io/api"
BIQUOTE_MIN_GAP = 0.02          # दोन requests मधलं कमीत कमी अंतर (सेकंद)
BIQUOTE_RETRIES = 3
BIQUOTE_BACKOFF = [2.0, 6.0, 15.0]
BIQUOTE_STALE_SECONDS = 900     # इतकं जुनं quote स्वीकारायचं नाही (सेकंद)

# Final timeframe -> component candle (minutes)
#   10m = 5m + 5m      30m = 15m + 15m     1h = 30m + 30m
#    2h = 1h + 1h       4h = 2h + 2h        8h = 4h + 4h
TIMEFRAMES = {
    "10m": 5,
    "30m": 15,
    "1h": 30,
    "2h": 60,
    "4h": 120,
    "8h": 240,
}

BODY_THRESHOLD = 0.50          # 1ल्या मेणबत्तीचा body >= 50%   (v7 : 60% -> 50%)

# ============================================================
# INDICATOR नियम — MOMENTUM (length 1) : खांबाची उंची
# ============================================================
# Momentum value (length 1) = मेणबत्तीचा प्रवास = बंद - उघड.
# ती TradingView वर खांब (histogram) स्वरूपात दाखवली जाते — खांब
# *मागच्या value पासून आजच्या value पर्यंत* रंगवला जातो.
# म्हणजे खांबाची उंची = momentum value मधला बदल.
#
#   m0 = 1ल्याच्या आधीची component मेणबत्ती
#   m1 = 1ली component मेणबत्ती     ->  खांब 1 = m1 - m0
#   m2 = 2री component मेणबत्ती     ->  खांब 2 = m2 - m1
#
# नियम : |खांब 2| >= 3.00 x |खांब 1| आणि दोन्ही खांब उलट दिशेचे.
MOMENTUM_ENABLED = True      # खोटं केलं तर indicator अगदी पूर्ण बंद
MOMENTUM_LENGTH = 1
MOMENTUM_MULTIPLIER = 3.0    # 2ऱ्या खांब = 1ल्याच्या किती पट
MOMENTUM_REQUIRE_OPPOSITE = True   # दोन्ही खांब उलट दिशेचे हवेत (V / उलट-V)
MOMENTUM_EPSILON = 1e-9      # अगदी 3x असलेली मेणबत्ती रद्द होऊ नये म्हणून


def candle_momentum(candle):
    """Momentum (length 1) ची value = मेणबत्तीचा प्रवास (बंद - उघड)."""
    return candle["close"] - candle["open"]


def momentum_stick(previous, candle):
    """खांबाची उंची = या value मधून मागच्या value ची वजाबाकी."""
    return candle_momentum(candle) - candle_momentum(previous)


def momentum_sticks(previous, first, second):
    """दोन्ही खांब: (1ला, 2रा). 'previous' नसेल तर 1ला = स्वतःची value."""
    if previous is None:
        s1 = candle_momentum(first)
    else:
        s1 = momentum_stick(previous, first)
    s2 = momentum_stick(first, second)
    return s1, s2


def momentum_ratio(previous, first, second):
    """2ऱ्या खांब ÷ 1ल्या खांब (पट). कल्कण झाला तर None."""
    s1, s2 = momentum_sticks(previous, first, second)
    if abs(s1) <= 0:
        return None
    return abs(s2) / abs(s1)


def momentum_ok(previous, first, second):
    """Indicator नियम जुळला तर True."""
    if not MOMENTUM_ENABLED:
        return True

    s1, s2 = momentum_sticks(previous, first, second)

    if abs(s1) <= 0:
        return False

    if MOMENTUM_REQUIRE_OPPOSITE and (s1 > 0) == (s2 > 0):
        return False

    return abs(s2) >= MOMENTUM_MULTIPLIER * abs(s1) - MOMENTUM_EPSILON * abs(s1)


CLOSE_LOW_THRESHOLD = 0.50     # bearish (1,3) : final close <= 50%  (v7 : 30% -> 50%)
CLOSE_HIGH_THRESHOLD = 0.50    # bullish (2,4) : final close >= 50%  (v7 : 70% -> 50%)

# ---- base candle : 5 मिनिटं ----
BASE_GRID_MINUTES = 5
BASE_INTERVAL_MS = BASE_GRID_MINUTES * 60 * 1000
BASE_INTERVAL = "5m"

# मेणबत्ती बंद झाल्यावर किती सेकंद थांबून scan करायचं
SCAN_DELAY_SECONDS = 20

# 300 x 5m = 25 तास (biquote 5m वर ~289 पेक्षा जास्त देत नाही)
KLINE_LIMIT = 300


def final_minutes(timeframe):
    """'10m' -> 10 · '30m' -> 30 · '1h' -> 60 · '8h' -> 480   (मिनिटं)"""

    number = int(timeframe[:-1])

    return number if timeframe.endswith("m") else number * 60


MAX_WORKERS = 20

IST = timezone(timedelta(hours=5, minutes=30))

ALERT_FILE = "forex_alerts_sent.json"

TEST_MODE = "--test" in sys.argv
DRY_RUN = "--dry" in sys.argv      # scan kara, pan telegram pathवू naka (nond pan nahi)

# ---- alerts_sent.json AUTO CLEANUP ------------------------------

# itkya divsaांpeksha junya keys automatic kadhli jatat.
# Ek key fakt tichya final candle chya confirmation window madhe
# ekdach trigger hou shakto (maximum 4 tas) - mhanun 30 divas
# khup surक्षित aahe. Junya keys kadhlyane ekhi navin alert
# block hou shakat nahi.
ALERT_RETENTION_DAYS = 30

# kiti velanni prune karaवे (6 tas = divasat 4 velा)
PRUNE_INTERVAL_SECONDS = 6 * 60 * 60

# disk itका kami zala tar heartbeat madhe LOW DISK warning
LOW_DISK_MB = 500

# WATCHDOG: price feed itkya secondांपेक्षा jast thambla tar
# process स्वतःch बंद hoतो आणि systemd (Restart=always) punha
# suru karto. Thread मेला tari system जिवंत rahto.
FEED_STALE_EXIT_SECONDS = 300

# prun karण्यापूर्वी ekdach yeणारा backup
BACKUP_FILE = ALERT_FILE + ".bak"

# ---- price feed ------------------------------------------------

# sagle symbols chya kimati kiti secondanni tapatasat
# (Yahoo 1m data ~1 minutani update hoto - mhanun 45s puresa aahe
#  ani Yahoo var कमी requests - 429 talu lagतो)
POLL_INTERVAL = 30.0      # 28 pairs x dar 30s = 56 requests/minit (मर्यादा 15000)

# running confirmation candle 1m varun kiti secondanni tapatasat (wick insurance)
SWEEP_INTERVAL = 60.0

# ekा sweep madhe jastit-jast kiti setups (kimati level la javळ chya aadhi)
SWEEP_MAX_SETUPS = 20
SWEEP_WORKERS = 4
SWEEP_KLINE_LIMIT = 300

# ekा sweep madhe kiti 1m candles (fakt nivडक भाग maगavतो)
SWEEP_LOOKBACK_MINUTES = 45

# ---- बाजाराची वेळ (UTC मध्ये) ----------------------------------
# Forex: सोमवार 04:30 IST (= रवि 23:00 UTC) ते शनिवार 04:00 IST (= शुक्र 22:30 UTC)
MARKET_CLOSE_FRIDAY_UTC_HOUR = 22.0   # शुक्र, यानंतर बंद
MARKET_OPEN_SUNDAY_UTC_HOUR = 21.5    # रवि, यानंतर उघडा
# बाजार उघडल्यावर इतक्या सेकंदांपर्यंत watchdog त्रास देणार नाही
MARKET_OPEN_GRACE_SECONDS = 600

# dar kiti secondala journal madhe jivantपणाची ओळ
HEARTBEAT_SECONDS = 60.0

# Telegram delivery
TELEGRAM_RETRIES = 3
TELEGRAM_RETRY_DELAY = 2.0

# Ekach alert sathi punha-punha Telegram prayatna kiti secondanni
SEND_RETRY_COOLDOWN_MS = 30 * 1000

# eवdhe prayatna zalyavar "give up" (pan setup window paryant chalu rahto)
MAX_SEND_ATTEMPTS = 40


# ============================================================
# GLOBAL STATE
# ============================================================

_thread_local = threading.local()

ACTIVE_SYMBOLS = set()

# key: SYMBOL|TIMEFRAME|FINAL_OPEN_TIME|SCANNER
ACTIVE_SETUPS = {}

LOCK = threading.Lock()

# ekach taseek punha scan hou naye
LAST_SCAN_KEYS = set()

SENT_ALERTS = set()

# price cache (heartbeat sathi + sweep ordering sathi)
PRICE_CACHE = {}

# server time offset
TIME_OFFSET_MS = 0

# heartbeat stats
POLL_COUNT = 0
LAST_POLL_MS = 0
LAST_PRICE_COUNT = 0
LAST_POLL_ERROR = None
SWEEP_COUNT = 0
LAST_SWEEP_MS = 0
ALERTS_SENT_COUNT = 0
LAST_PRUNE_MS = 0


# ============================================================
# HTTP
# ============================================================

def get_session():

    if not hasattr(_thread_local, "session"):

        _thread_local.session = requests.Session()

        _thread_local.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0 Safari/537.36"
            ),
            "Accept": "application/json",
        })

    return _thread_local.session


def get_server_time_ms():
    """Forex madhe feed server time nahi - sthaniक ghadyal (NTP) vaparto."""

    return int(time.time() * 1000)


def refresh_time_offset():

    global TIME_OFFSET_MS

    # feed madhun time ghenyasarkha kahi nahi - offset 0 ठेवतो
    TIME_OFFSET_MS = 0


def now_ms():

    return int(time.time() * 1000) + TIME_OFFSET_MS


# ============================================================
# TELEGRAM
# ============================================================

def send_telegram(message):

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:

        print("Telegram configuration missing.", flush=True)

        return False

    url = (
        "https://api.telegram.org/bot"
        f"{TELEGRAM_BOT_TOKEN}/sendMessage"
    )

    try:

        response = requests.post(
            url,
            data={
                "chat_id": TELEGRAM_CHAT_ID,
                "text": message,
            },
            timeout=15,
        )

        response.raise_for_status()

        data = response.json()

        if data.get("ok"):
            return True

        print("Telegram error:", data.get("description"), flush=True)

        return False

    except Exception as e:

        print("Telegram request error:", e, flush=True)

        return False


def send_telegram_retry(message):

    for attempt in range(1, TELEGRAM_RETRIES + 1):

        if send_telegram(message):
            return True

        print(
            f"Telegram attempt {attempt}/{TELEGRAM_RETRIES} failed",
            flush=True,
        )

        if attempt < TELEGRAM_RETRIES:
            time.sleep(TELEGRAM_RETRY_DELAY)

    return False


# ============================================================
# ALERT FILE
# ============================================================

def load_sent_alerts():

    try:

        with open(ALERT_FILE, "r") as f:
            data = json.load(f)

        if isinstance(data, list):
            return set(data)

        print(
            "WARNING: alerts file madhe list nahi - rikami suruvat",
            flush=True,
        )

        return set()

    except FileNotFoundError:

        return set()

    except Exception as e:

        # fail aala tari scanner thambat nahi, fakt kalavतो
        print(
            "WARNING: alerts file vachta ala nahi (",
            e,
            ") - rikami suruvat. Junya dedupe mahiti milali nahi.",
            flush=True,
        )

        return set()


SENT_ALERTS = load_sent_alerts()


def save_sent_alerts():

    # ATOMIC write:
    # adhi .tmp madhe lihito, fsync karto, mag os.replace() ne
    # ekाच step madhe jaga badalto. Power gelा / process thambला
    # tari मूळ file kधीch adhiचya ar्धवट state madhe rahat nahi.
    tmp = ALERT_FILE + ".tmp"

    try:

        with open(tmp, "w") as f:

            json.dump(sorted(SENT_ALERTS), f, indent=2)

            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp, ALERT_FILE)

    except Exception as e:

        print("Alert file save error:", e, flush=True)

        try:
            os.path.exists(tmp) and os.remove(tmp)
        except Exception:
            pass


# ============================================================
# CLEANUP  (automatic, crash-safe)
# ============================================================

def parse_alert_key_ms(key):

    """Current-format key madhlा final_open_time (ms).

    Current format:  SYMBOL|timeframe|<ms>|Scanner N
    Itar konताही format => None (junya pidyेची key)
    """

    parts = key.split("|")

    if len(parts) != 4:
        return None

    try:
        value = int(parts[2])

    except (TypeError, ValueError):
        return None

    # karyakari epoch ms (2001 te 2033) - itar kाही tar aahe tar sodun द्या
    if not (10 ** 12 <= value <= 2 * 10 ** 12):
        return None

    return value


def alerts_file_size_kb():

    try:
        return os.path.getsize(ALERT_FILE) // 1024

    except Exception:
        return -1


def rss_mb():

    """Process ची memory (MB) - leak kalण्यासाठी"""

    try:

        with open("/proc/self/statm") as f:
            pages = int(f.read().split()[1])

        return (
            pages
            * os.sysconf("SC_PAGE_SIZE")
            // (1024 * 1024)
        )

    except Exception:

        return None


def market_is_open(ms=None):
    """Forex bazar ughada aahe ka? (सोम 04:30 IST ते शनि 04:00 IST)"""

    if ms is None:
        ms = now_ms()

    dt = datetime.fromtimestamp(ms / 1000, timezone.utc)

    weekday = dt.weekday()          # 0=som ... 6=ravi

    hour = dt.hour + dt.minute / 60.0

    if weekday == 5:                                    # shanivar - band
        return False

    if weekday == 4 and hour >= MARKET_CLOSE_FRIDAY_UTC_HOUR:
        return False

    if weekday == 6 and hour < MARKET_OPEN_SUNDAY_UTC_HOUR:
        return False

    return True


def market_just_opened(ms=None):
    """Bazar nekडach ughadला aahe ka? (watchdog grace)"""

    if ms is None:
        ms = now_ms()

    return (
        market_is_open(ms)
        and
        not market_is_open(ms - MARKET_OPEN_GRACE_SECONDS * 1000)
    )


def feed_is_stale(current_ms):

    """Price feed 5 minांपेksha jast thambला ka?

    Suravatी (pahila poll yetoच) false - grace.
    Bazar band asel (weekend) tar false - te त्रुटी nahi.
    """

    if not market_is_open(current_ms):
        return False

    if market_just_opened(current_ms):
        return False

    if POLL_COUNT == 0 or LAST_POLL_MS == 0:
        return False

    return (
        current_ms - LAST_POLL_MS
        >
        FEED_STALE_EXIT_SECONDS * 1000
    )


def free_disk_mb(path="."):

    try:
        st = os.statvfs(path)

        return (st.f_bavail * st.f_frsize) // (1024 * 1024)

    except Exception:
        return None


def prune_sent_alerts(current_ms, force=False, quiet=False):

    """Junya + jun्या format chya alert keys kadhून टाकतो.

    SURAKSHIT ka aahe:
      - ek key fakt tichya confirmation window madhe ekdach trigger
        hou shakto (max 4 tas). 30 divsांपेksha junya key kधीch
        punha lagat nahi.
      - jun्या pidyेच्या (3-part / text) keys aataच्या format shi
        kधीch jujat nahit - mhanun tya ekhi navin alert block
        karू shakat nahit.
      - prun mhanje fakt SET ("key aahe ka nahi") madhun kadणे.
        Tyaमुळे चूकीचा alert YET nahi.
      - ACTIVE_SETUPS la kाहीch hot nahi.
    """

    global LAST_PRUNE_MS

    if not force:

        if (
            LAST_PRUNE_MS
            and current_ms - LAST_PRUNE_MS
            < PRUNE_INTERVAL_SECONDS * 1000
        ):
            return 0

    LAST_PRUNE_MS = current_ms

    cutoff = current_ms - ALERT_RETENTION_DAYS * 86400 * 1000

    with LOCK:

        if not SENT_ALERTS:
            return 0

        keep = set()
        dropped_old = 0
        dropped_legacy = 0

        for key in SENT_ALERTS:

            stamp = parse_alert_key_ms(key)

            if stamp is None:
                dropped_legacy += 1
                continue

            if stamp < cutoff:
                dropped_old += 1
                continue

            keep.add(key)

        removed = len(SENT_ALERTS) - len(keep)

        if removed:

            # prथमच prun madhe ekdach junी file japun theवतो
            if not os.path.exists(BACKUP_FILE):

                try:
                    with open(BACKUP_FILE, "w") as f:
                        json.dump(sorted(SENT_ALERTS), f, indent=2)

                    if not quiet:
                        print(
                            "alerts backup thevला:",
                            BACKUP_FILE,
                            flush=True,
                        )

                except Exception as e:

                    print("Backup error:", e, flush=True)

            SENT_ALERTS.clear()
            SENT_ALERTS.update(keep)

            save_sent_alerts()

        if not quiet and removed:

            print(
                "ALERTS FILE PRUNED:",
                f"{removed} junya keys kadhlya",
                f"(jun्या format: {dropped_legacy},",
                f"{ALERT_RETENTION_DAYS} divsांpeksha juni: {dropped_old})",
                f"| urल्या: {len(keep)}",
                flush=True,
            )

    return removed


def cleanup_temp_files():

    try:

        tmp = ALERT_FILE + ".tmp"

        if os.path.exists(tmp):
            os.remove(tmp)
            print("stale temp file kadhली:", tmp, flush=True)

    except Exception as e:

        print("temp cleanup error:", e, flush=True)


# ============================================================
# SYMBOLS
# ============================================================

def fetch_active_symbols():
    """आपली 28 instruments. (Binance sarkhi exchangeInfo list nahi -

    forex madhe यादी ठरलेली असते, म्हणून तीच वापरतो.)
    """

    return list(FOREX_PAIRS)


# ============================================================
# BIQUOTE FEED   (मुख्य feed — MT5 live quotes, key नाही)
# ============================================================

_BIQUOTE_LOCK = threading.Lock()
_LAST_BIQUOTE_MS = 0.0
BIQUOTE_ERRORS = 0
BIQUOTE_LAST_ERROR = ""


def biquote_get(path, params=None, timeout=20):
    """biquote.io sathi EKACH darवaja : rate limit + punha prayatna."""

    global _LAST_BIQUOTE_MS, BIQUOTE_ERRORS, BIQUOTE_LAST_ERROR

    url = path if path.startswith("http") else f"{BIQUOTE_BASE}{path}"

    last_error = None

    for attempt in range(BIQUOTE_RETRIES):

        with _BIQUOTE_LOCK:

            wait = BIQUOTE_MIN_GAP - (time.time() - _LAST_BIQUOTE_MS)

            if wait > 0:
                time.sleep(wait)

            _LAST_BIQUOTE_MS = time.time()

        try:

            response = get_session().get(url, params=params, timeout=timeout)

            status = getattr(response, "status_code", 200)

            if status == 200:

                return response.json()

            last_error = f"HTTP {status}"

            if status in (429, 500, 502, 503, 504):

                time.sleep(BIQUOTE_BACKOFF[min(attempt, len(BIQUOTE_BACKOFF) - 1)])

                continue

            break

        except Exception as e:

            last_error = str(e)

            time.sleep(BIQUOTE_BACKOFF[min(attempt, len(BIQUOTE_BACKOFF) - 1)])

    BIQUOTE_ERRORS += 1

    BIQUOTE_LAST_ERROR = str(last_error)

    raise RuntimeError(f"biquote: {last_error}")


def parse_iso_ms(text):
    """'2026-09-28T05:30:00Z' -> epoch milliseconds."""

    if not text:
        return None

    try:

        return int(datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp() * 1000)

    except Exception:

        return None


def interval_ms_of(interval):
    """'5m' -> 300000 · '1h' -> 3600000 · '1d' -> 86400000"""

    number = int(interval[:-1])

    unit = interval[-1]

    if unit == "m":
        return number * 60 * 1000

    if unit == "h":
        return number * 60 * 60 * 1000

    if unit == "d":
        return number * 24 * 60 * 60 * 1000

    raise ValueError(f"mahit nahi asa interval: {interval}")


def candles_from_biquote(payload, bar_ms, current, limit=None):
    """biquote chya bars -> aapल्या candles (fakt PURN झालेल्या, jun्या -> nav्या)."""

    rows = []

    for bar in (payload.get("bars") or []):

        if bar.get("isOpen"):                 # चालू मेणबत्ती नको
            continue

        open_time = parse_iso_ms(bar.get("openTime"))

        if open_time is None:
            continue

        close_time = open_time + bar_ms - 1

        if close_time >= current:             # अजून पूर्ण झाली नाही
            continue

        o = bar.get("open")
        h = bar.get("high")
        l = bar.get("low")
        c = bar.get("close")

        if None in (o, h, l, c):
            continue

        rows.append({
            "open_time": open_time,
            "open": float(o),
            "high": float(h),
            "low": float(l),
            "close": float(c),
            "close_time": close_time,
        })

    rows.sort(key=lambda x: x["open_time"])

    if limit:
        rows = rows[-limit:]

    return rows


def biquote_candles(symbol, interval="5m", limit=KLINE_LIMIT, current=None):
    """एका pair chya मेणबत्त्या (biquote)."""

    data = biquote_get(f"/{symbol}/ohlc", params={"interval": interval, "limit": limit})

    if current is None:
        current = now_ms()

    return candles_from_biquote(data, interval_ms_of(interval), current, limit)


def biquote_price(symbol):
    """एका pair chi taazі किंमत (mid). Juna/stale asel tar None."""

    data = biquote_get(f"/{symbol}")

    if data.get("stale"):
        return None

    age = data.get("quoteAgeSeconds")

    if age is not None and age > BIQUOTE_STALE_SECONDS:
        return None

    mid = data.get("mid")

    if not mid:

        bid = data.get("bid")
        ask = data.get("ask")

        mid = (bid + ask) / 2.0 if (bid and ask) else None

    return float(mid) if mid else None


# ============================================================
# CANDLES
# ============================================================

def fetch_all_base_candles(symbols=None):
    """सगळ्या symbols chya BASE (5m) candles — feed नुसार."""

    if symbols is None:

        symbols = sorted(ACTIVE_SYMBOLS) if ACTIVE_SYMBOLS else sorted(FOREX_PAIRS)

    names = sorted(symbols)

    out = {}

    current = now_ms()

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:

        jobs = {
            executor.submit(biquote_candles, name, BASE_INTERVAL, KLINE_LIMIT, current): name
            for name in names
        }

        for future in as_completed(jobs):

            name = jobs[future]

            try:

                candles = future.result()

            except Exception as e:

                print("candle error:", name, e, flush=True)

                continue

            if candles:
                out[name] = candles

    return out


def fetch_closed_base_candles(symbol):
    """एका pair chya PURN झालेल्या BASE (5m) candles — biquote."""

    return biquote_candles(symbol, BASE_INTERVAL, KLINE_LIMIT)


def aggregate_candles(base_candles, minutes):

    group_ms = minutes * 60 * 1000

    grouped = {}

    for candle in base_candles:

        bucket = (candle["open_time"] // group_ms) * group_ms

        grouped.setdefault(bucket, []).append(candle)

    result = []

    required_parts = minutes // BASE_GRID_MINUTES

    for bucket, parts in grouped.items():

        parts.sort(key=lambda x: x["open_time"])

        if len(parts) != required_parts:
            continue

        expected = [
            bucket + i * BASE_INTERVAL_MS
            for i in range(required_parts)
        ]

        actual = [x["open_time"] for x in parts]

        if actual != expected:
            continue

        result.append({
            "open_time": bucket,
            "open": parts[0]["open"],
            "high": max(x["high"] for x in parts),
            "low": min(x["low"] for x in parts),
            "close": parts[-1]["close"],
            "close_time": bucket + group_ms - 1,
        })

    result.sort(key=lambda x: x["open_time"])

    return result


# ============================================================
# CANDLE HELPERS
# ============================================================

def candle_body_ratio(candle):

    candle_range = candle["high"] - candle["low"]

    if candle_range <= 0:
        return 0.0

    return abs(candle["close"] - candle["open"]) / candle_range


def close_position(candle):

    candle_range = candle["high"] - candle["low"]

    if candle_range <= 0:
        return None

    return (candle["close"] - candle["low"]) / candle_range


# ============================================================
# SCANNERS 1-4  (v1 sarkhech - kaलेलाच logic)
# ============================================================

def scanner_result(first, second, final_candle, previous=None):

    final_position = close_position(final_candle)

    if final_position is None:
        return None

    # INDICATOR नियम (momentum खांब) — दोन्ही नियम झाले तरच alert.
    momentum_pass = momentum_ok(previous, first, second)

    # --- Scanner 1 : Bearish Reversal ------------------------
    scanner_1 = (
        first["close"] > first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] < second["open"]
        and second["high"] < first["high"]
        and second["low"] > first["low"]
        and final_position <= CLOSE_LOW_THRESHOLD
        and momentum_pass
    )

    if scanner_1:

        return {
            "scanner": "Scanner 1",
            "direction": "Bearish Reversal",
            "condition": "Scanner 1 - Bearish Reversal",
            "position": final_position,
        }

    # --- Scanner 2 : Bullish Reversal ------------------------
    scanner_2 = (
        first["close"] < first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] > second["open"]
        and second["high"] < first["high"]
        and second["low"] > first["low"]
        and final_position >= CLOSE_HIGH_THRESHOLD
        and momentum_pass
    )

    if scanner_2:

        return {
            "scanner": "Scanner 2",
            "direction": "Bullish Reversal",
            "condition": "Scanner 2 - Bullish Reversal",
            "position": final_position,
        }

    # --- Scanner 3 : Bearish (high break) -------------------
    scanner_3 = (
        first["close"] > first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] < second["open"]
        and second["high"] > first["high"]
        and second["low"] > first["low"]
        and final_position <= CLOSE_LOW_THRESHOLD
        and momentum_pass
    )

    if scanner_3:

        return {
            "scanner": "Scanner 3",
            "direction": "Bearish Reversal",
            "condition": "Scanner 3 - High Break Bearish Reversal",
            "position": final_position,
        }

    # --- Scanner 4 : Bullish (low break) --------------------
    scanner_4 = (
        first["close"] < first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] > second["open"]
        and second["low"] < first["low"]
        and second["high"] < first["high"]
        and final_position >= CLOSE_HIGH_THRESHOLD
        and momentum_pass
    )

    if scanner_4:

        return {
            "scanner": "Scanner 4",
            "direction": "Bullish Reversal",
            "condition": "Scanner 4 - Low Break Bullish Reversal",
            "position": final_position,
        }

    return None


# ============================================================
# SETUP DETECTION
# ============================================================

def detect_setup(base_candles, timeframe):

    component_minutes = TIMEFRAMES[timeframe]
    tf_final_minutes = final_minutes(timeframe)      # '10m' -> 10, '8h' -> 480

    component_candles = aggregate_candles(base_candles, component_minutes)
    final_candles = aggregate_candles(base_candles, tf_final_minutes)

    if not final_candles:
        return None

    final_candle = final_candles[-1]
    final_start = final_candle["open_time"]
    final_end = final_start + tf_final_minutes * 60 * 1000

    parts = [
        c for c in component_candles
        if final_start <= c["open_time"] < final_end
    ]

    if len(parts) != 2:
        return None

    parts.sort(key=lambda x: x["open_time"])

    first, second = parts[0], parts[1]

    # INDICATOR नियमासाठी : 1ल्याच्या *आधी*ची component मेणबत्ती (m0).
    # ती न सापडली तर (data मध्ये खाली) m0 = 0 धरली जाते.
    previous = None

    for candle in component_candles:

        if candle["open_time"] == first["open_time"] - component_minutes * 60 * 1000:

            previous = candle
            break

    result = scanner_result(first, second, final_candle, previous)

    if result is None:
        return None

    confirmation_start = final_end
    confirmation_end = (
        confirmation_start
        +
        component_minutes * 60 * 1000
    )

    return {
        "scanner": result["scanner"],
        "direction": result["direction"],
        "condition": result["condition"],
        "position": result["position"],
        "previous": previous,
        "first": first,
        "second": second,
        "final": final_candle,
        "confirmation_start": confirmation_start,
        "confirmation_end": confirmation_end,
        "confirmation_high": None,
        "confirmation_low": None,
    }


# ============================================================
# TIME FORMAT
# ============================================================

def format_ist(timestamp_ms):

    dt = datetime.fromtimestamp(
        timestamp_ms / 1000,
        timezone.utc,
    ).astimezone(IST)

    return dt.strftime("%d-%m-%Y %H:%M:%S IST")


# ============================================================
# ALERT MESSAGE
# ============================================================

def make_alert(symbol, timeframe, setup, current_price, event_time):

    final = setup["final"]
    first = setup["first"]
    second = setup["second"]

    position_percent = setup["position"] * 100

    # INDICATOR नियम (momentum खांब) चे आकडे
    _m_prev = setup.get("previous")
    _s1, _s2 = momentum_sticks(_m_prev, first, second)
    _ratio = momentum_ratio(_m_prev, first, second)
    momentum_line = (
        f"Momentum (len {MOMENTUM_LENGTH}): "
        f"1st {candle_momentum(first):+.4f}  ->  2nd {candle_momentum(second):+.4f}"
        f"  |  sticks {_s1:+.4f} / {_s2:+.4f}"
        f"  =  {'--' if _ratio is None else f'{_ratio:.2f}x'}"
        f" (niyam: >= {MOMENTUM_MULTIPLIER:.2f}x)"
        f"{'' if _m_prev is not None else '  [previous nahi - s1 = 1st chi value]'}"
    )

    if setup["direction"] == "Bearish Reversal":

        close_rule = f"Close <= {CLOSE_LOW_THRESHOLD * 100:.0f}% from Low"
        break_rule = "Running Low < 2nd Candle Low"

    else:

        close_rule = f"Close >= {CLOSE_HIGH_THRESHOLD * 100:.0f}% from Low"
        break_rule = "Running High > 2nd Candle High"

    confirmation_high = (
        setup["confirmation_high"]
        if setup["confirmation_high"] is not None
        else current_price
    )

    confirmation_low = (
        setup["confirmation_low"]
        if setup["confirmation_low"] is not None
        else current_price
    )

    message = (

        "🚨 BINANCE FUTURES LIVE ALERT\n"
        "\n"
        f"Pair: {symbol}\n"
        f"Timeframe: {timeframe}\n"
        f"{setup['scanner']} - {setup['direction']}\n"
        "\n"
        f"Close Position: {position_percent:.2f}%\n"
        f"Rule: {close_rule}\n"
        f"Confirmation: {break_rule}\n"
        f"{momentum_line}\n"
        "\n"
        f"Final Open: {final['open']}\n"
        f"Final High: {final['high']}\n"
        f"Final Low: {final['low']}\n"
        f"Final Close: {final['close']}\n"
        "\n"
        f"1st Candle Open: {first['open']}\n"
        f"1st Candle High: {first['high']}\n"
        f"1st Candle Low: {first['low']}\n"
        f"1st Candle Close: {first['close']}\n"
        f"1st Body: {candle_body_ratio(first) * 100:.2f}%\n"
        "\n"
        f"2nd Candle Open: {second['open']}\n"
        f"2nd Candle High: {second['high']}\n"
        f"2nd Candle Low: {second['low']}\n"
        f"2nd Candle Close: {second['close']}\n"
        "\n"
        f"Running Confirmation High: {confirmation_high}\n"
        f"Running Confirmation Low: {confirmation_low}\n"
        f"Break Price: {current_price}\n"
        f"Break Time: {format_ist(event_time)}\n"
        "\n"
        f"Final Closed: {format_ist(final['close_time'] + 1)}"
    )

    return message


# ============================================================
# SETUP BOOKKEEPING
# ============================================================

def setup_key(symbol, timeframe, setup):

    return (
        f"{symbol}|"
        f"{timeframe}|"
        f"{setup['final']['open_time']}|"
        f"{setup['scanner']}"
    )


def setup_is_bearish(setup):

    return setup["direction"] == "Bearish Reversal"


def setup_level(setup):
    """Alert ची हद्द (trigger level).

    v7 नियम : **2ऱ्या (शेवटच्या) component मेणबत्तीचा** low (bearish साठी)
    किंवा high (bullish साठी). आधी हा 'final' (दोनी एकत्र) मेणबत्तीचा होता.
    """

    second = setup.get("second") or {}

    if setup_is_bearish(setup):

        level = second.get("low")

        if level is not None:
            return level

        return setup["final"]["low"]

    level = second.get("high")

    if level is not None:
        return level

    return setup["final"]["high"]


def register_setup(symbol, timeframe, setup):

    key = setup_key(symbol, timeframe, setup)

    with LOCK:

        if key in ACTIVE_SETUPS:
            return False

        if key in SENT_ALERTS:
            return False

        ACTIVE_SETUPS[key] = {
            **setup,
            "symbol": symbol,
            "timeframe": timeframe,
            "key": key,
            "send_attempts": 0,
            "last_attempt_ms": 0,
        }

    print(
        "SETUP REGISTERED:",
        symbol,
        timeframe,
        setup["scanner"],
        setup["direction"],
        "| Confirmation:",
        format_ist(setup["confirmation_start"]),
        "to",
        format_ist(setup["confirmation_end"]),
        flush=True,
    )

    return True


def cleanup_expired_setups(current_ms, quiet=False):

    expired = []

    with LOCK:

        for key, setup in ACTIVE_SETUPS.items():

            if current_ms >= setup["confirmation_end"]:
                expired.append(key)

        for key in expired:

            setup = ACTIVE_SETUPS.pop(key, None)

            if setup and not quiet:

                print(
                    "SETUP EXPIRED:",
                    setup["symbol"],
                    setup["timeframe"],
                    setup["scanner"],
                    flush=True,
                )

    return expired


# ============================================================
# ALERT DELIVERY
#
# KEY v2 badal: Telegram YASHASWI zalyavarach key sathavli jate
# आणि setup kadla jato. Fail zala tar setup chalu rahto.
# ============================================================

def deliver_alert(key, price, event_time):

    global ALERTS_SENT_COUNT

    with LOCK:

        current = ACTIVE_SETUPS.get(key)

        if current is None:
            return

        setup = dict(current)

        # khup velat punha punha prayatna karu naye
        if setup["send_attempts"] >= MAX_SEND_ATTEMPTS:
            return

        # adhiच्या fail nantar thodा वेळ थांबा
        # (pahिला prayatna cooldown mule thambu naye)
        if (
            setup["send_attempts"] > 0
            and
            event_time - setup["last_attempt_ms"]
            <
            SEND_RETRY_COOLDOWN_MS
        ):
            return

        current["last_attempt_ms"] = event_time
        current["send_attempts"] = setup["send_attempts"] + 1

    message = make_alert(
        setup["symbol"],
        setup["timeframe"],
        setup,
        price,
        event_time,
    )

    print()
    print(
        "🚨 ALERT:",
        setup["symbol"],
        setup["timeframe"],
        setup["scanner"],
        price,
        "|",
        format_ist(event_time),
        flush=True,
    )

    if TEST_MODE:

        print("TEST MODE: Telegram alert suppressed", flush=True)

        sent = True

    elif DRY_RUN:

        print("DRY RUN: Telegram pathवla nahi (nond thevली nahi)", flush=True)

        return

    else:

        sent = send_telegram_retry(message)

    with LOCK:

        if sent:

            SENT_ALERTS.add(key)
            ACTIVE_SETUPS.pop(key, None)
            save_sent_alerts()

            ALERTS_SENT_COUNT += 1

        else:

            print(
                "TELEGRAM FAILED - alert haravla nahi; setup chalu",
                "(pudhchya tika la punha prayatna hoil):",
                setup["symbol"],
                setup["timeframe"],
                flush=True,
            )

    if sent:

        print(
            "✅ ALERT DELIVERED:",
            setup["symbol"],
            setup["timeframe"],
            setup["scanner"],
            flush=True,
        )


# ============================================================
# PRICE -> TRIGGER CHECK
#
# Ek price gheun sagळ्या active setups tapatasat.
# ============================================================

def update_extremes(setup, price):

    if setup["confirmation_high"] is None:

        setup["confirmation_high"] = price
        setup["confirmation_low"] = price

    else:

        setup["confirmation_high"] = max(
            setup["confirmation_high"],
            price,
        )

        setup["confirmation_low"] = min(
            setup["confirmation_low"],
            price,
        )


def process_prices(prices, event_time):

    triggered = []

    cleanup_expired_setups(event_time, quiet=True)

    with LOCK:

        for key, setup in list(ACTIVE_SETUPS.items()):

            price = prices.get(setup["symbol"])

            if price is None:
                continue

            if not (
                setup["confirmation_start"]
                <= event_time
                <
                setup["confirmation_end"]
            ):
                continue

            update_extremes(setup, price)

            level = setup_level(setup)

            if setup_is_bearish(setup):

                if price < level:
                    triggered.append((key, price))

            else:

                if price > level:
                    triggered.append((key, price))

    for key, price in triggered:

        deliver_alert(key, price, event_time)


def process_price(symbol, price, event_time):

    process_prices({symbol: price}, event_time)


# ============================================================
# PRICE FEED (REST polling)
# ============================================================

def fetch_all_prices():
    """सगळ्या instruments chya taaz्या किमती — biquote (mid)."""

    names = sorted(ACTIVE_SYMBOLS) if ACTIVE_SYMBOLS else sorted(FOREX_PAIRS)

    prices = {}

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:

        jobs = {executor.submit(biquote_price, name): name for name in names}

        for future in as_completed(jobs):

            name = jobs[future]

            try:

                price = future.result()

            except Exception as e:

                print("price error:", name, e, flush=True)

                continue

            if price:
                prices[name] = price

    return prices


def price_loop():

    global POLL_COUNT, LAST_POLL_MS, LAST_PRICE_COUNT, LAST_POLL_ERROR

    while True:

        started = time.time()

        # ---- bazar band? tar poll karycha nahi ----------------
        if not market_is_open():

            if now_ms() - MARKET_NOTICE["ms"] > 3600 * 1000:

                MARKET_NOTICE["ms"] = now_ms()

                print(
                    "MARKET BAND: forex bazar band aahe - scanner shant aahe"
                    " (somvari 04:30 IST la punha suru hoil)",
                    flush=True,
                )

            time.sleep(60.0)

            continue

        try:

            prices = fetch_all_prices()

            if prices:

                LAST_POLL_MS = now_ms()
                LAST_POLL_ERROR = None
                POLL_COUNT += 1
                LAST_PRICE_COUNT = len(prices)

                PRICE_CACHE.update(prices)

                process_prices(prices, LAST_POLL_MS)

        except Exception as e:

            LAST_POLL_ERROR = str(e)

            print("PRICE POLL ERROR:", e, flush=True)

        duration = time.time() - started

        time.sleep(max(0.2, POLL_INTERVAL - duration))


# ============================================================
# WICK INSURANCE : running confirmation candle cha 1m data
# ============================================================

def fetch_1m_candles(symbol, start_ms, current_ms):
    """1m candles (sweep साठी) — biquote. फक्त high/low पुरेसं."""

    rows = biquote_candles(symbol, "1m", SWEEP_KLINE_LIMIT, current_ms)

    return [
        {"open_time": c["open_time"], "high": c["high"], "low": c["low"]}
        for c in rows
        if c["open_time"] + 60 * 1000 > start_ms
    ]


def sweep_symbol(key, setup):

    current_s = int(time.time())

    start_ms = max(
        setup["confirmation_start"],
        (current_s - SWEEP_LOOKBACK_MINUTES * 60) * 1000,
    )

    try:

        candles = fetch_1m_candles(setup["symbol"], start_ms, now_ms())

    except Exception as e:

        print("sweep error:", setup["symbol"], e, flush=True)

        return

    if not candles:
        return

    current = now_ms()

    with LOCK:

        live = ACTIVE_SETUPS.get(key)

        if live is None:
            return

        if not (
            live["confirmation_start"]
            <= current
            <
            live["confirmation_end"]
        ):
            return

        high = max(c["high"] for c in candles)
        low = min(c["low"] for c in candles)

        if live["confirmation_high"] is None:

            live["confirmation_high"] = high
            live["confirmation_low"] = low

        else:

            live["confirmation_high"] = max(live["confirmation_high"], high)
            live["confirmation_low"] = min(live["confirmation_low"], low)

        bearish = setup_is_bearish(live)
        level = setup_level(live)

    hit = None

    for candle in candles:

        if bearish:

            if candle["low"] < level:
                hit = (candle["open_time"], candle["low"])
                break

        else:

            if candle["high"] > level:
                hit = (candle["open_time"], candle["high"])
                break

    if hit is not None:

        deliver_alert(key, hit[1], hit[0])


def do_kline_sweep():

    # bazar band asel tar sweep karycha nahi
    if not market_is_open():
        return

    with LOCK:

        setups = [
            (key, dict(setup))
            for key, setup in ACTIVE_SETUPS.items()
        ]

    if not setups:
        return

    def distance(item):

        key, setup = item

        price = PRICE_CACHE.get(setup["symbol"])

        if price is None:
            return 9e9

        level = setup_level(setup)

        if level <= 0:
            return 9e9

        return abs(price - level) / level

    setups.sort(key=distance)

    setups = setups[:SWEEP_MAX_SETUPS]

    with ThreadPoolExecutor(max_workers=SWEEP_WORKERS) as executor:

        futures = [
            executor.submit(sweep_symbol, key, setup)
            for key, setup in setups
        ]

        for future in as_completed(futures):

            try:
                future.result()

            except Exception as e:

                print("Sweep error:", e, flush=True)


def sweep_loop():

    global SWEEP_COUNT, LAST_SWEEP_MS

    while True:

        time.sleep(SWEEP_INTERVAL)

        try:

            do_kline_sweep()

            SWEEP_COUNT += 1
            LAST_SWEEP_MS = now_ms()

        except Exception as e:

            print("Sweep loop error:", e, flush=True)


# ============================================================
# HEARTBEAT  (जिवंतपणाचा पुरावा)
# ============================================================

def heartbeat_loop():

    while True:

        time.sleep(HEARTBEAT_SECONDS)

        try:

            refresh_time_offset()

            with LOCK:

                setups = len(ACTIVE_SETUPS)

                closest = None
                closest_gap = None

                for setup in ACTIVE_SETUPS.values():

                    price = PRICE_CACHE.get(setup["symbol"])

                    if price is None:
                        continue

                    level = setup_level(setup)

                    if level <= 0:
                        continue

                    gap = abs(price - level) / level * 100

                    if closest_gap is None or gap < closest_gap:

                        closest_gap = gap
                        closest = setup

            poll_age = (
                (now_ms() - LAST_POLL_MS) / 1000
                if LAST_POLL_MS
                else -1
            )

            sweep_age = (
                (now_ms() - LAST_SWEEP_MS) / 1000
                if LAST_SWEEP_MS
                else -1
            )

            line = (
                f"HEARTBEAT | polls {POLL_COUNT}"
                f" | prices {LAST_PRICE_COUNT}"
                f" | active setups {setups}"
                f" | alerts sent {ALERTS_SENT_COUNT}"
                f" | market {'OPEN' if market_is_open() else 'CLOSED'}"
                f" | last poll {poll_age:.1f}s ago"
                f" | last sweep {sweep_age:.1f}s ago"
            )

            # disk ani alerts file cha aकार (crash prevention)
            disk = free_disk_mb()

            if disk is not None:

                line += f" | disk {disk}MB free"

                if disk < LOW_DISK_MB:
                    line += "  <-- LOW DISK!"

            mem = rss_mb()

            if mem is not None:
                line += f" | rss {mem}MB"

            size_kb = alerts_file_size_kb()

            if size_kb >= 0:
                line += f" | alerts file {size_kb}KB ({len(SENT_ALERTS)} keys)"

            if closest is not None:

                line += (
                    f" | closest: {closest['symbol']} "
                    f"{closest['timeframe']} "
                    f"{closest_gap:.2f}% away"
                )

            if LAST_POLL_ERROR:

                line += f" | LAST POLL ERROR: {LAST_POLL_ERROR}"

            print(line, flush=True)

            # ---- WATCHDOG ----------------------------------
            # feed khup vel थांबला tar process band karto;
            # systemd Restart=always mule punha lagech suru hoto
            # (startup scan mule jivant setups punha register hotat).
            if feed_is_stale(now_ms()):

                stale = (now_ms() - LAST_POLL_MS) / 1000

                print(
                    f"WATCHDOG: price feed {stale:.0f}s thambla -",
                    "process band karto; systemd punha suru karel",
                    flush=True,
                )

                os._exit(1)

        except Exception as e:

            print("Heartbeat error:", e, flush=True)


# ============================================================
# SCANNING
# ============================================================

def scan_symbol(symbol, timeframes, candles=None):

    try:

        if candles is None:

            candles = fetch_closed_base_candles(symbol)

        results = []

        for timeframe in timeframes:

            setup = detect_setup(candles, timeframe)

            if setup is None:
                continue

            if register_setup(symbol, timeframe, setup):

                results.append((timeframe, setup["scanner"]))

        return symbol, results

    except Exception as e:

        return symbol, [("ERROR", str(e))]


def scan_all(timeframes):

    if not ACTIVE_SYMBOLS:
        return

    symbols = sorted(ACTIVE_SYMBOLS)

    print()
    print("==========================================")
    print("SETUP SCAN")
    print(
        datetime.now(IST).strftime("%d-%m-%Y %H:%M:%S"),
        "IST",
    )
    print("Symbols:", len(symbols))
    print("Timeframes:", ", ".join(timeframes))
    print("==========================================")

    found = 0

    # ---- sagle candles EKACH call madhe (Yahoo var कमी load) ----
    try:

        batch = fetch_all_base_candles(symbols)

        print(
            "Candles mile:",
            f"{len(batch)}/{len(symbols)} symbols (1 call)",
            flush=True,
        )

    except Exception as e:

        print("Batch candle error:", e, "-> vegveळ्या calls vaparto", flush=True)

        batch = {}

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:

        futures = [
            executor.submit(scan_symbol, symbol, timeframes, batch.get(symbol))
            for symbol in symbols
        ]

        for future in as_completed(futures):

            try:

                symbol, results = future.result()

                for timeframe, scanner in results:

                    if timeframe == "ERROR":

                        print("SCAN ERROR:", symbol, scanner, flush=True)
                        continue

                    found += 1

                    print("MATCH:", symbol, timeframe, scanner, flush=True)

            except Exception as e:

                print("Worker result error:", e, flush=True)

    print(
        "Setup scan complete. New setups:",
        found,
        flush=True,
    )


def due_timeframes(server_ms):
    """कोणत्या finals ची मेणबत्ती आत्ता बंद झाली.

    05:30 IST = 00:00 UTC anchor — 10m ते 8h सगळ्या त्याच जाळीवर बसतात.
    """

    dt = datetime.fromtimestamp(server_ms / 1000, timezone.utc)

    if dt.minute % BASE_GRID_MINUTES != 0:
        return []

    # मेणबत्ती बंद झाल्यावर थोडा वेळ थांबून scan (feed ला वेळ द्यायला)
    if dt.second < SCAN_DELAY_SECONDS:
        return []

    boundary = server_ms - (dt.second * 1000 + dt.microsecond // 1000)

    due = []

    for timeframe in TIMEFRAMES:

        step = final_minutes(timeframe) * 60 * 1000

        if boundary % step == 0:
            due.append(timeframe)

    return due


def startup_timeframes(base_candles, current_ms):

    result = []

    for timeframe in TIMEFRAMES:

        component_minutes = TIMEFRAMES[timeframe]
        tf_final_minutes = final_minutes(timeframe)

        final_candles = aggregate_candles(base_candles, tf_final_minutes)

        if not final_candles:
            continue

        final_candle = final_candles[-1]

        final_end = (
            final_candle["open_time"]
            +
            tf_final_minutes * 60 * 1000
        )

        confirmation_end = (
            final_end
            +
            component_minutes * 60 * 1000
        )

        if not (final_end <= current_ms < confirmation_end):
            continue

        parts = [
            c
            for c in aggregate_candles(base_candles, component_minutes)
            if (
                final_candle["open_time"]
                <= c["open_time"]
                <
                final_end
            )
        ]

        if len(parts) != 2:
            continue

        result.append(timeframe)

    return result


def compute_startup_timeframes(base_candles, current_ms):

    due = startup_timeframes(base_candles, current_ms)

    if due:
        return due

    return due_timeframes(current_ms)


# ============================================================
# TESTS
# ============================================================

def make_candle(open_, high, low, close, open_time=0):

    return {
        "open_time": open_time,
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "close_time": open_time + 1,
    }


PASS = 0
FAIL = 0


def self_test():

    print("Running Scanner 1-4 tests...")

    # वरची मेणबत्ती (m0) — खांब 1 = m1 - m0  (m1 = 1ली ची value)
    PREV_BEAR = make_candle(100, 110, 99, 108.70)     # m0 = +8.70  -> खांब 1 = +0.30
    PREV_BULL = make_candle(110, 111, 99, 100.70)     # m0 = -9.30  -> खांब 1 = -0.70

    # Scanner 1  (खांब 2 = -12.00 = 40x)
    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(106, 108, 102, 103),
        make_candle(103, 104, 100, 101),
        PREV_BEAR,
    )["scanner"] == "Scanner 1"

    # Scanner 2
    assert scanner_result(
        make_candle(110, 111, 99, 100),
        make_candle(101, 107, 100, 106),
        make_candle(104, 110, 100, 109),
        PREV_BULL,
    )["scanner"] == "Scanner 2"

    # Scanner 3
    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(108, 112, 103, 104),
        make_candle(104, 105, 100, 101),
        PREV_BEAR,
    )["scanner"] == "Scanner 3"

    # Scanner 4
    assert scanner_result(
        make_candle(110, 111, 99, 100),
        make_candle(101, 103, 97, 102),
        make_candle(104, 110, 100, 109),
        PREV_BULL,
    )["scanner"] == "Scanner 4"

    # strict equality -> reject (खांब नियम जुळतो, पण आकार जुळत नाही)
    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(106, 110, 102, 103),
        make_candle(103, 104, 100, 101),
        PREV_BEAR,
    ) is None

    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(108, 112, 99, 104),
        make_candle(104, 105, 100, 101),
        PREV_BEAR,
    ) is None

    # INDICATOR : खांब जुळला नाही तर setup नाही (तोच आकार, फक्त मागची बदलली)
    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(106, 108, 102, 103),
        make_candle(103, 104, 100, 101),
        make_candle(100, 110, 99, 101),      # m0 = +1.00 -> खांब 1 = +8.00 -> 3x नाही
    ) is None

    # live bearish breakout
    setup = {
        "direction": "Bearish Reversal",
        "final": {
            "open": 109,
            "high": 110,
            "low": 100,
            "close": 105.5,
            "close_time": 999,
        },
        "confirmation_start": 0,
        "confirmation_end": 9999999999999,
        "confirmation_high": None,
        "confirmation_low": None,
        "position": 0.55,
        "first": {
            "open": 110, "high": 111, "low": 99, "close": 110.5,
        },
        "second": {
            "open": 110.5, "high": 110.8, "low": 105, "close": 105.5,
        },
    }

    key = "TESTUSDT|1h|1|Scanner 1"

    with LOCK:

        ACTIVE_SETUPS.clear()
        SENT_ALERTS.discard(key)

        ACTIVE_SETUPS[key] = {
            **setup,
            "symbol": "TESTUSDT",
            "timeframe": "1h",
            "scanner": "Scanner 1",
            "key": key,
            "send_attempts": 0,
            "last_attempt_ms": 0,
        }

    # पातळी = 2ऱ्या मेणबत्तीचा तळ (105) — final चा तळ (100) नाही
    assert setup_level(ACTIVE_SETUPS[key]) == 105

    # touch -> trigger nahi
    process_price("TESTUSDT", 105.0, 1000)
    assert key in ACTIVE_SETUPS

    # 2री ची पातळी तुटली -> trigger  (आणि हे 100 च्या वर आहे :
    # जुन्या 'final' नियमानं इथे alert आला नसता)
    process_price("TESTUSDT", 104.99, 1000)
    assert key not in ACTIVE_SETUPS
    assert key in SENT_ALERTS

    print("Scanner 1 PASS")
    print("Scanner 2 PASS")
    print("Scanner 3 PASS")
    print("Scanner 4 PASS")
    print("Strict equality PASS")
    print("Strict breakout + dedupe PASS")

    # ========================================================
    # NAVIN BHAG : feed (biquote) + nave timeframes + 28 pairs
    # ========================================================

    global PASS, FAIL
    PASS = 0
    FAIL = 0

    def check(name, ok, extra=""):

        global PASS, FAIL

        if ok:
            PASS += 1
            print(f"  ✅ {name}" + (f"   {extra}" if extra else ""))
        else:
            FAIL += 1
            print(f"  ❌ {name}" + (f"   {extra}" if extra else ""))

    print()
    print("[9] PAIRS — 28 instruments")

    names = list(FOREX_PAIRS)

    check("एकूण 28", len(FOREX_PAIRS) == 28, f"{len(FOREX_PAIRS)}")

    WANT = ["GBPCHF", "EURCHF", "EURCAD", "GBPCAD", "GBPNZD", "AUDCHF", "GBPUSD", "AUDCAD",
            "EURUSD", "GBPAUD", "USDCHF", "NZDCHF", "EURAUD", "NZDCAD", "AUDNZD", "USDCAD",
            "AUDUSD", "CADCHF", "NZDUSD", "EURGBP", "XAUUSD", "GBPJPY", "EURJPY", "AUDJPY",
            "USDJPY", "NZDJPY", "CADJPY", "CHFJPY"]

    check("सगळी नावं जशी मागितली तशीच", names == WANT, f"{len(set(names))} वेगळी")

    check("fetch_active_symbols तीच यादी देतो",
          fetch_active_symbols() == WANT)

    print()
    print("[10] TIMEFRAMES — 10m व 30m ची भर")

    check("10m आहे (5m + 5m)", TIMEFRAMES.get("10m") == 5)
    check("30m आहे (15m + 15m)", TIMEFRAMES.get("30m") == 15)
    check("जुने तसेच आहेत",
          (TIMEFRAMES.get("1h"), TIMEFRAMES.get("2h"), TIMEFRAMES.get("4h"),
           TIMEFRAMES.get("8h")) == (30, 60, 120, 240))
    check("final_minutes() '10m' = 10", final_minutes("10m") == 10)
    check("final_minutes() '30m' = 30", final_minutes("30m") == 30)
    check("final_minutes() '1h' = 60", final_minutes("1h") == 60)
    check("final_minutes() '8h' = 480", final_minutes("8h") == 480)
    check("base candle 5m", BASE_INTERVAL == "5m" and BASE_INTERVAL_MS == 5 * 60 * 1000)

    print()
    print("[11] BIQUOTE — मेणबत्त्या वाचणं")

    payload = {"symbol": "EURUSD", "interval": "5m", "bars": [
        {"openTime": "2026-09-28T05:30:00Z", "open": 1.0, "high": 1.1, "low": 0.9,
         "close": 1.05, "isOpen": True},                       # चालू -> टाकायची नाही
        {"openTime": "2026-09-28T05:25:00Z", "open": 1.01, "high": 1.06, "low": 0.99,
         "close": 1.02, "isOpen": False},                      # नवी
        {"openTime": "2026-09-28T05:20:00Z", "open": 0.99, "high": 1.03, "low": 0.98,
         "close": 1.01, "isOpen": False},                      # जुनी
    ]}

    current = parse_iso_ms("2026-09-28T05:31:00Z")

    bars = candles_from_biquote(payload, 5 * 60 * 1000, current)

    check("चालू मेणबत्ती वगळली", len(bars) == 2, f"{len(bars)}")
    check("जुनी आधी, नवी शेवटी", bars[0]["open_time"] < bars[1]["open_time"])
    check("close_time = open + 5m - 1ms",
          bars[0]["close_time"] == bars[0]["open_time"] + 5 * 60 * 1000 - 1)
    check("OHLC जसेच", (bars[1]["open"], bars[1]["high"], bars[1]["low"], bars[1]["close"])
          == (1.01, 1.06, 0.99, 1.02))
    check("limit लागू", len(candles_from_biquote(payload, 300000, current, limit=1)) == 1)

    empty = candles_from_biquote({"bars": []}, 300000, current)
    check("रिकामा data चालतो", empty == [])

    print()
    print("[12] BIQUOTE — किंमत वाचणं")

    real_get = biquote_get

    def fake_live(path, params=None, timeout=20):
        return {"symbol": "EURUSD", "mid": 1.23456, "bid": 1.2345, "ask": 1.2346,
                "stale": False, "quoteAgeSeconds": 2}

    def fake_stale(path, params=None, timeout=20):
        return {"symbol": "EURUSD", "mid": 1.23456, "stale": True, "quoteAgeSeconds": 900}

    def fake_nomid(path, params=None, timeout=20):
        return {"symbol": "EURUSD", "mid": 0, "bid": 1.10, "ask": 1.12,
                "stale": False, "quoteAgeSeconds": 1}

    def fake_old(path, params=None, timeout=20):
        return {"symbol": "EURUSD", "mid": 1.2, "stale": False,
                "quoteAgeSeconds": BIQUOTE_STALE_SECONDS + 10}

    globals()["biquote_get"] = fake_live
    check("mid वाचला", biquote_price("EURUSD") == 1.23456)

    globals()["biquote_get"] = fake_stale
    check("stale किंमत नाकारली", biquote_price("EURUSD") is None)

    globals()["biquote_get"] = fake_nomid
    check("mid नसल्यास bid/ask ची सरासरी", abs(biquote_price("EURUSD") - 1.11) < 1e-9)

    globals()["biquote_get"] = fake_old
    check("खूप जुनी किंमत नाकारली", biquote_price("EURUSD") is None)

    globals()["biquote_get"] = real_get

    print()
    print("[13] 10m आणि 30m ची नवी जोड्या (खरा नियम चालतो का)")

    # 5m च्या मेणबत्त्या : 00:00 UTC (= 05:30 IST) पासून
    T0 = parse_iso_ms("2026-09-28T00:00:00Z")

    def mk5(o, h, l, c, i, interval_min=5):
        open_time = T0 + i * interval_min * 60 * 1000
        return {"open": o, "high": h, "low": l, "close": c,
                "open_time": open_time,
                "close_time": open_time + interval_min * 60 * 1000 - 1}

    # ---- 10m : Scanner 1 (bearish) — 5m + 5m ----
    base10 = [
        mk5(101.5, 101.6, 101.3, 101.4, 0),
        mk5(100.35, 101.35, 100.30, 101.30, 1),     # आधीची  (m0 = +0.95)
        mk5(100.00, 101.10, 99.90, 101.00, 2),      # 1ली (हिरवी, शरीर 1.00/1.20 = 83%, m1 = +1.00)
        mk5(101.00, 101.05, 100.00, 100.20, 3),     # 2री (लाल, आतच, m2 = -0.80)
    ]

    setup10 = detect_setup(base10, "10m")

    check("10m चा setup सापडला", setup10 is not None)
    check("10m → Scanner 1", setup10 and setup10["scanner"] == "Scanner 1",
          setup10["scanner"] if setup10 else "-")
    check("10m ची final = 2 x 5m मेणबत्त्या",
          setup10 and setup10["final"]["open"] == 100.0 and setup10["final"]["close"] == 100.20)
    check("10m ची पडताळणी खिडकी 5 मिनिटं",
          setup10 and setup10["confirmation_end"] - setup10["confirmation_start"] == 5 * 60 * 1000)
    check("10m चा खांब नियम जुळला",
          setup10 and momentum_ok(setup10["previous"], setup10["first"], setup10["second"]))
    check("10m ची पातळी = 2ऱ्याचा तळ",
          setup10 and setup_level(setup10) == setup10["second"]["low"],
          f"{setup_level(setup10) if setup10 else '-'}")

    # ---- 30m : तोच नियम, पण 15m + 15m  (15m = 3 x 5m) ----
    base30 = [
        mk5(101.5, 101.6, 101.3, 101.4, 0),
        mk5(101.4, 101.5, 101.2, 101.3, 1),
        mk5(101.3, 101.4, 101.1, 101.2, 2),
        mk5(100.35, 100.50, 100.30, 100.45, 3),     # आधीची 15m चा भाग 1  (m0 = +0.95)
        mk5(100.45, 100.90, 100.40, 100.85, 4),     # भाग 2
        mk5(100.85, 101.35, 100.80, 101.30, 5),     # भाग 3 -> आधीची बंद 101.30
        # --- final 30m (6 x 5m = 2 x 15m) ---
        mk5(100.00, 100.45, 99.95, 100.40, 6),      # 1ली (15m) चा भाग 1
        mk5(100.40, 100.95, 100.35, 100.85, 7),     # भाग 2
        mk5(100.85, 101.10, 100.80, 101.00, 8),     # भाग 3 -> 1ली बंद 101.00
        mk5(101.00, 101.05, 100.55, 100.60, 9),     # 2री (15m) चा भाग 1
        mk5(100.60, 100.65, 100.25, 100.30, 10),    # भाग 2
        mk5(100.30, 100.35, 100.10, 100.20, 11),    # भाग 3 -> बंद 100.20
    ]

    setup30 = detect_setup(base30, "30m")

    check("30m चा setup सापडला", setup30 is not None)
    check("30m → Scanner 1", setup30 and setup30["scanner"] == "Scanner 1",
          setup30["scanner"] if setup30 else "-")
    check("30m ची 1ली मेणबत्ती 15m ची आहे",
          setup30 and setup30["first"]["open_time"] == T0 + 30 * 60 * 1000
          and setup30["first"]["close"] == 101.00)
    check("30m ची पडताळणी खिडकी 15 मिनिटं",
          setup30 and setup30["confirmation_end"] - setup30["confirmation_start"] == 15 * 60 * 1000)
    check("30m चा खांब नियम जुळला",
          setup30 and momentum_ok(setup30["previous"], setup30["first"], setup30["second"]))
    check("30m ची पातळी = 2ऱ्याचा तळ",
          setup30 and setup_level(setup30) == setup30["second"]["low"],
          f"{setup_level(setup30) if setup30 else '-'}")

    # ---- 5m वरून मोठ्या मेणबत्त्या जोडणं चालतं का ----
    at_24h = parse_iso_ms("2026-09-27T00:00:00Z")     # 8h जाळीवर

    big = [
        mk5(100.0 + 0.01 * i, 100.05 + 0.01 * i, 99.95 + 0.01 * i, 100.02 + 0.01 * i, i)
        for i in range(96)                            # 96 x 5m = 8 तास
    ]

    big = [dict(c, open_time=c["open_time"] + at_24h, close_time=c["close_time"] + at_24h)
           for c in big]

    o8 = aggregate_candles(big, 480)
    o4 = aggregate_candles(big, 240)

    check("5m वरून 8h ची एक मेणबत्ती बनते", len(o8) == 1, f"{len(o8)}")
    check("5m वरून 4h च्या दोन मेणबत्त्या", len(o4) == 2, f"{len(o4)}")
    check("8h चा उच्चांक/नीचांक/बंद बरोबर",
          abs(o8[0]["high"] - max(c["high"] for c in big)) < 1e-9
          and abs(o8[0]["low"] - min(c["low"] for c in big)) < 1e-9
          and abs(o8[0]["close"] - big[-1]["close"]) < 1e-9)

    print()
    print("[14] वेळ — कोणती मेणबत्ती कधी बंद होते")

    def at(text):
        return parse_iso_ms(text)

    check("04:00:05 UTC → अजून नाही (20s थांबावं लागतं)", due_timeframes(at("2026-09-28T04:00:05Z")) == [])

    due_h4 = due_timeframes(at("2026-09-28T04:00:30Z"))

    check("04:00:30 UTC → सगळी (8h सोडून)",
          due_h4 == ["10m", "30m", "1h", "2h", "4h"], " · ".join(due_h4))

    due_0810 = due_timeframes(at("2026-09-28T04:10:30Z"))

    check("04:10:30 UTC → फक्त 10m", due_0810 == ["10m"], " · ".join(due_0810))

    due_0830 = due_timeframes(at("2026-09-28T04:30:30Z"))

    check("04:30:30 UTC → 10m + 30m", due_0830 == ["10m", "30m"], " · ".join(due_0830))

    due_8h = due_timeframes(at("2026-09-28T08:00:30Z"))

    check("08:00:30 UTC → 8h सुद्धा", "8h" in due_8h, " · ".join(due_8h))

    check("05:33:30 UTC (जाळीवर नाही) → काहीच नाही",
          due_timeframes(at("2026-09-28T05:33:30Z")) == [])

    # ========================================================
    print("[15] INDICATOR — momentum खांब (3.00x नियम)")
    # ========================================================

    km0 = make_candle(100, 110, 99, 108.70)     # m0 = +8.70
    km1 = make_candle(100, 110, 99, 109.00)     # m1 = +9.00
    km2 = make_candle(106, 108, 102, 103.00)    # m2 = -3.00

    check("मेणबत्तीचा प्रवास (momentum) बरोबर",
          abs(candle_momentum(km1) - 9.0) < 1e-9, f"{candle_momentum(km1):+.4f}")

    _s1, _s2 = momentum_sticks(km0, km1, km2)
    check("खांब 1 व खांब 2 बरोबर",
          abs(_s1 - 0.30) < 1e-9 and abs(_s2 + 12.00) < 1e-9, f"{_s1:+.4f} / {_s2:+.4f}")

    check("पट (ratio) = 40.00x",
          abs(momentum_ratio(km0, km1, km2) - 40.0) < 1e-6,
          f"{momentum_ratio(km0, km1, km2):.2f}x")

    check("नियम जुळला (40x >= 3x, उलट दिशा)", momentum_ok(km0, km1, km2) is True)

    # अगदी 3x  ->  चालतो (epsilon मुळे रद्द होत नाही)
    km2ex = make_candle(100, 110, 99, 108.10)   # m2 = +8.10  -> खांब 2 = -0.90 = 3 x 0.30
    check("अगदी 3.00x चालतो",
          abs(-0.90) >= 3.0 * 0.30 and momentum_ok(km0, km1, km2ex) is True)

    km2near = make_candle(100, 110, 99, 108.11)  # खांब 2 = -0.89  -> 3x पेक्षा कमी
    check("2.97x रद्द होतो", momentum_ok(km0, km1, km2near) is False)

    km2same = make_candle(100, 110, 99, 109.30)  # खांब 2 = +0.30 (सारखीच दिशा) -> रद्द
    check("दोन्ही खांब सारख्या दिशेचे असतील तर रद्द", momentum_ok(km0, km1, km2same) is False)

    km0same = make_candle(100, 110, 99, 109.00)  # m0 = m1  -> खांब 1 = 0 -> रद्द
    check("खांब 1 = 0 असल्यास रद्द", momentum_ok(km0same, km1, km2) is False)

    check("previous नसेल तर 1ला खांब = 1ली ची value",
          abs(momentum_sticks(None, km1, km2)[0] - 9.0) < 1e-9)
    check("previous नसेल आणि 3x नसेल तर रद्द", momentum_ok(None, km1, km2) is False)

    # indicator पूर्ण बंद केला तर सगळं चालतं
    global MOMENTUM_ENABLED
    saved_enabled = MOMENTUM_ENABLED
    MOMENTUM_ENABLED = False
    check("indicator बंद केल्यावर नियम शिथिल (चालतो)",
          momentum_ok(km0same, km1, km2) is True)
    MOMENTUM_ENABLED = saved_enabled
    check("indicator पुन्हा चालू", momentum_ok(km0same, km1, km2) is False)

    # खांब जुळला नाही तर detect_setup काहीच देत नाही
    base10_nomo = [
        mk5(101.5, 101.6, 101.3, 101.4, 0),
        mk5(100.00, 101.10, 99.90, 101.00, 1),      # आधीची = 1ली सारखीच -> खांब 1 = 0
        mk5(100.00, 101.10, 99.90, 101.00, 2),      # 1ली
        mk5(101.00, 101.05, 100.00, 100.20, 3),     # 2री
    ]
    check("खांब जुळला नाही -> setup नाही", detect_setup(base10_nomo, "10m") is None)

    # ========================================================
    print("[16] तुटण्याची पातळी — 2री मेणबत्ती (final नाही)")
    # ========================================================

    bear_setup = {
        "direction": "Bearish Reversal",
        "first": {"open": 100.0, "high": 101.10, "low": 99.90, "close": 101.00},
        "second": {"open": 101.00, "high": 101.05, "low": 100.20, "close": 100.60},
        "final": {"open": 100.0, "high": 101.10, "low": 99.90, "close": 100.20,
                  "close_time": 999},
    }
    bull_setup = {
        "direction": "Bullish Reversal",
        "first": {"open": 101.00, "high": 101.10, "low": 99.90, "close": 100.00},
        "second": {"open": 100.00, "high": 100.80, "low": 99.95, "close": 100.40},
        "final": {"open": 101.00, "high": 101.10, "low": 99.90, "close": 100.80,
                  "close_time": 999},
    }

    check("bearish : पातळी = 2ऱ्याचा तळ (100.20), final चा (99.90) नाही",
          setup_level(bear_setup) == 100.20, f"{setup_level(bear_setup)}")
    check("bullish : पातळी = 2ऱ्याचा वरचा टोक (100.80), final चा (101.10) नाही",
          setup_level(bull_setup) == 100.80, f"{setup_level(bull_setup)}")

    def _arm(su, tf="10m", scan="Scanner 1"):
        k = f"TESTUSDT|{tf}|1|{scan}"
        with LOCK:
            ACTIVE_SETUPS.clear()
            SENT_ALERTS.discard(k)
            ACTIVE_SETUPS[k] = {
                **su, "symbol": "TESTUSDT", "timeframe": tf, "scanner": scan,
                "key": k, "confirmation_start": 0, "confirmation_end": 9999999999999,
                "confirmation_high": None, "confirmation_low": None,
                "position": 0.4, "send_attempts": 0, "last_attempt_ms": 0,
            }
        return k

    bkey = _arm(bear_setup)
    process_price("TESTUSDT", 100.20, 1000)
    check("2री च्या तळाला अगदी टेकला -> अजून alert नाही", bkey in ACTIVE_SETUPS)
    process_price("TESTUSDT", 100.19, 1000)
    check("2री चा तळ तुटला -> alert (final चा तळ अजून दूर आहे)",
          bkey not in ACTIVE_SETUPS and bkey in SENT_ALERTS)

    ukey = _arm(bull_setup, scan="Scanner 2")
    process_price("TESTUSDT", 100.80, 1000)
    check("2ऱ्याच्या वरच्या टोकाला टेकला -> अजून alert नाही", ukey in ACTIVE_SETUPS)
    process_price("TESTUSDT", 100.81, 1000)
    check("2ऱ्याचा वरचा टोक तुटला -> alert",
          ukey not in ACTIVE_SETUPS and ukey in SENT_ALERTS)

    # alert संदेशात नवे शब्द/आकडे आहेत का
    with LOCK:
        ACTIVE_SETUPS.clear()
    msg_bear = make_alert("EURUSD", "10m", {**bear_setup, "previous": km0,
                                            "scanner": "Scanner 1",
                                            "confirmation_high": 100.9,
                                            "confirmation_low": 100.0,
                                            "position": 0.4},
                          100.19, 1000)
    check("संदेशात '2nd Candle Low' आहे", "2nd Candle Low" in msg_bear)
    check("संदेशात momentum चे आकडे आहेत", "Momentum (len 1)" in msg_bear)
    check("संदेशात 3.00x चा नियम आहे", "3.00x" in msg_bear)
    check("संदेशात Close <= 50% आहे", "Close <= 50% from Low" in msg_bear)

    msg_bull = make_alert("EURUSD", "10m", {**bull_setup, "previous": km0,
                                             "scanner": "Scanner 2",
                                            "confirmation_high": 100.9,
                                            "confirmation_low": 100.0,
                                            "position": 0.6},
                          100.81, 1000)
    check("bullish संदेशात '2nd Candle High' आहे", "2nd Candle High" in msg_bull)

    with LOCK:
        ACTIVE_SETUPS.clear()

    print()
    print(f" नवीन चाचण्या : {PASS} pass, {FAIL} fail")
    print("ALL TESTS PASSED" if FAIL == 0 else "KAHITARI FAIL ZALE")

    if FAIL:

        raise SystemExit(1)


# ============================================================
# ONE SHOT
# ============================================================

def run_once(symbol=None, timeframe=None):

    global ACTIVE_SYMBOLS

    refresh_time_offset()

    if symbol:

        ACTIVE_SYMBOLS = {symbol.upper()}

    else:

        ACTIVE_SYMBOLS = set(fetch_active_symbols())

    print("Active symbols:", len(ACTIVE_SYMBOLS))

    timeframes = [timeframe] if timeframe else list(TIMEFRAMES.keys())

    scan_all(timeframes)


# ============================================================
# MAIN LOOP
# ============================================================

def banner():

    print()
    print("==========================================")
    print("FOREX SCANNER  (feed: BIQUOTE — MT5 live quotes)")
    print("==========================================")
    print(f"Pairs: {len(FOREX_PAIRS)} instruments (27 forex + XAUUSD sone)")
    print("Final: " + " / ".join(TIMEFRAMES.keys()))
    print("Components: " + " / ".join(
        f"{v}m" if v < 60 else f"{v // 60}h" for v in TIMEFRAMES.values()))
    print("Scanners: 1 / 2 / 3 / 4")
    print("Confirmation: RUNNING CANDLE (strict break)")
    print(f"Trigger: 2nd candle low/high (v7)   |   Body >= {BODY_THRESHOLD*100:.0f}%"
          f"   |   Close {CLOSE_LOW_THRESHOLD*100:.0f}%"
          f"   |   Momentum >= {MOMENTUM_MULTIPLIER:.2f}x (len {MOMENTUM_LENGTH})")
    print("IST anchor: 05:30  (= 00:00 UTC)")
    print("Bazar: som 04:30 IST te shani 04:00 IST (band asतana shant)")
    print(f"Base candle: {BASE_INTERVAL}   |   Scan: dar meणbatti band zhаlyavar"
          f" ({SCAN_DELAY_SECONDS}s ne thambun)")
    print(f"Price feed: BIQUOTE REST POLL every {POLL_INTERVAL:.0f}s")
    print(f"Wick sweep: every {SWEEP_INTERVAL:.0f}s (1m candles)")
    print(f"Heartbeat: every {HEARTBEAT_SECONDS:.0f}s")
    print(f"Telegram: retry x{TELEGRAM_RETRIES}")
    print(
        f"Cleanup: alerts auto-prune {ALERT_RETENTION_DAYS}d"
        f" (dar {PRUNE_INTERVAL_SECONDS // 3600}h)"
    )
    print(
        f"Watchdog: feed {FEED_STALE_EXIT_SECONDS}s thambla tar",
        "process restart"
    )
    print("==========================================")


def main_loop():

    global ACTIVE_SYMBOLS
    global LAST_SCAN_KEYS

    banner()

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:

        print("WARNING: Telegram token/chat_id .env madhe nahi!")

    try:

        ACTIVE_SYMBOLS = set(fetch_active_symbols())

        print("Active symbols loaded:", len(ACTIVE_SYMBOLS))

    except Exception as e:

        print("Initial symbol load error:", e)

        return

    refresh_time_offset()

    # stale .tmp kadhून टाका (adhiच्या crash chya nishाणी)
    cleanup_temp_files()

    # jun्या alert keys ekdाch kadhून टाका (startup la force)
    prune_sent_alerts(now_ms(), force=True)

    # price feed + sweep + heartbeat
    for target in (price_loop, sweep_loop, heartbeat_loop):

        threading.Thread(target=target, daemon=True).start()

    print("PRICE FEED THREADS STARTED")

    # ---- immediate startup scan ------------------------------
    try:

        startup_ms = now_ms()

        if not market_is_open(startup_ms):

            print(
                "Startup scan skipped: forex bazar band aahe",
                flush=True,
            )

            raise StopIteration

        startup_candles = fetch_closed_base_candles("EURUSD")

        startup_due = compute_startup_timeframes(
            startup_candles,
            startup_ms,
        )

        startup_key = datetime.fromtimestamp(
            startup_ms / 1000,
            timezone.utc,
        ).strftime("%Y-%m-%d-%H-%M")

        LAST_SCAN_KEYS.add(startup_key)

        if startup_due:

            print(
                "Startup scan timeframes:",
                ", ".join(startup_due),
            )

            scan_all(startup_due)

        else:

            print("Startup scan skipped: no confirmation candle running")

    except StopIteration:

        pass

    except Exception as e:

        print("Startup scan error:", e)

    # ---- normal loop -----------------------------------------
    while True:

        try:

            current = now_ms()

            dt = datetime.fromtimestamp(current / 1000, timezone.utc)

            current_key = dt.strftime("%Y-%m-%d-%H-%M")

            due = due_timeframes(current)

            if (
                due
                and
                current_key not in LAST_SCAN_KEYS
                and
                market_is_open(current)
            ):

                LAST_SCAN_KEYS.add(current_key)

                if len(LAST_SCAN_KEYS) > 400:

                    LAST_SCAN_KEYS = set(
                        sorted(LAST_SCAN_KEYS)[-200:]
                    )

                scan_all(due)

            if dt.minute == 5:

                try:

                    new_symbols = set(fetch_active_symbols())

                    if new_symbols != ACTIVE_SYMBOLS:

                        ACTIVE_SYMBOLS = new_symbols

                        print(
                            "Symbol list refreshed:",
                            len(ACTIVE_SYMBOLS),
                            flush=True,
                        )

                except Exception as e:

                    print("Symbol refresh error:", e, flush=True)

            cleanup_expired_setups(current)

            # daर 6 tasांनी jun्या keys automatic kadhून टाका
            prune_sent_alerts(current)

            time.sleep(2)

        except KeyboardInterrupt:

            print()
            print("Scanner stopped.")
            break

        except Exception as e:

            print()
            print("MAIN LOOP ERROR:", e)
            time.sleep(10)


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument("--test", action="store_true")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--dry", action="store_true",
                        help="scan kara pan telegram pathवू naka (nond thevat nahi)")
    parser.add_argument("--symbol", default=None)
    parser.add_argument(
        "--timeframe",
        choices=list(TIMEFRAMES.keys()),
        default=None,
    )

    args = parser.parse_args()

    if args.test:

        self_test()

    elif args.once:

        run_once(symbol=args.symbol, timeframe=args.timeframe)

    else:

        main_loop()

