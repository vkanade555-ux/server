#!/usr/bin/env python3
# ============================================================
#  थेट तपास — 30m व 1h मेणबत्त्या *थेट biquote कडून*
# ============================================================
#  ek_jodi_tapas.py 5m मेणबत्त्या एकत्र करून तपासतं. पण feed बंद
#  पडलेल्या काळात 5m मेणबत्त्या गायब असतात, तेव्हा त्या तासाची
#  मेणबत्ती *तपासली जात नाही* (एकत्र करताना अपूर्ण ठरते).
#  हे सादन 30m आणि 1h मेणबत्त्या थेट घेतं — म्हणून खिंडार असूनही
#  तपासणी होते. फक्त वाचतं : स्कॅनरला हात लागत नाही, लिहित नाही.
#
#  वापर :
#     python3 ek_jodi_thet.py AUDUSD          # शेवटच्या 3 तास-मेणबत्त्या
#     python3 ek_jodi_thet.py GBPAUD 6        # 6 मेणबत्त्या
#     python3 ek_jodi_thet.py AUDUSD --demo   # चाचणी (internet नाही)
#
#  बरोबर :  30m मेणबत्त्या = जोडीचे घटक · 1h = एकत्र मेणबत्ती
# ============================================================

import os
import sys
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, "/home/ubuntu/trading-bot-forex", os.getcwd()):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)

IST_TZ = timezone(timedelta(hours=5, minutes=30))

MODULE_NAMES = ("forex_scanner", "forex_scanner_v7")
REQUIRED = ("TIMEFRAMES", "aggregate_candles", "scanner_result", "momentum_ok",
            "momentum_sticks", "momentum_ratio", "close_position",
            "candle_body_ratio", "biquote_candles", "now_ms", "KLINE_LIMIT")


def load_scanner():

    problems = []

    for name in MODULE_NAMES:
        try:
            module = __import__(name)
        except Exception as e:
            problems.append(f"{name}: {type(e).__name__} {e}")
            continue

        missing = [a for a in REQUIRED if not hasattr(module, a)]

        if missing:
            problems.append(f"{name}: जुनी फाइल ({', '.join(missing[:3])} नाही)")
            continue

        global IST_TZ
        IST_TZ = getattr(module, "IST", None) or IST_TZ
        return module

    print("❌ v7 नियमांची स्कॅनर फाइल सापडली नाही.")
    for p in problems:
        print(f"   · {p}")
    sys.exit(2)


def t(ms):
    return datetime.fromtimestamp(ms / 1000, IST_TZ).strftime("%d-%m %H:%M")


def hm(ms):
    return datetime.fromtimestamp(ms / 1000, IST_TZ).strftime("%H:%M")


def date_of(ms):
    return datetime.fromtimestamp(ms / 1000, IST_TZ).strftime("%d-%m-%Y")


def num(x):
    return f"{x:.5f}"


def closest(fx, first, second, final_candle, previous):
    """जवळचा Scanner व फसलेल्या अटी."""

    body_min = getattr(fx, "BODY_THRESHOLD", 0.50)
    lo_max = getattr(fx, "CLOSE_LOW_THRESHOLD", 0.50)
    hi_min = getattr(fx, "CLOSE_HIGH_THRESHOLD", 0.50)
    mult = getattr(fx, "MOMENTUM_MULTIPLIER", 3.0)

    c1g = first["close"] > first["open"]
    c1r = first["close"] < first["open"]
    c2g = second["close"] > second["open"]
    c2r = second["close"] < second["open"]

    body1_ok = fx.candle_body_ratio(first) >= body_min
    pos = fx.close_position(final_candle)
    mom_ok = bool(fx.momentum_ok(previous, first, second))

    checks = {
        "Scanner 1": [("1ली हिरवी", c1g), ("1लीचा body ≥ 50%", body1_ok), ("2री लाल", c2r),
                      ("2रीचा high 1लीपेक्षा खाली", second["high"] < first["high"]),
                      ("2रीचा low 1लीपेक्षा वर", second["low"] > first["low"]),
                      ("एकत्र close खालच्या 50% भागात", pos is not None and pos <= lo_max),
                      (f"खांब {mult:.1f}× + उलट दिशा", mom_ok)],
        "Scanner 2": [("1ली लाल", c1r), ("1लीचा body ≥ 50%", body1_ok), ("2री हिरवी", c2g),
                      ("2रीचा high 1लीपेक्षा खाली", second["high"] < first["high"]),
                      ("2रीचा low 1लीपेक्षा वर", second["low"] > first["low"]),
                      ("एकत्र close वरच्या 50% भागात", pos is not None and pos >= hi_min),
                      (f"खांब {mult:.1f}× + उलट दिशा", mom_ok)],
        "Scanner 3": [("1ली हिरवी", c1g), ("1लीचा body ≥ 50%", body1_ok), ("2री लाल", c2r),
                      ("2रीचा high 1लीपेक्षा वर (तोड)", second["high"] > first["high"]),
                      ("2रीचा low 1लीपेक्षा वर", second["low"] > first["low"]),
                      ("एकत्र close खालच्या 50% भागात", pos is not None and pos <= lo_max),
                      (f"खांब {mult:.1f}× + उलट दिशा", mom_ok)],
        "Scanner 4": [("1ली लाल", c1r), ("1लीचा body ≥ 50%", body1_ok), ("2री हिरवी", c2g),
                      ("2रीचा low 1लीपेक्षा खाली (तोड)", second["low"] < first["low"]),
                      ("2रीचा high 1लीपेक्षा खाली", second["high"] < first["high"]),
                      ("एकत्र close वरच्या 50% भागात", pos is not None and pos >= hi_min),
                      (f"खांब {mult:.1f}× + उलट दिशा", mom_ok)],
    }

    best, best_pass, best_fail = None, -1, []

    for name, items in checks.items():
        passed = sum(1 for _, ok in items if ok)
        if passed > best_pass:
            best, best_pass, best_fail = name, passed, [lab for lab, ok in items if not ok]

    return best, best_pass, best_fail


def report(fx, symbol, c30, c60, count, now, c5=None):

    by30 = {c["open_time"]: c for c in c30}
    finals = [c for c in c60]
    finals = finals[-count:]

    print()
    print(f"🔎 थेट तपास — {symbol} · 1h   (28-09 · biquote · v7 'stick' नियम)")
    print("=" * 62)
    print(f"यंत्राची वेळ : {t(now)} IST")
    print(f"30m : {len(c30)} मेणबत्त्या · 1h : {len(c60)} मेणबत्त्या")

    if c5:
        print(f"5m  : {len(c5)} मेणबत्त्या · {t(c5[0]['open_time'])} → {t(c5[-1]['open_time'])}")
        gaps = [i for i in range(len(c5) - 1)
                if c5[i + 1]["open_time"] - c5[i]["open_time"] != 300000]
        print(f"5m खिंडार : {len(gaps)}")
        for i in gaps[:8]:
            print(f"     ⚠️ {t(c5[i]['open_time'])} → {t(c5[i + 1]['open_time'])} (ध सुटलं)")

    setups = 0
    fired = 0

    for final in finals:

        s = final["open_time"]
        label = f"{t(s)} → {t(s + 3600000)} IST"

        print()
        print(f"🕒 {label}")

        f1 = by30.get(s)
        f2 = by30.get(s + 1800000)
        m0 = by30.get(s - 1800000)

        if not (f1 and f2):
            print("   ⏳ 30m घटक नाहीत — तपासता आली नाही")
            continue

        s1, s2 = fx.momentum_sticks(m0, f1, f2)
        ratio = fx.momentum_ratio(m0, f1, f2)
        opp = (s1 > 0) != (s2 > 0)

        print(f"   एकत्र: उघड {num(final['open'])} · उच्च {num(final['high'])} · "
              f"नीच {num(final['low'])} · बंद {num(final['close'])}")
        print(f"   1ली {hm(f1['open_time'])}–{hm(f2['open_time'])}: "
              f"{'हिरवी' if f1['close'] > f1['open'] else 'लाल'} · "
              f"body {fx.candle_body_ratio(f1):.0%}")
        print(f"   2री {hm(f2['open_time'])}–{hm(s + 3600000)}: "
              f"{'हिरवी' if f2['close'] > f2['open'] else 'लाल'} · "
              f"body {fx.candle_body_ratio(f2):.0%}")
        print(f"   खांब: 1ला {s1:+.5f} · 2रा {s2:+.5f} → "
              f"{('%.2f पट' % ratio) if ratio is not None else '—'} "
              f"(उलट दिशा: {'हो' if opp else 'नाही'})")

        verdict = fx.scanner_result(f1, f2, final, m0)

        if verdict:

            setups += 1
            bearish = "Bearish" in verdict["direction"]
            level = f2["low"] if bearish else f2["high"]

            print(f"   ✅ SETUP होता — {verdict['scanner']} ({verdict['direction']})")
            print(f"      हद्द (2रीचा {'low' if bearish else 'high'}) : {num(level)}")

            after = [c for c in c30 if c["open_time"] >= s + 3600000]
            hit = None
            hit_at = None

            for c in after:
                if (c["low"] <= level) if bearish else (c["high"] >= level):
                    hit, hit_at = c, c["open_time"]
                    break

            if hit is not None:
                fired += 1
                px = hit["low"] if bearish else hit["high"]
                print(f"      🔔 भाव {hm(hit_at)} वाजता {num(px)} पर्यंत गेला — "
                      f"हद्द तोडली → alert जायचा ✅")
            else:
                print(f"      ⛔ नंतरच्या मेणबत्त्यांत भाव हद्दीपर्यंत गेला नाही → "
                      f"alert जायचा नाही (नियमानुसार बरोबर ✅)")

        else:

            name, passed, fails = closest(fx, f1, f2, final, m0)
            why = " · ".join(fails[:3])
            if len(fails) > 3:
                why += f" · +{len(fails) - 3} अटी"
            print(f"   ❌ setup नाही")
            print(f"      जवळचा: {name} ({passed}/7) — ✗ {why}")

    print()
    print("=" * 62)
    print(f"एकूण : {len(finals)} मेणबत्त्या · {setups} setup · {fired} वेळा हद्द तोडली")
    if setups and not fired:
        print("➡️  setup होता पण भाव हद्दीपर्यंत पोहोचला नाही = alert न येणे नियमानुसार बरोबर.")
    print("=" * 62)


# ============================================================
#  चाचणी (internet नाही)
# ============================================================

def demo():

    fx = load_scanner()
    global IST_TZ
    IST_TZ = getattr(fx, "IST", None) or IST_TZ

    START = 1759060800 * 1000          # 1h + 30m जाळीवर बसणारी वेळ

    comps = [
        (1.00000, 1.00050, 0.99950, 0.99980),   # प्री (setup नाही)
        (1.00000, 1.00320, 0.99980, 1.00300),   # m0  = +0.0030
        (1.00000, 1.00650, 0.99550, 1.00600),   # 1ली = +0.0060 (body 55%)
        (1.00100, 1.00700, 0.99560, 0.99580),   # 2री = -0.0052 (high तोड)
        (1.00000, 1.00500, 0.99500, 0.99950),   # खिडकी (हद्द 0.9956 तोडली)
        (0.99700, 0.99900, 0.99650, 0.99800),
    ]

    c30 = []
    for i, (o, h, l, c) in enumerate(comps):
        c30.append({"open_time": START + i * 1800000, "open": o, "high": h,
                    "low": l, "close": c, "volume": 0})

    c60 = []
    for j in range(3):
        a, b = c30[2 * j], c30[2 * j + 1]
        c60.append({
            "open_time": START + j * 3600000,
            "open": a["open"],
            "high": max(a["high"], b["high"]),
            "low": min(a["low"], b["low"]),
            "close": b["close"],
            "volume": 0,
        })

    c5 = [{"open_time": START + i * 300000, "open": 1.0, "high": 1.0,
           "low": 1.0, "close": 1.0, "volume": 0} for i in range(36)]
    del c5[14]                                   # बनावट खिंडार

    now = START + 3 * 3600000 + 60000

    import io
    import contextlib

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        report(fx, "AUDUSD", c30, c60, 3, now, c5)
    out = buf.getvalue()

    want = [
        ("खिंडार 1", "5m खिंडार : 1"),
        ("setup 1", "एकूण : 3 मेणबत्त्या · 1 setup · 1 वेळा हद्द तोडली"),
        ("Scanner 3", "SETUP होता — Scanner 3"),
        ("हद्द", "0.99560"),
    ]

    ok_all = True
    for label, needle in want:
        ok = needle in out
        ok_all = ok_all and ok
        print(f"  {'✅' if ok else '❌'} {label}")

    print()
    print("=" * 62)
    print(f" निकाल : {'सगळ्या चाचण्या पास ✅' if ok_all else 'काहीतरी फसलं ❌'}")
    print("=" * 62)
    return 0 if ok_all else 1


# ============================================================

def main():

    if len(sys.argv) >= 2 and sys.argv[1] == "--demo":
        return demo()

    if len(sys.argv) < 2:
        print(__doc__ or "")
        return 2

    symbol = sys.argv[1].upper().replace("/", "")

    try:
        count = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    except ValueError:
        count = 3

    fx = load_scanner()

    want_list = getattr(fx, "WANT", None)
    if want_list and symbol not in want_list:
        print(f"⚠️  {symbol} स्कॅनरच्या यादीत नाही.")
        return 2

    now = fx.now_ms()

    print(f"डेटा आणतोय : {symbol} (30m + 1h + 5m, थेट biquote)...")

    try:
        c30 = fx.biquote_candles(symbol, "30m", 200, current=now)
        c60 = fx.biquote_candles(symbol, "1h", 100, current=now)
    except Exception as e:
        print(f"❌ biquote कडून डेटा आला नाही : {e}")
        return 1

    c5 = None
    try:
        c5 = fx.biquote_candles(symbol, "5m", fx.KLINE_LIMIT, current=now)
    except Exception:
        pass

    if not c60 or not c30:
        print("❌ मेणबत्त्या मिळाल्या नाहीत")
        return 1

    report(fx, symbol, c30, c60, count, now, c5)
    return 0


if __name__ == "__main__":
    sys.exit(main())
