#!/usr/bin/env python3
# ============================================================
#  TIN CANDLE SCANNER — "3 meणbatti pattern"  (4h chya aat)
#  ============================================================
#
#  NIYAM (yuzar ne sangitlya pramाणे) :
#
#    4h block : 05:30 te 09:29 IST     (udahaरण — aajcha block)
#
#      1ली 1h  : 05:30 - 06:30
#                 • body >= 70%  (purna range chya)
#                 • close >= 70% (purna range chya)
#
#      2री 1h  : 06:30 - 07:30
#                 • body >= 70%
#                 • close >= 70%
#
#      3री 1h  : 07:30 - 08:30
#                 • body >= 80%
#                 • close >= 80%
#                 • 3री chi RANGE >= 2 x (1ली + 2री chi range)
#                   (1ली + 2री = 200 asel tar 3री >= 400 kiva tya peksha jast)
#
#      ⏰ ALERT = 3री meणbatti BAND zhालi ki (08:30 IST) — aani tevha
#                 SAGLE pairs tapasalе jaतात, aani ekach digast (report) yeतो.
#
#  ⚠️ HA VEGLA SCANNER AHE :
#       • sadyacha live_scanner.py  — haat nahi lavat (te alerts tasेच yeतil)
#       • navin_scanner.py (pattern 2x) — haat nahi lavat (vegla scanner)
#       • swatachi service : tin-candle-scanner.service
#       • swatachi nod     : tin_candle_alerts_sent.json
#
#  CHALAVA :
#      ./venv/bin/python tin_candle_scanner.py --test                 # chaanणी
#      ./venv/bin/python tin_candle_scanner.py --once --dry-run --show  # aajcha block tapasa
#      ./venv/bin/python tin_candle_scanner.py                        # chालू (08:30 la alert)
#      ./venv/bin/python tin_candle_scanner.py --blocks all           # sगळ्या 4h blocks
# ============================================================

import argparse
import json
import os
import sys
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta

import requests
from dotenv import load_dotenv


# ============================================================
# CONFIG
# ============================================================

load_dotenv()

TELEGRAM_BOT_TOKEN = (
    os.getenv("TIN_TELEGRAM_BOT_TOKEN") or os.getenv("TELEGRAM_BOT_TOKEN")
)

TELEGRAM_CHAT_ID = (
    os.getenv("TIN_TELEGRAM_CHAT_ID") or os.getenv("TELEGRAM_CHAT_ID")
)

BINANCE_BASE = "https://fapi.binance.com"

# ---- NIYAMACHE AAKडे (itHE badala) --------------------------

# 3 meणbatti : (block pasun kitवा tas, body chya %, close chya %)
CANDLES = [
    (0, 0.70, 0.70),      # 1ली : 70% body, 70% close
    (1, 0.70, 0.70),      # 2री : 70% body, 70% close
    (2, 0.80, 0.80),      # 3री : 80% body, 80% close
]

THIRD_RATIO = 2.00        # 3री chi range >= itke x (1ली + 2री)

# 3री chi range kona-शी tulna?   "sum" = 1ली + 2री chi range chi beriज
#                                 "combined" = donhi chya ekत्र mulखडी unchi
BASE_OF_2X = "sum"

MUST_BE_GREEN = True      # tino hi HIRAVI havi (niyamात aapोaap yetं, tari thevली)

# ---- KONTE 4h BLOCK TAPASAYCHA (IST) -----------------------

# yuzar ne sangitले : 05:30 te 09:29  ->  block 05:30 la suru
WINDOWS_IST = ["05:30"]

ALL_BLOCKS = False        # True = dar 4h la (05:30, 09:30, 13:30, 17:30, 21:30, 01:30)

# ---- CHALणी -------------------------------------------------

DRY_RUN = False           # True = fakt log, Telegram la kाहich nahi
WINDOW_END_WAIT = 25      # 3री band zhालyavar itke sekand थांबून meणbattya yeto
MAX_WORKERS = 12
KLINE_LIMIT = 6           # 1h meणbattya — 4-6 puresा
STATE_FILE = os.getenv("TIN_STATE_FILE", "tin_candle_alerts_sent.json")
STATE_KEEP_DAYS = 180
MESSAGE_LIMIT = 3500      # Telegram ekा message chi hadd (4096 madhli surक्षit)
COINS_PER_MESSAGE = 8     # ekा message madhe kiti pairs chi tapashil

IST = timezone(timedelta(hours=5, minutes=30))
MINUTE_MS = 60 * 1000
DAY_MS = 24 * 60 * 60 * 1000
LOCK = threading.Lock()

SESSION = None
SENT_ALERTS = {}
DIGESTS_SENT = 0
SCANS_DONE = 0
LAST_SCAN_MS = 0


# ============================================================
# VEL
# ============================================================

def now_ms():
    return int(time.time() * 1000)


def format_ist(timestamp_ms):
    dt = datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).astimezone(IST)
    return dt.strftime("%d-%m-%Y %H:%M IST")


def hhmm_ist(timestamp_ms):
    dt = datetime.fromtimestamp(timestamp_ms / 1000, timezone.utc).astimezone(IST)
    return dt.strftime("%H:%M")


def ist_window_to_utc_minutes(text):
    """'05:30' (IST)  ->  0 (UTC madhle minute, 00:00)"""

    parts = text.strip().split(":")

    if len(parts) != 2:
        raise ValueError(text)

    minutes = int(parts[0]) * 60 + int(parts[1])

    return (minutes - 330) % 1440


def window_list():
    """konte block tapasayche (UTC minute) — chaalu windows"""

    if ALL_BLOCKS:
        return [0, 240, 480, 720, 960, 1200]

    return [ist_window_to_utc_minutes(w) for w in WINDOWS_IST]


# ============================================================
# NETWORK
# ============================================================

def get_session():
    global SESSION

    if SESSION is None:
        SESSION = requests.Session()
        SESSION.headers.update({"User-Agent": "tin-candle-scanner/1.0"})

    return SESSION


def fetch_active_symbols():
    r = get_session().get(f"{BINANCE_BASE}/fapi/v1/exchangeInfo", timeout=25)
    r.raise_for_status()

    out = set()

    for item in r.json().get("symbols", []):
        if (item.get("status") == "TRADING"
                and item.get("quoteAsset") == "USDT"
                and item.get("contractType") == "PERPETUAL"):
            out.add(item["symbol"])

    return sorted(out)


def fetch_closed_1h(symbol, limit=KLINE_LIMIT):
    """1h meणbattya — chaalu meणbatti sodun."""

    r = get_session().get(
        f"{BINANCE_BASE}/fapi/v1/klines",
        params={"symbol": symbol, "interval": "1h", "limit": int(limit)},
        timeout=20,
    )
    r.raise_for_status()

    current = now_ms()

    out = []

    for k in r.json():
        if int(k[6]) >= current:
            continue

        out.append({
            "open_time": int(k[0]),
            "open": float(k[1]),
            "high": float(k[2]),
            "low": float(k[3]),
            "close": float(k[4]),
            "close_time": int(k[6]),
        })

    return out


def send_telegram(message, retries=3):

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("⚠️ Telegram aakडे nahit (.env tapasa).", flush=True)
        return False

    for attempt in range(1, retries + 1):

        try:
            r = get_session().post(
                f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
                json={"chat_id": TELEGRAM_CHAT_ID, "text": message,
                      "disable_web_page_preview": True},
                timeout=20,
            )

            if r.status_code == 200 and r.json().get("ok"):
                return True

            print(f"Telegram error ({attempt}/{retries}):", r.text[:150], flush=True)

        except Exception as e:
            print(f"Telegram error ({attempt}/{retries}): {e}", flush=True)

        time.sleep(3 * attempt)

    return False


# ============================================================
# MEणBATTI CHYA AAKडे
# ============================================================

def candle_range(candle):
    return candle["high"] - candle["low"]


def body_ratio(candle):
    """body = |band - udghad|  /  purna range."""

    rng = candle_range(candle)

    if rng <= 0:
        return None

    return abs(candle["close"] - candle["open"]) / rng


def close_position(candle):
    """close = range chya kiti % var (0.70 = 70%)."""

    rng = candle_range(candle)

    if rng <= 0:
        return None

    return (candle["close"] - candle["low"]) / rng


def is_green(candle):
    return candle["close"] > candle["open"]


# ============================================================
# NIYAM TAPAसणी
# ============================================================

def pick_candles(kline_rows, block_start_ms):
    """block chya tino 1h meणbattya (open_time ne) — nahit tar None."""

    index = {c["open_time"]: c for c in kline_rows}

    picked = []

    for offset_h, _, _ in CANDLES:

        want = block_start_ms + offset_h * 60 * MINUTE_MS

        candle = index.get(want)

        if candle is None:
            return None

        picked.append(candle)

    return picked


def check_three(three):

    a, b, c = three

    r1, r2, r3 = candle_range(a), candle_range(b), candle_range(c)

    if r1 <= 0 or r2 <= 0 or r3 <= 0:
        return None

    if MUST_BE_GREEN and not (is_green(a) and is_green(b) and is_green(c)):
        return None

    details = []

    for candle, (_, body_min, close_min), rng in zip(three, CANDLES, (r1, r2, r3)):

        body = body_ratio(candle)
        pos = close_position(candle)

        if body is None or pos is None:
            return None

        if body < body_min - 1e-12 or pos < close_min - 1e-12:
            return None

        details.append({"body": body, "pos": pos, "range": rng})

    if BASE_OF_2X == "combined":

        base = max(a["high"], b["high"]) - min(a["low"], b["low"])

    else:

        base = r1 + r2

    if base <= 0:
        return None

    ratio = r3 / base

    if ratio < THIRD_RATIO - 1e-12:
        return None

    return {
        "candles": three,
        "details": details,
        "base": base,
        "ratio": ratio,
        "base_of_2x": BASE_OF_2X,
    }


def scan_symbol(symbol, kline_rows, block_start_ms):

    three = pick_candles(kline_rows, block_start_ms)

    if three is None:
        return None

    result = check_three(three)

    if result is None:
        return None

    result["symbol"] = symbol
    result["block_start_ms"] = block_start_ms
    result["key"] = f"{symbol}|{block_start_ms}|tincandle"

    return result


# ============================================================
# NOD (state)
# ============================================================

def load_state():

    global SENT_ALERTS

    if not os.path.isfile(STATE_FILE):
        return False

    try:
        with open(STATE_FILE, "r") as f:
            data = json.load(f)

        if isinstance(data, dict):
            SENT_ALERTS = {str(k): int(v) for k, v in data.items()}
        elif isinstance(data, list):
            stamp = now_ms()
            SENT_ALERTS = {str(k): stamp for k in data}

        return True

    except Exception as e:
        print("State file vaachta alI nahi:", e, flush=True)
        return False


def save_state():

    tmp = STATE_FILE + ".tmp"

    try:
        with open(tmp, "w") as f:
            json.dump(SENT_ALERTS, f)
        os.replace(tmp, STATE_FILE)
    except Exception as e:
        print("State file lihta alI nahi:", e, flush=True)


def prune_state():

    cutoff = now_ms() - STATE_KEEP_DAYS * DAY_MS

    for key in [k for k, v in SENT_ALERTS.items() if v < cutoff]:
        SENT_ALERTS.pop(key, None)


# ============================================================
# DIGAST (report) — sगळे pairs ekत्र
# ============================================================

def candle_line(name, detail, candle):

    return (f"   {name} : range {detail['range']:.8g} | body {detail['body'] * 100:.0f}%"
            f" | close {detail['pos'] * 100:.0f}% |"
            f" {'hiravi ✅' if is_green(candle) else 'laal ❌'}")


def build_digest(matches, block_start_ms, scanned):
    """sगळ्या jhालेल्या pairs cha digast — लांब asel tar tukडे karतो."""

    header = [
        "🚨 TIN CANDLE PATTERN",
        "",
        f"4h block : {hhmm_ist(block_start_ms)} – "
        f"{hhmm_ist(block_start_ms + 4 * 60 * MINUTE_MS - 60 * 1000)} IST",
        f"3री meणbatti band : {format_ist(matches[0]['candles'][2]['close_time'])}",
        f"Sagale pairs tapasalе : {scanned}",
        f"Jhalele pairs : {len(matches)}",
        "",
    ]

    body = []

    for i, m in enumerate(matches, 1):

        a, b, c = m["candles"]
        da, db, dc = m["details"]

        body.append(f"{i}) {m['symbol']}")
        body.append(candle_line("1ली", da, a))
        body.append(candle_line("2री", db, b))
        body.append(candle_line("3री", dc, c))
        body.append(
            f"   📐 3री ÷ (1ली+2री) : {dc['range']:.8g} ÷ {m['base']:.8g}"
            f" = {m['ratio']:.2f}x   (niyam >= {THIRD_RATIO:.2f}x)"
        )
        body.append("")

    footer = [
        "⚠️ ha TIN CANDLE scanner (vegla niyam)",
    ]

    return header, body, footer


def send_digest(matches, block_start_ms, scanned):
    """digast pathवतो — लांब asel tar kai messages madhe."""

    global DIGESTS_SENT

    header, body, footer = build_digest(matches, block_start_ms, scanned)

    # ---- chhote tukडे tayaar ----
    chunks = []

    current = list(header)

    for i, m in enumerate(matches, 1):

        a, b, c = m["candles"]
        da, db, dc = m["details"]

        block = [
            f"{i}) {m['symbol']}",
            candle_line("1ली", da, a),
            candle_line("2री", db, b),
            candle_line("3री", dc, c),
            f"   📐 3री ÷ (1ली+2री) : {dc['range']:.8g} ÷ {m['base']:.8g}"
            f" = {m['ratio']:.2f}x   (niyam >= {THIRD_RATIO:.2f}x)",
            "",
        ]

        if sum(len(x) + 1 for x in current + block) > MESSAGE_LIMIT:
            chunks.append("\n".join(current))
            current = [f"… (pudhe) {block_start_ms and format_ist(block_start_ms)}", ""]

        current.extend(block)

    current.extend(footer)

    chunks.append("\n".join(current))

    total = len(chunks)

    ok_all = True

    for n, chunk in enumerate(chunks, 1):

        text = chunk if total == 1 else f"[{n}/{total}]\n{chunk}"

        print()
        print("=" * 72)
        print(text)
        print("=" * 72)

        if DRY_RUN:
            print("   DRY RUN: Telegram alert pathवला nahi", flush=True)
            continue

        if send_telegram(text):
            print(f"   ✅ DIGAST DELIVERED ({n}/{total})", flush=True)
        else:
            ok_all = False
            print(f"   ⚠️ Telegram FAILED ({n}/{total})", flush=True)

    if ok_all and not DRY_RUN:
        DIGESTS_SENT += 1

    return ok_all


# ============================================================
# SCAN (sगळे pairs)
# ============================================================

def scan_all(symbols, block_start_ms, allow_alert=True, show=False):

    global SCANS_DONE, LAST_SCAN_MS

    started = now_ms()

    matches = []
    errors = 0
    ready = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:

        jobs = {pool.submit(fetch_closed_1h, s): s for s in symbols}

        for job in as_completed(jobs):

            symbol = jobs[job]

            try:
                rows = job.result()
            except Exception:
                errors += 1
                continue

            if not rows:
                continue

            ready += 1

            try:
                found = scan_symbol(symbol, rows, block_start_ms)
            except Exception as e:
                errors += 1
                print("scan error:", symbol, e, flush=True)
                continue

            if found:
                matches.append(found)

    matches.sort(key=lambda m: -m["ratio"])

    # ---- nave kाहich aahe ka? ----
    new_matches = []

    with LOCK:

        for m in matches:

            if m["key"] in SENT_ALERTS:
                continue

            SENT_ALERTS[m["key"]] = m["block_start_ms"]
            new_matches.append(m)

        if new_matches:
            save_state()

    print(f"   {len(matches)} pairs jhale | {len(new_matches)} nave | "
          f"{ready}/{len(symbols)} pairs chi meणbattya milalI | {errors} errors",
          flush=True)

    if show and matches:
        for m in matches:
            print(f"      {m['symbol']:<16} {m['ratio']:.2f}x", flush=True)

    if allow_alert and new_matches:
        send_digest(new_matches, block_start_ms, len(symbols))

    SCANS_DONE += 1
    LAST_SCAN_MS = started

    return len(matches), len(new_matches), errors


# ============================================================
# VELA (kadhी alert yeईl)
# ============================================================

def target_ms_for_block(block_start_ms):
    """3री meणbatti BAND zhालi tya kshaणी = block + 3 tas"""

    return block_start_ms + 3 * 60 * MINUTE_MS


def next_target_ms(from_ms=None):
    """pudhचा alert cha वेळ (block chya tिसऱ्या meणbattiche band hoणे)."""

    now = now_ms() if from_ms is None else from_ms

    day = (now // DAY_MS) * DAY_MS

    best = None

    for d in range(0, 8):

        base = day + d * DAY_MS

        for minutes in window_list():

            block = base + minutes * MINUTE_MS
            target = target_ms_for_block(block)

            if target > now:
                if best is None or target < best:
                    best = target

    return best


def last_finished_block_ms(from_ms=None):
    """sगळ्यात shevatचा PURNA zhालेला block (--once sathi)."""

    now = now_ms() if from_ms is None else from_ms

    day = (now // DAY_MS) * DAY_MS

    best = None

    for d in (-1, 0):

        base = day + d * DAY_MS

        for minutes in window_list():

            block = base + minutes * MINUTE_MS

            if target_ms_for_block(block) <= now:
                if best is None or block > best:
                    best = block

    return best


# ============================================================
# BANNER
# ============================================================

def banner():

    print()
    print("==========================================")
    print("TIN CANDLE SCANNER — 3 meणbatti pattern (4h)")
    print("==========================================")

    for minutes in window_list():

        block_ist = (minutes + 330) % 1440
        b_str = f"{block_ist // 60:02d}:{block_ist % 60:02d}"
        end_ist = (block_ist + 240) % 1440
        e_str = f"{end_ist // 60:02d}:{end_ist % 60:02d}"

        print(f"  4h block : {b_str} – {e_str} IST")

        for off, body_min, close_min in CANDLES:

            s = (block_ist + off * 60) % 1440
            e = (block_ist + off * 60 + 60) % 1440

            print(f"    {off + 1}ली 1h : {s // 60:02d}:{s % 60:02d} – {e // 60:02d}:{e % 60:02d}"
                  f"  | body >= {body_min * 100:.0f}% | close >= {close_min * 100:.0f}%")

        print(f"    3री chi range >= {THIRD_RATIO:.2f}x "
              f"(1ली + 2री chi range — {BASE_OF_2X})")

    print(f"  Hiravi havi : {'ho' if MUST_BE_GREEN else 'nahi'}")
    print(f"  Alert : 3री meणbatti BAND zhालi ki (sगळे pairs ekत्र)")
    print(f"  Telegram : {'BAND (dry run)' if DRY_RUN else 'chalu'}")
    print(f"  Nod file : {STATE_FILE}")
    print("==========================================")

    nxt = next_target_ms()

    if nxt:
        print(f"Pudhचa scan : {format_ist(nxt)}")

    print(flush=True)


# ============================================================
# SWATAHCHI CHAचणी (network nahit)
# ============================================================

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL

    if cond:
        PASS += 1
        print(f"  ✅ {name}" + (f"   {extra}" if extra else ""))
    else:
        FAIL += 1
        print(f"  ❌ {name}" + (f"   {extra}" if extra else ""))


def c1h(start, o, h, l, c):
    return {"open_time": start, "open": o, "high": h, "low": l, "close": c,
            "close_time": start + 60 * MINUTE_MS - 1}


def up(start, rng, body, pos, base=100.0):
    """hiravi meणbatti : range rng, body body*rng, close unchi chya pos*rng var."""

    low = base
    high = base + rng
    close = low + pos * rng
    open_ = close - body * rng

    return c1h(start, open_, high, low, close)


def three_candles(block, r1, b1, p1, r2, b2, p2, r3, b3, p3, green=True):
    """block chya tino 1h meणbattya (base 100 varun)."""

    first = up(block, r1, b1, p1)
    second = up(block + 60 * MINUTE_MS, r2, b2, p2, base=100.5 if green else 100.5)

    if not green:
        second["close"], second["open"] = second["open"], second["close"]

    third = up(block + 120 * MINUTE_MS, r3, b3, p3, base=101.0)

    if not green:
        third["close"], third["open"] = third["open"], third["close"]

    return [first, second, third]


def self_test():

    global PASS, FAIL, DRY_RUN, STATE_FILE, SENT_ALERTS, BASE_OF_2X, MUST_BE_GREEN
    global WINDOWS_IST, ALL_BLOCKS

    print("=" * 72)
    print(" SWATAHCHI CHAचणी — network nahit, Telegram nahit")
    print("=" * 72)

    saved = (DRY_RUN, STATE_FILE, dict(SENT_ALERTS), BASE_OF_2X, MUST_BE_GREEN,
             list(WINDOWS_IST), ALL_BLOCKS)

    tmp_state = "tin_candle_selftest_state.json"

    try:

        DRY_RUN = True
        STATE_FILE = tmp_state
        SENT_ALERTS = {}

        if os.path.isfile(tmp_state):
            os.remove(tmp_state)

        # 1 divas sariवar — 1h meणbattya sगळ्या kड्यावar basतात
        block = 1_700_000_000_000 // DAY_MS * DAY_MS + 60 * MINUTE_MS

        # ---- [1] config ----
        print()
        print("[1] NIYAMACHE AAKडे")

        check("1ली : 70% body / 70% close", CANDLES[0] == (0, 0.70, 0.70))
        check("2री : 70% body / 70% close", CANDLES[1] == (1, 0.70, 0.70))
        check("3री : 80% body / 80% close", CANDLES[2] == (2, 0.80, 0.80))
        check("3री chi range >= 2x (1ली + 2री)", abs(THIRD_RATIO - 2.0) < 1e-9)
        check("base = 1ली + 2री chi range", BASE_OF_2X == "sum")
        check("default window = 05:30 IST (UTC 00:00)",
              ist_window_to_utc_minutes("05:30") == 0 and WINDOWS_IST == ["05:30"])
        check("sगळे 4h blocks (all) : 05:30, 09:30, 13:30, 17:30, 21:30, 01:30",
              [ist_window_to_utc_minutes(x) for x in
               ("05:30", "09:30", "13:30", "17:30", "21:30", "01:30")]
              == [0, 240, 480, 720, 960, 1200])

        # ---- [2] aakडे kadhणी ----
        print()
        print("[2] MEणBATTI CHYA AAKडे")

        c = up(block, 1.00, 0.70, 0.70)

        check("body 70%", abs(body_ratio(c) - 0.70) < 1e-9, f"{body_ratio(c) * 100:.0f}%")
        check("close 70%", abs(close_position(c) - 0.70) < 1e-9,
              f"{close_position(c) * 100:.0f}%")
        check("hiravi", is_green(c))

        c2 = up(block, 1.00, 0.90, 0.90)
        check("body 90% / close 90%", abs(body_ratio(c2) - 0.90) < 1e-9
              and abs(close_position(c2) - 0.90) < 1e-9)

        # laal meणbatti : body 70% + close 70% shakya NAHI
        red = c1h(block, 100.70, 101.00, 100.00, 100.70)
        red["close"] = 100.72 - 0.70
        check("laal + body/close 70% — ashakya (ganitane)",
              (body_ratio(red) is None) or
              not (body_ratio(red) >= 0.70 and close_position(red) >= 0.70),
              f"body {body_ratio(red) and body_ratio(red) * 100:.0f}% / "
              f"close {close_position(red) * 100:.0f}%")

        check("unchi zero -> None", body_ratio(c1h(block, 100, 100, 100, 100)) is None)

        # ---- [3] tino meणbatti — pass ----
        print()
        print("[3] TINO MEणBATTI JHUणALYA")

        # 3री = adgad 2 x (1+2)  : 1.00 + 1.00 = 2.00  ->  3री 4.00
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 4.00, 0.80, 0.80)
        res = check_three(t)

        check("adgad 2.00x -> jhuणले", res is not None)
        check("   ratio = 2.00x", res and abs(res["ratio"] - 2.0) < 1e-9,
              f"{res['ratio']:.3f}x" if res else "-")
        check("   base = 1ली + 2री = 2.00", res and abs(res["base"] - 2.0) < 1e-9)

        # 1.99x -> nahi
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 3.98, 0.80, 0.80)
        check("1.99x -> jhuणले nahi", check_three(t) is None)

        # 5x -> chalta
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 10.0, 0.85, 0.85)
        res = check_three(t)
        check("10.00x (5x peksha jast) -> chalta", res is not None and res["ratio"] > 4.9,
              f"{res['ratio']:.2f}x" if res else "-")

        # 1ली body 69% -> nahi
        t = three_candles(block, 1.00, 0.69, 0.80, 1.00, 0.70, 0.70, 4.00, 0.80, 0.80)
        check("1ली body 69% -> nahi", check_three(t) is None)

        # 1ली close 69% -> nahi
        t = three_candles(block, 1.00, 0.69, 0.69, 1.00, 0.70, 0.70, 4.00, 0.80, 0.80)
        check("1ली close 69% -> nahi", check_three(t) is None)

        # 2री body 69% -> nahi
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.69, 0.80, 4.00, 0.80, 0.80)
        check("2री body 69% -> nahi", check_three(t) is None)

        # 3री body 79% -> nahi (80% havi)
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 4.00, 0.79, 0.85)
        check("3री body 79% -> nahi (80% havi)", check_three(t) is None)

        # 3री close 79% -> nahi
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 4.00, 0.85, 0.79)
        check("3री close 79% -> nahi", check_three(t) is None)

        # 1ली 2री 75% -> chalta (70 peksha jast)
        t = three_candles(block, 1.00, 0.75, 0.75, 1.00, 0.75, 0.75, 4.00, 0.85, 0.85)
        check("1ली/2री 75% -> chalta", check_three(t) is not None)

        # 3री = 3 x -> chalta
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 6.00, 0.80, 0.80)
        res = check_three(t)
        check("3री = 3.00x -> chalta", res is not None and abs(res["ratio"] - 3.0) < 1e-9,
              f"{res['ratio']:.2f}x" if res else "-")

        # laal meणbatti -> nahi
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 4.00, 0.80, 0.80)
        t[1]["open"], t[1]["close"] = t[1]["close"], t[1]["open"]
        check("2री laal -> nahi", check_three(t) is None)

        # unchi zero -> crash nahi
        t = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 4.00, 0.80, 0.80)
        t[2] = c1h(block + 120 * MINUTE_MS, 100, 100, 100, 100)
        check("3री chi unchi zero -> crash nahi, nahi",
              check_three(t) is None)

        # ---- [4] combined paddhat ----
        print()
        print("[4] BASE = 'combined' (doni chya ekत्र mulखडी unchi)")

        BASE_OF_2X = "combined"

        # 1ली : 100 -> 101 (range 1) ; 2री : 101 -> 102 (range 1) ; combined = 2
        a = up(block, 1.00, 0.70, 0.70, base=100.0)
        b = up(block + 60 * MINUTE_MS, 1.00, 0.70, 0.70, base=101.0)
        c3 = up(block + 120 * MINUTE_MS, 4.08, 0.85, 0.85, base=102.0)

        res = check_three([a, b, c3])

        check("combined = 2.00 (1ली low 100, 2री high 102)", 
              res is not None and abs(res["base"] - 2.0) < 1e-9,
              f"base {res['base']:.4g}" if res else "-")
        check("   ratio = 2.04x -> chalta", res is not None,
              f"{res['ratio']:.2f}x" if res else "-")

        BASE_OF_2X = "sum"

        # ---- [5] window sathi ----
        print()
        print("[5] BLOCK AANI VELA")

        check("05:30 IST block = UTC 00:00", ist_window_to_utc_minutes("05:30") == 0)
        check("09:30 IST block = UTC 04:00", ist_window_to_utc_minutes("09:30") == 240)

        check("12:00 IST = 06:30 UTC", ist_window_to_utc_minutes("12:00") == 390)

        t_block = 1_700_000_000_000 // DAY_MS * DAY_MS

        check("3री band zhालi = block + 3 tas",
              target_ms_for_block(t_block) == t_block + 3 * 60 * MINUTE_MS)

        # aaj 07:00 IST (block 05:30 zhाला) -> pudhचa target aaj 08:30
        now_aaj = t_block + 90 * MINUTE_MS          # 07:00 IST
        nxt = next_target_ms(now_aaj)
        check("07:00 IST la pudhचa alert = aaj 08:30 IST",
              nxt == t_block + 180 * MINUTE_MS, format_ist(nxt))

        # aaj 10:00 IST (block purna) -> pudhचa target UDYA 08:30
        now_udya = t_block + 270 * MINUTE_MS        # 10:00 IST
        nxt = next_target_ms(now_udya)
        check("10:00 IST la pudhचa alert = udya 08:30 IST",
              nxt == t_block + DAY_MS + 180 * MINUTE_MS, format_ist(nxt))

        # --once : shevatचा purna block
        done = last_finished_block_ms(now_udya)
        check("10:00 IST la shevatचा purna block = aaj 05:30",
              done == t_block, format_ist(done) if done else "-")

        done2 = last_finished_block_ms(t_block + 90 * MINUTE_MS)
        check("07:00 IST la shevatचा purna block = kalcha (udya nahi)",
              done2 == t_block - DAY_MS, format_ist(done2) if done2 else "-")

        # sगळे blocks mode
        ALL_BLOCKS = True
        check("--blocks all -> dar 4h la ek block", len(window_list()) == 6)
        ALL_BLOCKS = False

        # ---- [6] nod (doharA alert nahi) ----
        print()
        print("[6] NOD (doharA alert nahi)")

        SENT_ALERTS = {}
        rows = three_candles(block, 1.00, 0.70, 0.70, 1.00, 0.70, 0.70, 4.00, 0.80, 0.80)

        m1 = scan_symbol("AAAUSDT", rows, block)
        check("scan_symbol -> jhuणले", m1 is not None)
        check("key = SYMBOL|block|tincandle",
              m1 and m1["key"] == f"AAAUSDT|{block}|tincandle")

        if m1:
            SENT_ALERTS[m1["key"]] = block

        m2 = scan_symbol("AAAUSDT", rows, block)

        check("punha tapasal tar nod madhe aahe (doharA nahi)",
              m2 is not None and m2["key"] in SENT_ALERTS)

        check("ek block, ek pair -> ek key", len(SENT_ALERTS) == 1)

        # ---- [7] digast message ----
        print()
        print("[7] DIGAST MESSAGE")

        SENT_ALERTS = {}

        fake = []
        for i, sym in enumerate(["AAAUSDT", "BBBUSDT"], 1):
            m = scan_symbol(sym, rows, block)
            if m:
                fake.append(m)

        header, body, footer = build_digest(fake, block, 732)

        txt = "\n".join(header + body + footer)

        for bit in ["TIN CANDLE PATTERN", "AAAUSDT", "BBBUSDT", "3री ÷ (1ली+2री)",
                    "2.00x", "Sagale pairs tapasalе : 732", "Jhalele pairs : 2"]:
            check(f"message madhe '{bit}'", bit in txt)

        check("body/close % message madhe", "body 70%" in txt or "body 70.0%" in txt or
              "body 70" in txt)

        # लांब digast tukड्यात jatो
        many = []

        for i in range(40):
            m = scan_symbol(f"SYM{i}USDT", rows, block)
            if m:
                many.append(m)

        header, body, footer = build_digest(many, block, 732)
        chunks = []
        current = list(header)

        for i, m in enumerate(many, 1):
            a, b, c = m["candles"]
            da, db, dc = m["details"]
            blk = [f"{i}) {m['symbol']}"] + [
                candle_line(n, d, cc) for n, d, cc in
                (("1ली", da, a), ("2री", db, b), ("3री", dc, c))]
            blk.append("")
            if sum(len(x) + 1 for x in current + blk) > MESSAGE_LIMIT:
                chunks.append("".join(current))
                current = ["… (pudhe)"]
            current.extend(blk)

        current.extend(footer)
        chunks.append("".join(current))

        check("40 pairs -> kai messages madhe faडतो", len(chunks) >= 2, f"{len(chunks)}")
        check("    pratyek message haddेत", all(
            sum(len(x) + 1 for x in [c]) <= MESSAGE_LIMIT + 200 for c in chunks))

        # ---- [8] dry run ----
        print()
        print("[8] DRY RUN")

        before = DIGESTS_SENT
        SENT_ALERTS = {}
        good = scan_symbol("DRYUSDT", rows, block)
        ok = send_digest([good], block, 732) if good else False
        check("dry run madhe digast count vadhat nahi", DIGESTS_SENT == before)

        # ---- [9] kami data ----
        print()
        print("[9] KAMI / ARDHI DATA")

        check("fakt 2 meणbattya -> nahi",
              scan_symbol("X", rows[:2], block) is None)
        check("block chya baher chya meणbattya -> nahi",
              scan_symbol("X", rows, block + 7 * DAY_MS) is None)
        check("sapाट data -> nahi", scan_symbol(
            "X", [c1h(block + i * 60 * MINUTE_MS, 100, 100, 100, 100)
                  for i in range(3)], block) is None)

    finally:

        (DRY_RUN, STATE_FILE, sent, BASE_OF_2X, MUST_BE_GREEN,
         win, allb) = saved

        SENT_ALERTS = sent
        WINDOWS_IST = win
        ALL_BLOCKS = allb

        for f in (tmp_state, tmp_state + ".tmp"):
            if os.path.isfile(f):
                os.remove(f)

    print()
    print("=" * 72)
    print(f" निकाल : {PASS} pass, {FAIL} fail")
    print("=" * 72)

    return 0 if FAIL == 0 else 1


# ============================================================
# MAIN LOOP
# ============================================================

def main_loop(symbols):

    load_state()

    print(f"Symbols: {len(symbols)}", flush=True)

    while True:

        target = next_target_ms()

        if target is None:
            print("pudhचa वेळ sapadla nahi — 5 minanni punha", flush=True)
            time.sleep(300)
            continue

        wait_s = (target - now_ms()) / 1000.0

        print()
        print(f"Pudhचa scan : {format_ist(target)}  ({wait_s / 60:.0f} minanni)",
              flush=True)

        while True:

            left = (target - now_ms()) / 1000.0

            if left <= 0:
                break

            time.sleep(min(60, max(1, left)))

        # 3री meणbatti band zhालi — thoda वेळ थांबा aani sगळे pairs tapasa
        time.sleep(WINDOW_END_WAIT)

        block = target - 3 * 60 * MINUTE_MS

        print()
        print("=" * 72)
        print(f"SCAN : {format_ist(target)}  (block {hhmm_ist(block)} IST)", flush=True)
        print("=" * 72)

        try:
            scan_all(symbols, block, allow_alert=True, show=False)

            print(f"HEARTBEAT | scans {SCANS_DONE} | digast {DIGESTS_SENT} | "
                  f"nod {len(SENT_ALERTS)}", flush=True)

            with LOCK:
                prune_state()
                save_state()

        except KeyboardInterrupt:
            print("(थांबवले)", flush=True)
            return

        except Exception as e:
            print("scan error:", e, flush=True)

        # sगळे pairs punha tayaar (roj nave pairs yetat)
        try:
            fresh = fetch_active_symbols()
            if len(fresh) != len(symbols):
                print(f"symbols update : {len(symbols)} -> {len(fresh)}", flush=True)
                symbols = fresh
        except Exception:
            pass


# ============================================================
# MAIN
# ============================================================

def main():

    ap = argparse.ArgumentParser(description="TIN CANDLE SCANNER — 3 meणbatti (4h)")

    ap.add_argument("--test", action="store_true", help="swatahchi chaanणी (network nahit)")
    ap.add_argument("--once", action="store_true",
                    help="fakt ekda tapasa (shevatचा purna zhालेला block)")
    ap.add_argument("--dry-run", action="store_true", help="fakt log — Telegram nahi")
    ap.add_argument("--show", action="store_true", help="jhuणलेले pairs dakhva")
    ap.add_argument("--symbol", default="", help="fakt ha ek symbol")
    ap.add_argument("--symbols", type=int, default=0, help="fakt pahlे itke symbols")
    ap.add_argument("--window", default="", help="block chi suruवात (IST) : 05:30")
    ap.add_argument("--blocks", default="", choices=["", "one", "all"],
                    help="one = fakt --window (default) | all = dar 4h la")

    args = ap.parse_args()

    global DRY_RUN, ALL_BLOCKS, WINDOWS_IST

    if args.dry_run:
        DRY_RUN = True

    if args.window:
        WINDOWS_IST = [args.window]

    if args.blocks == "all":
        ALL_BLOCKS = True
    elif args.blocks == "one":
        ALL_BLOCKS = False

    if args.test:
        sys.exit(self_test())

    banner()

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("⚠️ Telegram aakडे nahit — fakt log madhe disेl.", flush=True)

    try:
        if args.symbol:
            symbols = [args.symbol.upper()]
        else:
            symbols = fetch_active_symbols()
            if args.symbols:
                symbols = symbols[:args.symbols]

    except Exception as e:
        print("symbols aणता alе nahit:", e, flush=True)
        sys.exit(1)

    if args.once:

        load_state()

        block = last_finished_block_ms()

        if block is None:
            print("purna zhालेला block sapadla nahi.", flush=True)
            sys.exit(1)

        print()
        print("=" * 72)
        print(f"SCAN : block {format_ist(block)}  "
              f"({hhmm_ist(block)} – {hhmm_ist(block + 3 * 60 * MINUTE_MS)} IST)")
        print("=" * 72)

        found, new, err = scan_all(symbols, block, allow_alert=not DRY_RUN, show=True)

        print()
        print(f"झालं : {found} pairs jhale | {new} nave | {err} errors", flush=True)
        sys.exit(0)

    main_loop(symbols)


if __name__ == "__main__":
    main()
