import os
import sys
import json
import time
import threading
from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from dotenv import load_dotenv


# ============================================================
# CONFIG
# ============================================================

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

BINANCE_BASE = "https://fapi.binance.com"

# Final timeframe -> component candle (minutes)
TIMEFRAMES = {
    "1h": 30,
    "2h": 60,
    "4h": 120,
    "8h": 240,
}

BODY_THRESHOLD = 0.50          # 1ल्या meणbatti cha body >= 50%  (26-09 : 60% -> 50%)

# ============================================================
# INDICATOR NIYAM — MOMENTUM (length 1) : KHAMBACHI UNCHI
# ============================================================
# Momentum value (length 1) = meणbatti cha pravas = band - udghad.
# TradingView var ti khambа (histogram) svarupat dakhvli jate - khambа
# *maagchya value pasun aajchya value paryant* rangvla jato. Mhanje
# khambachi unchi = momentum value madhla badal.
#
#   m0 = 1ल्याच्या aadhi-chi component meणbatti
#   m1 = 1ली component meणbatti        ->  khambа 1 = m1 - m0
#   m2 = 2री component meणbatti        ->  khambа 2 = m2 - m1
#
# Niyam : |khambа 2|  >=  MOMENTUM_MULTIPLIER x |khambа 1|   aani ulaट disha.
MOMENTUM_ENABLED = True      # khota kelа tar indicator adti purn band
MOMENTUM_LENGTH = 1
MOMENTUM_MULTIPLIER = 3.0    # 2ऱ्या khambа = 1ल्याच्या kiti pat
MOMENTUM_REQUIRE_OPPOSITE = True   # donhi khambа ulaट disheche havit (V / ulaट-V)
MOMENTUM_EPSILON = 1e-9      # agadi 3x asleli meणbatti radd hou naye mhanun


def candle_momentum(candle):
    """Momentum (length 1) chi value = meणbatti cha pravas (band - udghad)."""
    return candle["close"] - candle["open"]


def momentum_stick(previous, candle):
    """Khambachi unchi = ya value madhun maagchya value chi vajabaki."""
    return candle_momentum(candle) - candle_momentum(previous)


def momentum_sticks(previous, first, second):
    """Donhi khambа: (1ला, 2रा). 'previous' nasel tar 1ला = swatahchi value."""
    if previous is None:
        s1 = candle_momentum(first)
    else:
        s1 = momentum_stick(previous, first)
    s2 = momentum_stick(first, second)
    return s1, s2


def momentum_ratio(previous, first, second):
    """2ऱ्या khambа ÷ 1ल्या khambа (pat). Kalkhan zala tar None."""
    s1, s2 = momentum_sticks(previous, first, second)
    if abs(s1) <= 0:
        return None
    return abs(s2) / abs(s1)


def momentum_ok(previous, first, second):
    """Indicator niyam jugla tar True."""
    if not MOMENTUM_ENABLED:
        return True

    s1, s2 = momentum_sticks(previous, first, second)

    if abs(s1) <= 0:
        return False

    if MOMENTUM_REQUIRE_OPPOSITE and (s1 > 0) == (s2 > 0):
        return False

    return abs(s2) >= MOMENTUM_MULTIPLIER * abs(s1) - MOMENTUM_EPSILON * abs(s1)
CLOSE_LOW_THRESHOLD = 0.50     # bearish (Scanner 1,3) : final close <= 50%  (26-09 : 30% -> 50%)
CLOSE_HIGH_THRESHOLD = 0.50    # bullish (Scanner 2,4) : final close >= 50%  (26-09 : 70% -> 50%)

BASE_INTERVAL_MS = 15 * 60 * 1000

# 64 x 15m = 16 hours
KLINE_LIMIT = 64

MAX_WORKERS = 20

IST = timezone(timedelta(hours=5, minutes=30))

ALERT_FILE = "alerts_sent.json"

TEST_MODE = "--test" in sys.argv

# ---- alerts_sent.json AUTO CLEANUP ------------------------------

# itkya divsaांpeksha junya keys automatic kadhli jatat.
# Ek key fakt tichya final candle chya confirmation window madhe
# ekdach trigger hou shakto (maximum 4 tas) - mhanun 30 divas
# khup surक्षित aahe. Junya keys kadhlyane ekhi navin alert
# block hou shakat nahi.
ALERT_RETENTION_DAYS = 30

# kiti velanni prune karaवे (6 tas = divasat 4 velा)
PRUNE_INTERVAL_SECONDS = 6 * 60 * 60

# disk itका kami zala tar heartbeat madhe LOW DISK warning
LOW_DISK_MB = 500

# WATCHDOG: price feed itkya secondांपेक्षा jast thambla tar
# process स्वतःch बंद hoतो आणि systemd (Restart=always) punha
# suru karto. Thread मेला tari system जिवंत rahto.
FEED_STALE_EXIT_SECONDS = 300

# prun karण्यापूर्वी ekdach yeणारा backup
BACKUP_FILE = ALERT_FILE + ".bak"

# ---- price feed ------------------------------------------------

# sagle symbols chya kimati kiti secondanni tapatasat
POLL_INTERVAL = 2.0

# running confirmation candle 1m varun kiti secondanni tapatasat (wick insurance)
SWEEP_INTERVAL = 20.0

# ekा sweep madhe jastit-jast kiti setups (kimati level la javळ chya aadhi)
SWEEP_MAX_SETUPS = 40
SWEEP_WORKERS = 5
SWEEP_KLINE_LIMIT = 300

# dar kiti secondala journal madhe jivantपणाची ओळ
HEARTBEAT_SECONDS = 60.0

# Telegram delivery
TELEGRAM_RETRIES = 3
TELEGRAM_RETRY_DELAY = 2.0

# Ekach alert sathi punha-punha Telegram prayatna kiti secondanni
SEND_RETRY_COOLDOWN_MS = 30 * 1000

# eवdhe prayatna zalyavar "give up" (pan setup window paryant chalu rahto)
MAX_SEND_ATTEMPTS = 40


# ============================================================
# GLOBAL STATE
# ============================================================

_thread_local = threading.local()

ACTIVE_SYMBOLS = set()

# key: SYMBOL|TIMEFRAME|FINAL_OPEN_TIME|SCANNER
ACTIVE_SETUPS = {}

LOCK = threading.Lock()

# ekach taseek punha scan hou naye
LAST_SCAN_KEYS = set()

SENT_ALERTS = set()

# price cache (heartbeat sathi + sweep ordering sathi)
PRICE_CACHE = {}

# server time offset
TIME_OFFSET_MS = 0

# heartbeat stats
POLL_COUNT = 0
LAST_POLL_MS = 0
LAST_PRICE_COUNT = 0
LAST_POLL_ERROR = None
SWEEP_COUNT = 0
LAST_SWEEP_MS = 0
ALERTS_SENT_COUNT = 0
LAST_PRUNE_MS = 0


# ============================================================
# HTTP
# ============================================================

def get_session():

    if not hasattr(_thread_local, "session"):

        _thread_local.session = requests.Session()

        _thread_local.session.headers.update({
            "User-Agent": "Binance-Futures-Scanner/4.0",
        })

    return _thread_local.session


def get_server_time_ms():

    response = get_session().get(
        f"{BINANCE_BASE}/fapi/v1/time",
        timeout=10,
    )

    response.raise_for_status()

    return int(response.json()["serverTime"])


def refresh_time_offset():

    global TIME_OFFSET_MS

    try:

        TIME_OFFSET_MS = (
            get_server_time_ms()
            -
            int(time.time() * 1000)
        )

    except Exception as e:

        print("Time offset refresh error:", e, flush=True)


def now_ms():

    return int(time.time() * 1000) + TIME_OFFSET_MS


# ============================================================
# TELEGRAM
# ============================================================

def send_telegram(message):

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:

        print("Telegram configuration missing.", flush=True)

        return False

    url = (
        "https://api.telegram.org/bot"
        f"{TELEGRAM_BOT_TOKEN}/sendMessage"
    )

    try:

        response = requests.post(
            url,
            data={
                "chat_id": TELEGRAM_CHAT_ID,
                "text": message,
            },
            timeout=15,
        )

        response.raise_for_status()

        data = response.json()

        if data.get("ok"):
            return True

        print("Telegram error:", data.get("description"), flush=True)

        return False

    except Exception as e:

        print("Telegram request error:", e, flush=True)

        return False


def send_telegram_retry(message):

    for attempt in range(1, TELEGRAM_RETRIES + 1):

        if send_telegram(message):
            return True

        print(
            f"Telegram attempt {attempt}/{TELEGRAM_RETRIES} failed",
            flush=True,
        )

        if attempt < TELEGRAM_RETRIES:
            time.sleep(TELEGRAM_RETRY_DELAY)

    return False


# ============================================================
# ALERT FILE
# ============================================================

def load_sent_alerts():

    try:

        with open(ALERT_FILE, "r") as f:
            data = json.load(f)

        if isinstance(data, list):
            return set(data)

        print(
            "WARNING: alerts file madhe list nahi - rikami suruvat",
            flush=True,
        )

        return set()

    except FileNotFoundError:

        return set()

    except Exception as e:

        # fail aala tari scanner thambat nahi, fakt kalavतो
        print(
            "WARNING: alerts file vachta ala nahi (",
            e,
            ") - rikami suruvat. Junya dedupe mahiti milali nahi.",
            flush=True,
        )

        return set()


SENT_ALERTS = load_sent_alerts()


def save_sent_alerts():

    # ATOMIC write:
    # adhi .tmp madhe lihito, fsync karto, mag os.replace() ne
    # ekाच step madhe jaga badalto. Power gelा / process thambला
    # tari मूळ file kधीch adhiचya ar्धवट state madhe rahat nahi.
    tmp = ALERT_FILE + ".tmp"

    try:

        with open(tmp, "w") as f:

            json.dump(sorted(SENT_ALERTS), f, indent=2)

            f.flush()
            os.fsync(f.fileno())

        os.replace(tmp, ALERT_FILE)

    except Exception as e:

        print("Alert file save error:", e, flush=True)

        try:
            os.path.exists(tmp) and os.remove(tmp)
        except Exception:
            pass


# ============================================================
# CLEANUP  (automatic, crash-safe)
# ============================================================

def parse_alert_key_ms(key):

    """Current-format key madhlा final_open_time (ms).

    Current format:  SYMBOL|timeframe|<ms>|Scanner N
    Itar konताही format => None (junya pidyेची key)
    """

    parts = key.split("|")

    if len(parts) != 4:
        return None

    try:
        value = int(parts[2])

    except (TypeError, ValueError):
        return None

    # karyakari epoch ms (2001 te 2033) - itar kाही tar aahe tar sodun द्या
    if not (10 ** 12 <= value <= 2 * 10 ** 12):
        return None

    return value


def alerts_file_size_kb():

    try:
        return os.path.getsize(ALERT_FILE) // 1024

    except Exception:
        return -1


def rss_mb():

    """Process ची memory (MB) - leak kalण्यासाठी"""

    try:

        with open("/proc/self/statm") as f:
            pages = int(f.read().split()[1])

        return (
            pages
            * os.sysconf("SC_PAGE_SIZE")
            // (1024 * 1024)
        )

    except Exception:

        return None


def feed_is_stale(current_ms):

    """Price feed 5 minांपेksha jast thambला ka?

    Suravatी (pahila poll yetoच) false - grace.
    """

    if POLL_COUNT == 0 or LAST_POLL_MS == 0:
        return False

    return (
        current_ms - LAST_POLL_MS
        >
        FEED_STALE_EXIT_SECONDS * 1000
    )


def free_disk_mb(path="."):

    try:
        st = os.statvfs(path)

        return (st.f_bavail * st.f_frsize) // (1024 * 1024)

    except Exception:
        return None


def prune_sent_alerts(current_ms, force=False, quiet=False):

    """Junya + jun्या format chya alert keys kadhून टाकतो.

    SURAKSHIT ka aahe:
      - ek key fakt tichya confirmation window madhe ekdach trigger
        hou shakto (max 4 tas). 30 divsांपेksha junya key kधीch
        punha lagat nahi.
      - jun्या pidyेच्या (3-part / text) keys aataच्या format shi
        kधीch jujat nahit - mhanun tya ekhi navin alert block
        karू shakat nahit.
      - prun mhanje fakt SET ("key aahe ka nahi") madhun kadणे.
        Tyaमुळे चूकीचा alert YET nahi.
      - ACTIVE_SETUPS la kाहीch hot nahi.
    """

    global LAST_PRUNE_MS

    if not force:

        if (
            LAST_PRUNE_MS
            and current_ms - LAST_PRUNE_MS
            < PRUNE_INTERVAL_SECONDS * 1000
        ):
            return 0

    LAST_PRUNE_MS = current_ms

    cutoff = current_ms - ALERT_RETENTION_DAYS * 86400 * 1000

    with LOCK:

        if not SENT_ALERTS:
            return 0

        keep = set()
        dropped_old = 0
        dropped_legacy = 0

        for key in SENT_ALERTS:

            stamp = parse_alert_key_ms(key)

            if stamp is None:
                dropped_legacy += 1
                continue

            if stamp < cutoff:
                dropped_old += 1
                continue

            keep.add(key)

        removed = len(SENT_ALERTS) - len(keep)

        if removed:

            # prथमच prun madhe ekdach junी file japun theवतो
            if not os.path.exists(BACKUP_FILE):

                try:
                    with open(BACKUP_FILE, "w") as f:
                        json.dump(sorted(SENT_ALERTS), f, indent=2)

                    if not quiet:
                        print(
                            "alerts backup thevला:",
                            BACKUP_FILE,
                            flush=True,
                        )

                except Exception as e:

                    print("Backup error:", e, flush=True)

            SENT_ALERTS.clear()
            SENT_ALERTS.update(keep)

            save_sent_alerts()

        if not quiet and removed:

            print(
                "ALERTS FILE PRUNED:",
                f"{removed} junya keys kadhlya",
                f"(jun्या format: {dropped_legacy},",
                f"{ALERT_RETENTION_DAYS} divsांpeksha juni: {dropped_old})",
                f"| urल्या: {len(keep)}",
                flush=True,
            )

    return removed


def cleanup_temp_files():

    try:

        tmp = ALERT_FILE + ".tmp"

        if os.path.exists(tmp):
            os.remove(tmp)
            print("stale temp file kadhली:", tmp, flush=True)

    except Exception as e:

        print("temp cleanup error:", e, flush=True)


# ============================================================
# SYMBOLS
# ============================================================

def fetch_active_symbols():

    response = get_session().get(
        f"{BINANCE_BASE}/fapi/v1/exchangeInfo",
        timeout=20,
    )

    response.raise_for_status()

    data = response.json()

    symbols = set()

    for item in data.get("symbols", []):

        if (
            item.get("status") == "TRADING"
            and
            item.get("quoteAsset") == "USDT"
        ):

            symbols.add(item["symbol"])

    return sorted(symbols)


# ============================================================
# CANDLES
# ============================================================

def fetch_closed_15m_candles(symbol):

    response = get_session().get(
        f"{BINANCE_BASE}/fapi/v1/klines",
        params={
            "symbol": symbol,
            "interval": "15m",
            "limit": KLINE_LIMIT,
        },
        timeout=15,
    )

    response.raise_for_status()

    current = now_ms()

    candles = []

    for k in response.json():

        open_time = int(k[0])
        close_time = int(k[6])

        # chालू 15m candle sodun टाका
        if close_time >= current:
            continue

        candles.append({
            "open_time": open_time,
            "open": float(k[1]),
            "high": float(k[2]),
            "low": float(k[3]),
            "close": float(k[4]),
            "close_time": close_time,
        })

    return candles


def aggregate_candles(base_candles, minutes):

    group_ms = minutes * 60 * 1000

    grouped = {}

    for candle in base_candles:

        bucket = (candle["open_time"] // group_ms) * group_ms

        grouped.setdefault(bucket, []).append(candle)

    result = []

    required_parts = minutes // 15

    for bucket, parts in grouped.items():

        parts.sort(key=lambda x: x["open_time"])

        if len(parts) != required_parts:
            continue

        expected = [
            bucket + i * BASE_INTERVAL_MS
            for i in range(required_parts)
        ]

        actual = [x["open_time"] for x in parts]

        if actual != expected:
            continue

        result.append({
            "open_time": bucket,
            "open": parts[0]["open"],
            "high": max(x["high"] for x in parts),
            "low": min(x["low"] for x in parts),
            "close": parts[-1]["close"],
            "close_time": bucket + group_ms - 1,
        })

    result.sort(key=lambda x: x["open_time"])

    return result


# ============================================================
# CANDLE HELPERS
# ============================================================

def candle_body_ratio(candle):

    candle_range = candle["high"] - candle["low"]

    if candle_range <= 0:
        return 0.0

    return abs(candle["close"] - candle["open"]) / candle_range


def close_position(candle):

    candle_range = candle["high"] - candle["low"]

    if candle_range <= 0:
        return None

    return (candle["close"] - candle["low"]) / candle_range


# ============================================================
# SCANNERS 1-4  (v1 sarkhech - kaलेलाच logic)
# ============================================================

def scanner_result(first, second, final_candle, previous=None):

    final_position = close_position(final_candle)

    if final_position is None:
        return None

    # INDICATOR niyam (momentum khambа) — doghe niyam jhale tarach alert.
    momentum_pass = momentum_ok(previous, first, second)

    # --- Scanner 1 : Bearish Reversal ------------------------
    scanner_1 = (
        first["close"] > first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] < second["open"]
        and second["high"] < first["high"]
        and second["low"] > first["low"]
        and final_position <= CLOSE_LOW_THRESHOLD
        and momentum_pass
    )

    if scanner_1:

        return {
            "scanner": "Scanner 1",
            "direction": "Bearish Reversal",
            "condition": "Scanner 1 - Bearish Reversal",
            "position": final_position,
        }

    # --- Scanner 2 : Bullish Reversal ------------------------
    scanner_2 = (
        first["close"] < first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] > second["open"]
        and second["high"] < first["high"]
        and second["low"] > first["low"]
        and final_position >= CLOSE_HIGH_THRESHOLD
        and momentum_pass
    )

    if scanner_2:

        return {
            "scanner": "Scanner 2",
            "direction": "Bullish Reversal",
            "condition": "Scanner 2 - Bullish Reversal",
            "position": final_position,
        }

    # --- Scanner 3 : Bearish (high break) -------------------
    scanner_3 = (
        first["close"] > first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] < second["open"]
        and second["high"] > first["high"]
        and second["low"] > first["low"]
        and final_position <= CLOSE_LOW_THRESHOLD
        and momentum_pass
    )

    if scanner_3:

        return {
            "scanner": "Scanner 3",
            "direction": "Bearish Reversal",
            "condition": "Scanner 3 - High Break Bearish Reversal",
            "position": final_position,
        }

    # --- Scanner 4 : Bullish (low break) --------------------
    scanner_4 = (
        first["close"] < first["open"]
        and candle_body_ratio(first) >= BODY_THRESHOLD
        and second["close"] > second["open"]
        and second["low"] < first["low"]
        and second["high"] < first["high"]
        and final_position >= CLOSE_HIGH_THRESHOLD
        and momentum_pass
    )

    if scanner_4:

        return {
            "scanner": "Scanner 4",
            "direction": "Bullish Reversal",
            "condition": "Scanner 4 - Low Break Bullish Reversal",
            "position": final_position,
        }

    return None


# ============================================================
# SETUP DETECTION
# ============================================================

def detect_setup(base_candles, timeframe):

    component_minutes = TIMEFRAMES[timeframe]
    final_minutes = int(timeframe[:-1]) * 60

    component_candles = aggregate_candles(base_candles, component_minutes)
    final_candles = aggregate_candles(base_candles, final_minutes)

    if not final_candles:
        return None

    final_candle = final_candles[-1]
    final_start = final_candle["open_time"]
    final_end = final_start + final_minutes * 60 * 1000

    parts = [
        c for c in component_candles
        if final_start <= c["open_time"] < final_end
    ]

    if len(parts) != 2:
        return None

    parts.sort(key=lambda x: x["open_time"])

    first, second = parts[0], parts[1]

    # INDICATOR niyamासाठी : 1ल्याच्या *aadhi*chi component meणbatti (m0).
    # Ti na saapडली tar (data madhe khali) m0 = 0 dharli jate.
    previous = None

    for candle in component_candles:

        if candle["open_time"] == first["open_time"] - component_minutes * 60 * 1000:

            previous = candle
            break

    result = scanner_result(first, second, final_candle, previous)

    if result is None:
        return None

    confirmation_start = final_end
    confirmation_end = (
        confirmation_start
        +
        component_minutes * 60 * 1000
    )

    return {
        "scanner": result["scanner"],
        "direction": result["direction"],
        "condition": result["condition"],
        "position": result["position"],
        "first": first,
        "second": second,
        "final": final_candle,
        "confirmation_start": confirmation_start,
        "confirmation_end": confirmation_end,
        "confirmation_high": None,
        "confirmation_low": None,
    }


# ============================================================
# TIME FORMAT
# ============================================================

def format_ist(timestamp_ms):

    dt = datetime.fromtimestamp(
        timestamp_ms / 1000,
        timezone.utc,
    ).astimezone(IST)

    return dt.strftime("%d-%m-%Y %H:%M:%S IST")


# ============================================================
# ALERT MESSAGE
# ============================================================

def make_alert(symbol, timeframe, setup, current_price, event_time):

    final = setup["final"]
    first = setup["first"]
    second = setup["second"]

    position_percent = setup["position"] * 100

    # INDICATOR niyam (momentum khambа) che aakडे
    _s1, _s2 = momentum_sticks(setup.get("previous"), first, second)
    _ratio = momentum_ratio(setup.get("previous"), first, second)
    momentum_line = (
        f"Momentum (len {MOMENTUM_LENGTH}): "
        f"1st {candle_momentum(first):+.4f}  ->  2nd {candle_momentum(second):+.4f}"
        f"  |  sticks {_s1:+.4f} / {_s2:+.4f}"
        f"  =  {'--' if _ratio is None else f'{_ratio:.2f}x'}"
        f" (niyam: >= {MOMENTUM_MULTIPLIER:.2f}x)\n"
    )

    if setup["direction"] == "Bearish Reversal":

        close_rule = f"Close <= {CLOSE_LOW_THRESHOLD * 100:.0f}% from Low"
        break_rule = "Running Low < Final Low"

    else:

        close_rule = f"Close >= {CLOSE_HIGH_THRESHOLD * 100:.0f}% from Low"
        break_rule = "Running High > Final High"

    confirmation_high = (
        setup["confirmation_high"]
        if setup["confirmation_high"] is not None
        else current_price
    )

    confirmation_low = (
        setup["confirmation_low"]
        if setup["confirmation_low"] is not None
        else current_price
    )

    message = (

        "🚨 BINANCE FUTURES LIVE ALERT\n"
        "\n"
        f"Pair: {symbol}\n"
        f"Timeframe: {timeframe}\n"
        f"{setup['scanner']} - {setup['direction']}\n"
        "\n"
        f"Close Position: {position_percent:.2f}%\n"
        f"Rule: {close_rule}\n"
        f"Confirmation: {break_rule}\n"
        "\n"
        f"Final Open: {final['open']}\n"
        f"Final High: {final['high']}\n"
        f"Final Low: {final['low']}\n"
        f"Final Close: {final['close']}\n"
        "\n"
        f"1st Candle Open: {first['open']}\n"
        f"1st Candle High: {first['high']}\n"
        f"1st Candle Low: {first['low']}\n"
        f"1st Candle Close: {first['close']}\n"
        f"1st Body: {candle_body_ratio(first) * 100:.2f}%\n"
        "\n"
        f"2nd Candle Open: {second['open']}\n"
        f"2nd Candle High: {second['high']}\n"
        f"2nd Candle Low: {second['low']}\n"
        f"2nd Candle Close: {second['close']}\n"
        + momentum_line
        + "\n"
        f"Running Confirmation High: {confirmation_high}\n"
        f"Running Confirmation Low: {confirmation_low}\n"
        f"Break Price: {current_price}\n"
        f"Break Time: {format_ist(event_time)}\n"
        "\n"
        f"Final Closed: {format_ist(final['close_time'] + 1)}"
    )

    return message


# ============================================================
# SETUP BOOKKEEPING
# ============================================================

def setup_key(symbol, timeframe, setup):

    return (
        f"{symbol}|"
        f"{timeframe}|"
        f"{setup['final']['open_time']}|"
        f"{setup['scanner']}"
    )


def setup_is_bearish(setup):

    return setup["direction"] == "Bearish Reversal"


def setup_level(setup):

    if setup_is_bearish(setup):
        return setup["final"]["low"]

    return setup["final"]["high"]


def register_setup(symbol, timeframe, setup):

    key = setup_key(symbol, timeframe, setup)

    with LOCK:

        if key in ACTIVE_SETUPS:
            return False

        if key in SENT_ALERTS:
            return False

        ACTIVE_SETUPS[key] = {
            **setup,
            "symbol": symbol,
            "timeframe": timeframe,
            "key": key,
            "send_attempts": 0,
            "last_attempt_ms": 0,
        }

    print(
        "SETUP REGISTERED:",
        symbol,
        timeframe,
        setup["scanner"],
        setup["direction"],
        "| Confirmation:",
        format_ist(setup["confirmation_start"]),
        "to",
        format_ist(setup["confirmation_end"]),
        flush=True,
    )

    return True


def cleanup_expired_setups(current_ms, quiet=False):

    expired = []

    with LOCK:

        for key, setup in ACTIVE_SETUPS.items():

            if current_ms >= setup["confirmation_end"]:
                expired.append(key)

        for key in expired:

            setup = ACTIVE_SETUPS.pop(key, None)

            if setup and not quiet:

                print(
                    "SETUP EXPIRED:",
                    setup["symbol"],
                    setup["timeframe"],
                    setup["scanner"],
                    flush=True,
                )

    return expired


# ============================================================
# ALERT DELIVERY
#
# KEY v2 badal: Telegram YASHASWI zalyavarach key sathavli jate
# आणि setup kadla jato. Fail zala tar setup chalu rahto.
# ============================================================

def deliver_alert(key, price, event_time):

    global ALERTS_SENT_COUNT

    with LOCK:

        current = ACTIVE_SETUPS.get(key)

        if current is None:
            return

        setup = dict(current)

        # khup velat punha punha prayatna karu naye
        if setup["send_attempts"] >= MAX_SEND_ATTEMPTS:
            return

        # adhiच्या fail nantar thodा वेळ थांबा
        # (pahिला prayatna cooldown mule thambu naye)
        if (
            setup["send_attempts"] > 0
            and
            event_time - setup["last_attempt_ms"]
            <
            SEND_RETRY_COOLDOWN_MS
        ):
            return

        current["last_attempt_ms"] = event_time
        current["send_attempts"] = setup["send_attempts"] + 1

    message = make_alert(
        setup["symbol"],
        setup["timeframe"],
        setup,
        price,
        event_time,
    )

    print()
    print(
        "🚨 ALERT:",
        setup["symbol"],
        setup["timeframe"],
        setup["scanner"],
        price,
        "|",
        format_ist(event_time),
        flush=True,
    )

    if TEST_MODE:

        print("TEST MODE: Telegram alert suppressed", flush=True)

        sent = True

    else:

        sent = send_telegram_retry(message)

    with LOCK:

        if sent:

            SENT_ALERTS.add(key)
            ACTIVE_SETUPS.pop(key, None)
            save_sent_alerts()

            ALERTS_SENT_COUNT += 1

        else:

            print(
                "TELEGRAM FAILED - alert haravla nahi; setup chalu",
                "(pudhchya tika la punha prayatna hoil):",
                setup["symbol"],
                setup["timeframe"],
                flush=True,
            )

    if sent:

        print(
            "✅ ALERT DELIVERED:",
            setup["symbol"],
            setup["timeframe"],
            setup["scanner"],
            flush=True,
        )


# ============================================================
# PRICE -> TRIGGER CHECK
#
# Ek price gheun sagळ्या active setups tapatasat.
# ============================================================

def update_extremes(setup, price):

    if setup["confirmation_high"] is None:

        setup["confirmation_high"] = price
        setup["confirmation_low"] = price

    else:

        setup["confirmation_high"] = max(
            setup["confirmation_high"],
            price,
        )

        setup["confirmation_low"] = min(
            setup["confirmation_low"],
            price,
        )


def process_prices(prices, event_time):

    triggered = []

    cleanup_expired_setups(event_time, quiet=True)

    with LOCK:

        for key, setup in list(ACTIVE_SETUPS.items()):

            price = prices.get(setup["symbol"])

            if price is None:
                continue

            if not (
                setup["confirmation_start"]
                <= event_time
                <
                setup["confirmation_end"]
            ):
                continue

            update_extremes(setup, price)

            if setup_is_bearish(setup):

                if price < setup["final"]["low"]:
                    triggered.append((key, price))

            else:

                if price > setup["final"]["high"]:
                    triggered.append((key, price))

    for key, price in triggered:

        deliver_alert(key, price, event_time)


def process_price(symbol, price, event_time):

    process_prices({symbol: price}, event_time)


# ============================================================
# PRICE FEED (REST polling)
# ============================================================

def fetch_all_prices():

    response = get_session().get(
        f"{BINANCE_BASE}/fapi/v1/ticker/price",
        timeout=15,
    )

    response.raise_for_status()

    prices = {}

    for item in response.json():

        symbol = item.get("symbol")

        if not symbol:
            continue

        try:
            prices[symbol] = float(item["price"])

        except Exception:
            continue

    return prices


def price_loop():

    global POLL_COUNT, LAST_POLL_MS, LAST_PRICE_COUNT, LAST_POLL_ERROR

    while True:

        started = time.time()

        try:

            prices = fetch_all_prices()

            if prices:

                LAST_POLL_MS = now_ms()
                LAST_POLL_ERROR = None
                POLL_COUNT += 1
                LAST_PRICE_COUNT = len(prices)

                PRICE_CACHE.update(prices)

                process_prices(prices, LAST_POLL_MS)

        except Exception as e:

            LAST_POLL_ERROR = str(e)

            print("PRICE POLL ERROR:", e, flush=True)

        duration = time.time() - started

        time.sleep(max(0.2, POLL_INTERVAL - duration))


# ============================================================
# WICK INSURANCE : running confirmation candle cha 1m data
# ============================================================

def sweep_symbol(key, setup):

    response = get_session().get(
        f"{BINANCE_BASE}/fapi/v1/klines",
        params={
            "symbol": setup["symbol"],
            "interval": "1m",
            "startTime": setup["confirmation_start"],
            "limit": SWEEP_KLINE_LIMIT,
        },
        timeout=15,
    )

    response.raise_for_status()

    candles = [
        {
            "open_time": int(k[0]),
            "high": float(k[2]),
            "low": float(k[3]),
        }
        for k in response.json()
    ]

    if not candles:
        return

    current = now_ms()

    with LOCK:

        live = ACTIVE_SETUPS.get(key)

        if live is None:
            return

        if not (
            live["confirmation_start"]
            <= current
            <
            live["confirmation_end"]
        ):
            return

        high = max(c["high"] for c in candles)
        low = min(c["low"] for c in candles)

        if live["confirmation_high"] is None:

            live["confirmation_high"] = high
            live["confirmation_low"] = low

        else:

            live["confirmation_high"] = max(live["confirmation_high"], high)
            live["confirmation_low"] = min(live["confirmation_low"], low)

        bearish = setup_is_bearish(live)
        level = setup_level(live)

    hit = None

    for candle in candles:

        if bearish:

            if candle["low"] < level:
                hit = (candle["open_time"], candle["low"])
                break

        else:

            if candle["high"] > level:
                hit = (candle["open_time"], candle["high"])
                break

    if hit is not None:

        deliver_alert(key, hit[1], hit[0])


def do_kline_sweep():

    with LOCK:

        setups = [
            (key, dict(setup))
            for key, setup in ACTIVE_SETUPS.items()
        ]

    if not setups:
        return

    def distance(item):

        key, setup = item

        price = PRICE_CACHE.get(setup["symbol"])

        if price is None:
            return 9e9

        level = setup_level(setup)

        if level <= 0:
            return 9e9

        return abs(price - level) / level

    setups.sort(key=distance)

    setups = setups[:SWEEP_MAX_SETUPS]

    with ThreadPoolExecutor(max_workers=SWEEP_WORKERS) as executor:

        futures = [
            executor.submit(sweep_symbol, key, setup)
            for key, setup in setups
        ]

        for future in as_completed(futures):

            try:
                future.result()

            except Exception as e:

                print("Sweep error:", e, flush=True)


def sweep_loop():

    global SWEEP_COUNT, LAST_SWEEP_MS

    while True:

        time.sleep(SWEEP_INTERVAL)

        try:

            do_kline_sweep()

            SWEEP_COUNT += 1
            LAST_SWEEP_MS = now_ms()

        except Exception as e:

            print("Sweep loop error:", e, flush=True)


# ============================================================
# HEARTBEAT  (जिवंतपणाचा पुरावा)
# ============================================================

def heartbeat_loop():

    while True:

        time.sleep(HEARTBEAT_SECONDS)

        try:

            refresh_time_offset()

            with LOCK:

                setups = len(ACTIVE_SETUPS)

                closest = None
                closest_gap = None

                for setup in ACTIVE_SETUPS.values():

                    price = PRICE_CACHE.get(setup["symbol"])

                    if price is None:
                        continue

                    level = setup_level(setup)

                    if level <= 0:
                        continue

                    gap = abs(price - level) / level * 100

                    if closest_gap is None or gap < closest_gap:

                        closest_gap = gap
                        closest = setup

            poll_age = (
                (now_ms() - LAST_POLL_MS) / 1000
                if LAST_POLL_MS
                else -1
            )

            sweep_age = (
                (now_ms() - LAST_SWEEP_MS) / 1000
                if LAST_SWEEP_MS
                else -1
            )

            line = (
                f"HEARTBEAT | polls {POLL_COUNT}"
                f" | prices {LAST_PRICE_COUNT}"
                f" | active setups {setups}"
                f" | alerts sent {ALERTS_SENT_COUNT}"
                f" | last poll {poll_age:.1f}s ago"
                f" | last sweep {sweep_age:.1f}s ago"
            )

            # disk ani alerts file cha aकार (crash prevention)
            disk = free_disk_mb()

            if disk is not None:

                line += f" | disk {disk}MB free"

                if disk < LOW_DISK_MB:
                    line += "  <-- LOW DISK!"

            mem = rss_mb()

            if mem is not None:
                line += f" | rss {mem}MB"

            size_kb = alerts_file_size_kb()

            if size_kb >= 0:
                line += f" | alerts file {size_kb}KB ({len(SENT_ALERTS)} keys)"

            if closest is not None:

                line += (
                    f" | closest: {closest['symbol']} "
                    f"{closest['timeframe']} "
                    f"{closest_gap:.2f}% away"
                )

            if LAST_POLL_ERROR:

                line += f" | LAST POLL ERROR: {LAST_POLL_ERROR}"

            print(line, flush=True)

            # ---- WATCHDOG ----------------------------------
            # feed khup vel थांबला tar process band karto;
            # systemd Restart=always mule punha lagech suru hoto
            # (startup scan mule jivant setups punha register hotat).
            if feed_is_stale(now_ms()):

                stale = (now_ms() - LAST_POLL_MS) / 1000

                print(
                    f"WATCHDOG: price feed {stale:.0f}s thambla -",
                    "process band karto; systemd punha suru karel",
                    flush=True,
                )

                os._exit(1)

        except Exception as e:

            print("Heartbeat error:", e, flush=True)


# ============================================================
# SCANNING
# ============================================================

def scan_symbol(symbol, timeframes):

    try:

        candles = fetch_closed_15m_candles(symbol)

        results = []

        for timeframe in timeframes:

            setup = detect_setup(candles, timeframe)

            if setup is None:
                continue

            if register_setup(symbol, timeframe, setup):

                results.append((timeframe, setup["scanner"]))

        return symbol, results

    except Exception as e:

        return symbol, [("ERROR", str(e))]


def scan_all(timeframes):

    if not ACTIVE_SYMBOLS:
        return

    symbols = sorted(ACTIVE_SYMBOLS)

    print()
    print("==========================================")
    print("SETUP SCAN")
    print(
        datetime.now(IST).strftime("%d-%m-%Y %H:%M:%S"),
        "IST",
    )
    print("Symbols:", len(symbols))
    print("Timeframes:", ", ".join(timeframes))
    print("==========================================")

    found = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:

        futures = [
            executor.submit(scan_symbol, symbol, timeframes)
            for symbol in symbols
        ]

        for future in as_completed(futures):

            try:

                symbol, results = future.result()

                for timeframe, scanner in results:

                    if timeframe == "ERROR":

                        print("SCAN ERROR:", symbol, scanner, flush=True)
                        continue

                    found += 1

                    print("MATCH:", symbol, timeframe, scanner, flush=True)

            except Exception as e:

                print("Worker result error:", e, flush=True)

    print(
        "Setup scan complete. New setups:",
        found,
        flush=True,
    )


def due_timeframes(server_ms):

    dt = datetime.fromtimestamp(server_ms / 1000, timezone.utc)

    if dt.minute != 0:
        return []

    hour = dt.hour

    result = ["1h"]

    if hour % 2 == 0:
        result.append("2h")

    if hour % 4 == 0:
        result.append("4h")

    if hour % 8 == 0:
        result.append("8h")

    return result


def startup_timeframes(base_candles, current_ms):

    result = []

    for timeframe in TIMEFRAMES:

        component_minutes = TIMEFRAMES[timeframe]
        final_minutes = int(timeframe[:-1]) * 60

        final_candles = aggregate_candles(base_candles, final_minutes)

        if not final_candles:
            continue

        final_candle = final_candles[-1]

        final_end = (
            final_candle["open_time"]
            +
            final_minutes * 60 * 1000
        )

        confirmation_end = (
            final_end
            +
            component_minutes * 60 * 1000
        )

        if not (final_end <= current_ms < confirmation_end):
            continue

        parts = [
            c
            for c in aggregate_candles(base_candles, component_minutes)
            if (
                final_candle["open_time"]
                <= c["open_time"]
                <
                final_end
            )
        ]

        if len(parts) != 2:
            continue

        result.append(timeframe)

    return result


def compute_startup_timeframes(base_candles, current_ms):

    due = startup_timeframes(base_candles, current_ms)

    if due:
        return due

    return due_timeframes(current_ms)


# ============================================================
# TESTS
# ============================================================

def make_candle(open_, high, low, close, open_time=0):

    return {
        "open_time": open_time,
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "close_time": open_time + 1,
    }


def self_test():

    print("Running Scanner 1-4 tests...")

    # Juni tests fakt meणbatti-chya niyamachi aahet - mhanun indicator adti
    # band thevun chalवतो, aani nantar momentum chya swatantra tests karतो.
    global MOMENTUM_ENABLED, MOMENTUM_MULTIPLIER

    saved_enabled = MOMENTUM_ENABLED
    MOMENTUM_ENABLED = False

    # Scanner 1
    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(106, 108, 102, 103),
        make_candle(103, 104, 100, 101),
    )["scanner"] == "Scanner 1"

    # Scanner 2
    assert scanner_result(
        make_candle(110, 111, 99, 100),
        make_candle(101, 107, 100, 106),
        make_candle(104, 110, 100, 109),
    )["scanner"] == "Scanner 2"

    # Scanner 3
    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(108, 112, 103, 104),
        make_candle(104, 105, 100, 101),
    )["scanner"] == "Scanner 3"

    # Scanner 4
    assert scanner_result(
        make_candle(110, 111, 99, 100),
        make_candle(101, 103, 97, 102),
        make_candle(104, 110, 100, 109),
    )["scanner"] == "Scanner 4"

    # ============================================================
    # NAVA NIYAM (26-09) : 1st body >= 50% , final close <= 50% / >= 50%
    # ============================================================

    # 1ल्या cha body AGAD 50% -> chalta
    assert scanner_result(
        make_candle(100, 110, 100, 105),          # body = 5/10 = 50%
        make_candle(105, 108, 102, 103),
        make_candle(103, 104, 100, 101),
    )["scanner"] == "Scanner 1"

    # 1ल्या cha body 49% -> nahi
    assert scanner_result(
        make_candle(100, 110, 100, 104.9),        # body = 4.9/10 = 49%
        make_candle(105, 108, 102, 103),
        make_candle(103, 104, 100, 101),
    ) is None

    # final close AGAD 50% -> bearish (Scanner 1) chalta
    assert scanner_result(
        make_candle(100, 110, 100, 105),
        make_candle(105, 108, 102, 103),
        make_candle(103, 104, 100, 102),          # close = 50%
    )["scanner"] == "Scanner 1"

    # final close 50.1% -> bearish nahi (hadde baher)
    assert scanner_result(
        make_candle(100, 110, 100, 105),
        make_candle(105, 108, 102, 103),
        make_candle(103, 104, 100, 102.004),      # close = 50.1%
    ) is None

    # final close AGAD 50% -> bullish (Scanner 2) chalta
    assert scanner_result(
        make_candle(105, 110, 100, 100),          # 1ली laal, body 50%
        make_candle(100, 107, 101, 106),
        make_candle(104, 110, 100, 105),          # close = 50%
    )["scanner"] == "Scanner 2"

    # final close 49.9% -> bullish nahi
    assert scanner_result(
        make_candle(105, 110, 100, 100),
        make_candle(100, 107, 101, 106),
        make_candle(104, 110, 100, 104.99),       # close = 49.9%
    ) is None

    # message madhe aakडे tech dakhvatat
    _msg_setup = {
        "direction": "Bearish Reversal",
        "scanner": "Scanner 1",
        "position": 0.25,
        "previous": None,
        "first": make_candle(100, 110, 100, 105),
        "second": make_candle(105, 108, 102, 103),
        "final": make_candle(103, 104, 100, 101),
        "confirmation_high": None,
        "confirmation_low": None,
    }

    _msg = make_alert("TESTUSDT", "4h", _msg_setup, 99.5, 1700000000000)
    assert f"Close <= {CLOSE_LOW_THRESHOLD * 100:.0f}% from Low" in _msg, _msg

    _msg_setup["direction"] = "Bullish Reversal"
    _msg = make_alert("TESTUSDT", "4h", _msg_setup, 106.0, 1700000000000)
    assert f"Close >= {CLOSE_HIGH_THRESHOLD * 100:.0f}% from Low" in _msg, _msg

    print("Nava niyam (body 50% / close 50%) PASS")



    # strict equality -> reject
    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(106, 110, 102, 103),
        make_candle(103, 104, 100, 101),
    ) is None

    assert scanner_result(
        make_candle(100, 110, 99, 109),
        make_candle(108, 112, 99, 104),
        make_candle(104, 105, 100, 101),
    ) is None

    # live bearish breakout
    setup = {
        "direction": "Bearish Reversal",
        "final": {
            "open": 109,
            "high": 110,
            "low": 100,
            "close": 105.5,
            "close_time": 999,
        },
        "confirmation_start": 0,
        "confirmation_end": 9999999999999,
        "confirmation_high": None,
        "confirmation_low": None,
        "position": 0.55,
        "first": {
            "open": 110, "high": 111, "low": 99, "close": 110.5,
        },
        "second": {
            "open": 110.5, "high": 110.8, "low": 105, "close": 105.5,
        },
    }

    key = "TESTUSDT|1h|1|Scanner 1"

    with LOCK:

        ACTIVE_SETUPS.clear()
        SENT_ALERTS.discard(key)

        ACTIVE_SETUPS[key] = {
            **setup,
            "symbol": "TESTUSDT",
            "timeframe": "1h",
            "scanner": "Scanner 1",
            "key": key,
            "send_attempts": 0,
            "last_attempt_ms": 0,
        }

    # touch -> trigger nahi
    process_price("TESTUSDT", 100.0, 1000)
    assert key in ACTIVE_SETUPS

    # strict break -> trigger
    process_price("TESTUSDT", 99.99, 1000)
    assert key not in ACTIVE_SETUPS
    assert key in SENT_ALERTS

    # ============================================================
    # INDICATOR NIYAM — momentum khambachi unchi
    # ============================================================

    MOMENTUM_ENABLED = True

    # ---- Yuzar chya skrin-shot che KHARE aakडे (measured) ----
    m0 = make_candle(154.4033, 154.4200, 154.2800, 154.2967)      # 1ल्याच्या aadhi-chi
    m1 = make_candle(154.2967, 154.3000, 153.9800, 154.0317)      # 1ली (laal)
    m2 = make_candle(154.0317, 154.2600, 154.0300, 154.2583)      # 2री (hiravi)

    _s1, _s2 = momentum_sticks(m0, m1, m2)

    assert abs(candle_momentum(m1) - (-0.2650)) < 0.001
    assert abs(candle_momentum(m2) - (+0.2266)) < 0.001
    assert abs(_s1 - (-0.1584)) < 0.002, _s1
    assert abs(_s2 - (+0.4916)) < 0.002, _s2

    _r = momentum_ratio(m0, m1, m2)
    assert _r is not None and abs(_r - 3.10) < 0.05, _r
    # aakडा badal-la tari hi ओळ chukat nahi (fakt khara pat tapasalto)
    assert momentum_ok(m0, m1, m2) is (MOMENTUM_MULTIPLIER <= 3.10)

    # ---- Yuzar chе shabdaant-le udahaरण : 110 -> 102 , 102 -> 126 ----
    p0 = make_candle(110, 110, 110, 110)          # aadhi-chi sapаट
    p1 = make_candle(110, 110, 102, 102)          # 8 khali
    p2 = make_candle(102, 126, 102, 126)          # 24 var

    assert momentum_ratio(p0, p1, p2) is not None
    assert abs(momentum_ratio(p0, p1, p2) - 4.0) < 1e-9
    assert momentum_ok(p0, p1, p2) is (MOMENTUM_MULTIPLIER <= 4.0)

    # ---- hadde : kona-tari aakडा thevला tari hi test chalta rahili pahije ----
    # khambа 1 = -8 (m1 - m0 = -8 - 0) ; khambа 2 = m2 - m1 = m2 + 8
    #   agadi pat : khambа 2 = 8 x MOMENTUM_MULTIPLIER   ->   band = 8 x M + 94
    _band = 8.0 * MOMENTUM_MULTIPLIER + 94.0
    assert momentum_ok(p0, p1, make_candle(102, _band, 102, _band)) is True          # agadi M x
    assert momentum_ok(p0, p1, make_candle(102, _band + 8, 102, _band + 8)) is True  # M + 1 x
    assert momentum_ok(p0, p1, make_candle(102, _band - 1, 102, _band - 1)) is False  # M - 0.125 x
    assert momentum_ok(p0, p1, make_candle(102, _band - 8, 102, _band - 8)) is False  # M - 1 x

    # ---- fakt M x nahi - M peksha MOTHE sagle pat chaltat (3x, 4x, 5x ... 100x) ----
    for _mult in (1.0, 1.02, 1.15, 1.5, 2.0, 3.0, 5.0, 10.0, 33.0):
        _b2 = 8.0 * (MOMENTUM_MULTIPLIER * _mult) + 94.0
        assert momentum_ok(p0, p1, make_candle(102, _b2, 102, _b2)) is True, _mult

    _b3 = 8.0 * (MOMENTUM_MULTIPLIER * 0.99) + 94.0
    assert momentum_ok(p0, p1, make_candle(102, _b3, 102, _b3)) is False

    # ekach disheche khambа -> nahi
    assert momentum_ok(
        make_candle(100, 100, 100, 100),
        make_candle(102, 110, 102, 110),
        make_candle(110, 126, 110, 126)
    ) is False

    print(f"INDICATOR: momentum khambachi unchi PASS"
          f" ({MOMENTUM_MULTIPLIER:.1f}x peksha mothe sagle pat chaltat)")

    # ---- gate scanner 1-4 var laagl‍ा aahe ka? ----
    saved_mult = MOMENTUM_MULTIPLIER
    MOMENTUM_MULTIPLIER = 1.0

    F1 = make_candle(100, 110, 99, 109)
    F2 = make_candle(109, 110, 99, 100)
    P1 = make_candle(95, 100, 95, 96)         # aadhi-chi (F1 sathi)
    P2 = make_candle(114, 115, 108, 109)      # aadhi-chi (F2 sathi)
    S1 = make_candle(109.9, 109.95, 100.1, 100.2)
    S2 = make_candle(100.1, 109.6, 100.05, 109.5)

    assert scanner_result(F1, S1, make_candle(100, 110, 99, 100.2), P1)["scanner"] == "Scanner 1"
    assert scanner_result(F2, S2, make_candle(109, 110, 99, 109.5), P2)["scanner"] == "Scanner 2"
    assert scanner_result(F1, make_candle(109.9, 112, 100, 100.4),
                          make_candle(100, 112, 99, 100.4), P1)["scanner"] == "Scanner 3"
    assert scanner_result(F2, make_candle(100.2, 109.8, 97, 109.6),
                          make_candle(109, 110, 97, 109.6), P2)["scanner"] == "Scanner 4"

    MOMENTUM_MULTIPLIER = saved_mult
    print("INDICATOR: scanner 1-4 var gate PASS")

    # ---- niyamane junे kamjor setup RADD hotat ka? (kona-tari aakड्यावर) ----
    _wk_f = make_candle(100, 110, 99, 109)
    _wk_s = make_candle(106, 108, 102, 103)
    _wk_ratio = momentum_ratio(P1, _wk_f, _wk_s)
    _wk_saved = MOMENTUM_MULTIPLIER
    MOMENTUM_MULTIPLIER = _wk_ratio * 2.0        # kamjor pat asleला setup

    assert scanner_result(_wk_f, _wk_s, make_candle(103, 104, 100, 101), P1) is None

    MOMENTUM_MULTIPLIER = _wk_saved
    print(f"INDICATOR: indicator niyamane junे kamjor setup RADD hotat PASS"
          f" ({_wk_ratio:.2f}x < {MOMENTUM_MULTIPLIER:.2f}x)")

    MOMENTUM_ENABLED = saved_enabled      # thevलेल्या sthitiवar parat

    print("Scanner 1 PASS")
    print("Scanner 2 PASS")
    print("Scanner 3 PASS")
    print("Scanner 4 PASS")
    print("Strict equality PASS")
    print("Strict breakout + dedupe PASS")
    print("ALL TESTS PASSED")


# ============================================================
# ONE SHOT
# ============================================================

def run_once(symbol=None, timeframe=None):

    global ACTIVE_SYMBOLS

    refresh_time_offset()

    if symbol:

        ACTIVE_SYMBOLS = {symbol.upper()}

    else:

        ACTIVE_SYMBOLS = set(fetch_active_symbols())

    print("Active symbols:", len(ACTIVE_SYMBOLS))

    timeframes = [timeframe] if timeframe else list(TIMEFRAMES.keys())

    scan_all(timeframes)


# ============================================================
# MAIN LOOP
# ============================================================

def banner():

    print()
    print("==========================================")
    print("BINANCE FUTURES SCANNER v2")
    print("==========================================")
    print("Pairs: ALL active USDT Futures")
    print("Final: 1H / 2H / 4H / 8H")
    print("Components: 30m / 1H / 2H / 4H")
    print("Scanners: 1 / 2 / 3 / 4")
    print(
        f"Niyam: 1st body >= {BODY_THRESHOLD * 100:.0f}%  |  "
        f"final close <= {CLOSE_LOW_THRESHOLD * 100:.0f}% (bearish) / "
        f">= {CLOSE_HIGH_THRESHOLD * 100:.0f}% (bullish)"
    )
    print("Confirmation: RUNNING CANDLE (strict break)")
    print("IST anchor: 05:30")
    print(f"Price feed: REST POLL every {POLL_INTERVAL:.0f}s (no websocket)")
    print(f"Wick sweep: every {SWEEP_INTERVAL:.0f}s (1m candles)")
    print(f"Heartbeat: every {HEARTBEAT_SECONDS:.0f}s")
    print(f"Telegram: retry x{TELEGRAM_RETRIES}")
    print(
        f"Cleanup: alerts auto-prune {ALERT_RETENTION_DAYS}d"
        f" (dar {PRUNE_INTERVAL_SECONDS // 3600}h)"
    )
    print(
        f"Watchdog: feed {FEED_STALE_EXIT_SECONDS}s thambla tar",
        "process restart"
    )
    print("==========================================")


def main_loop():

    global ACTIVE_SYMBOLS
    global LAST_SCAN_KEYS

    banner()

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:

        print("WARNING: Telegram token/chat_id .env madhe nahi!")

    try:

        ACTIVE_SYMBOLS = set(fetch_active_symbols())

        print("Active symbols loaded:", len(ACTIVE_SYMBOLS))

    except Exception as e:

        print("Initial symbol load error:", e)

        return

    refresh_time_offset()

    # stale .tmp kadhून टाका (adhiच्या crash chya nishाणी)
    cleanup_temp_files()

    # jun्या alert keys ekdाch kadhून टाका (startup la force)
    prune_sent_alerts(now_ms(), force=True)

    # price feed + sweep + heartbeat
    for target in (price_loop, sweep_loop, heartbeat_loop):

        threading.Thread(target=target, daemon=True).start()

    if MOMENTUM_ENABLED:
        print(
            f"INDICATOR NIYAM | momentum (len {MOMENTUM_LENGTH}) khambachi unchi"
            f" | 2ri >= {MOMENTUM_MULTIPLIER:.2f}x 1li"
            f" | alert fakt doghe niyam jhale tar"
        )
    else:
        print("INDICATOR NIYAM | momentum BAND (fakt candle niyam)")

    print("PRICE FEED THREADS STARTED")

    # ---- immediate startup scan ------------------------------
    try:

        startup_ms = now_ms()

        startup_candles = fetch_closed_15m_candles("BTCUSDT")

        startup_due = compute_startup_timeframes(
            startup_candles,
            startup_ms,
        )

        startup_key = datetime.fromtimestamp(
            startup_ms / 1000,
            timezone.utc,
        ).strftime("%Y-%m-%d-%H")

        LAST_SCAN_KEYS.add(startup_key)

        if startup_due:

            print(
                "Startup scan timeframes:",
                ", ".join(startup_due),
            )

            scan_all(startup_due)

        else:

            print("Startup scan skipped: no confirmation candle running")

    except Exception as e:

        print("Startup scan error:", e)

    # ---- normal loop -----------------------------------------
    while True:

        try:

            current = now_ms()

            dt = datetime.fromtimestamp(current / 1000, timezone.utc)

            current_key = dt.strftime("%Y-%m-%d-%H")

            due = due_timeframes(current)

            if due and current_key not in LAST_SCAN_KEYS:

                LAST_SCAN_KEYS.add(current_key)

                if len(LAST_SCAN_KEYS) > 48:

                    LAST_SCAN_KEYS = set(
                        sorted(LAST_SCAN_KEYS)[-24:]
                    )

                scan_all(due)

            if dt.minute == 5:

                try:

                    new_symbols = set(fetch_active_symbols())

                    if new_symbols != ACTIVE_SYMBOLS:

                        ACTIVE_SYMBOLS = new_symbols

                        print(
                            "Symbol list refreshed:",
                            len(ACTIVE_SYMBOLS),
                            flush=True,
                        )

                except Exception as e:

                    print("Symbol refresh error:", e, flush=True)

            cleanup_expired_setups(current)

            # daर 6 tasांनी jun्या keys automatic kadhून टाका
            prune_sent_alerts(current)

            time.sleep(2)

        except KeyboardInterrupt:

            print()
            print("Scanner stopped.")
            break

        except Exception as e:

            print()
            print("MAIN LOOP ERROR:", e)
            time.sleep(10)


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument("--test", action="store_true")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--symbol", default=None)
    parser.add_argument(
        "--timeframe",
        choices=["1h", "2h", "4h", "8h"],
        default=None,
    )

    args = parser.parse_args()

    if args.test:

        self_test()

    elif args.once:

        run_once(symbol=args.symbol, timeframe=args.timeframe)

    else:

        main_loop()
