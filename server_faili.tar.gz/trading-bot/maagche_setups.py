#!/usr/bin/env python3
# ============================================================
#  MAAGCHE SETUPS — maagchya N divsांcha ahaval  (fakt vaachan)
#
#  kaay karto :
#    1) maagchya N divsांचi 15m meणbattya Binance kडून ghеto
#    2) tya-ch TUMCHYA sadyachya niyamांvar tapasalto
#         - june meणbatti niyam (Scanner 1/2/3/4)
#         - indicator niyam (khambа >= MOMENTUM_MULTIPLIER)
#    3) kitle setups sapadले, kona kona pair madhe, kadhi - te sangto
#    4) tya-paiki konaला alert zhala asता (breakout) te pण sangto
#    5) alerts_sent.json madhele KHARE pathवलेले alerts pण dakhavto
#    6) sagla tapshil CSV madhe lihto
#
#  ⚠️ ha script KAHICH badalat nahi :
#       alerts_sent.json la haat lavat nahi, Telegram la kाहi pathवत nahi,
#       scanner band karat nahi.  fakt aakडे mojto.
#
#  niyam ithे parat liht nahit — teh खालच्या live_scanner.py madhूनच vaparले
#  jaतात.  tyamuळे ahaval aani sadyacha scanner सारखाच niyam vaparto.
#
#  chaalava :
#      ./venv/bin/python maagche_setups.py --selftest      # adhi ha (network nahi)
#      ./venv/bin/python maagche_setups.py --days 1 --symbols 100   # thoda vegaLa
#      ./venv/bin/python maagche_setups.py --days 3        # purna ahaval
# ============================================================

import argparse
import csv
import importlib.util
import json
import os
import sys
import time

SCANNER_FILES = ["live_scanner.py", "live_scanner_v7_stick.py"]

PASS = 0
FAIL = 0


# ============================================================
# SCANNER MODULE
# ============================================================

def load_scanner(path=None):

    """sadyachi live_scanner.py import karto (tyachT niyam vaparण्यासाठी)."""

    if path is None:
        for f in SCANNER_FILES:
            if os.path.isfile(f):
                path = f
                break

    if path is None:
        print("❌ live_scanner.py sapadli nahi — tya folder madhून chaalava.")
        sys.exit(2)

    spec = importlib.util.spec_from_file_location("live_scanner_mod", path)

    mod = importlib.util.module_from_spec(spec)

    spec.loader.exec_module(mod)

    return mod, path


# ============================================================
# MEणBATTYA (Binance)
# ============================================================

_last_call = [0.0]


def _throttle(gap):

    now = time.time()

    wait = gap - (now - _last_call[0])

    if wait > 0:
        time.sleep(wait)

    _last_call[0] = time.time()


def fetch_15m(ls, symbol, start_ms, limit):

    """15m meणbattya — chaalu meणbatti sodun (scanner sारखंच)."""

    limit = max(50, min(1000, int(limit)))

    gap = 0.30 if limit > 500 else 0.12

    for attempt in range(4):

        _throttle(gap)

        try:

            response = ls.get_session().get(
                f"{ls.BINANCE_BASE}/fapi/v1/klines",
                params={
                    "symbol": symbol,
                    "interval": "15m",
                    "startTime": int(start_ms),
                    "limit": limit,
                },
                timeout=20,
            )

            if response.status_code in (429, 418):

                print(f"   (rate limit — {20 * (attempt + 1)}s thambto…)",
                      flush=True)

                time.sleep(20 * (attempt + 1))

                continue

            response.raise_for_status()

            current = ls.now_ms()

            out = []

            for k in response.json():

                close_time = int(k[6])

                if close_time >= current:      # chaalu meणbatti sodun
                    continue

                out.append({
                    "open_time": int(k[0]),
                    "open": float(k[1]),
                    "high": float(k[2]),
                    "low": float(k[3]),
                    "close": float(k[4]),
                    "close_time": close_time,
                })

            return out

        except Exception as e:

            if attempt == 3:
                raise

            time.sleep(2 * (attempt + 1))

    return []


# ============================================================
# EK TIMEFRAME TAPASणी
# ============================================================

def scan_timeframe(ls, symbol, timeframe, candles, win_start, win_end):

    """eka symbol + eka timeframe sathi sagळे jhालेले setups.

    win_start / win_end = ahaval cha kaalावधी (ms).  Yachya baher chya
    meणbattya baghat nahit.
    """

    component_minutes = ls.TIMEFRAMES[timeframe]
    final_minutes = int(timeframe[:-1]) * 60

    comp_ms = component_minutes * 60 * 1000
    final_ms = final_minutes * 60 * 1000

    comps = ls.aggregate_candles(candles, component_minutes)
    finals = ls.aggregate_candles(candles, final_minutes)

    comp_index = {c["open_time"]: c for c in comps}

    rows = []

    for fc in finals:

        f_start = fc["open_time"]
        f_end = f_start + final_ms

        if f_end > win_end or f_end < win_start:
            continue                      # ahaval chya kaalावधीt nahi

        parts = sorted(
            [c for c in comps if f_start <= c["open_time"] < f_end],
            key=lambda x: x["open_time"],
        )

        if len(parts) != 2:
            continue

        first, second = parts

        previous = comp_index.get(first["open_time"] - comp_ms)

        result = ls.scanner_result(first, second, fc, previous)

        if result is None:
            continue

        ratio = ls.momentum_ratio(previous, first, second)

        # module chyaT niyam : "Bearish Reversal" asel tar final cha LOW toडायcha
        bullish = not result["direction"].lower().startswith("bearish")

        level = fc["high"] if bullish else fc["low"]

        # ---- breakout (confirmation khaंड) -------------------
        conf_start = f_end
        conf_end = f_end + comp_ms

        hit = None

        for c in candles:

            if c["open_time"] < conf_start or c["open_time"] >= conf_end:
                continue

            if bullish and c["high"] > level:
                hit = c["open_time"]
                break

            if (not bullish) and c["low"] < level:
                hit = c["open_time"]
                break

        running = conf_end > ls.now_ms()

        rows.append({
            "symbol": symbol,
            "timeframe": timeframe,
            "scanner": result["scanner"],
            "direction": result["direction"],
            "setup_ms": f_start,
            "ratio": ratio,
            "level": level,
            "bullish": bullish,
            "breakout": (True if hit else (None if running else False)),
            "breakout_ms": hit,
            "conf_start": conf_start,
        })

    return rows


def scan_symbol(ls, symbol, candles, win_start, win_end):

    rows = []

    for timeframe in ls.TIMEFRAMES:

        try:
            rows.extend(
                scan_timeframe(ls, symbol, timeframe, candles, win_start, win_end)
            )

        except Exception:
            continue

    return rows


# ============================================================
# alerts_sent.json — KHARE pathवलेले alerts
# ============================================================

def read_sent_alerts(ls, days):

    """fakt vaachan.  key : SYMBOL|tf|<ms>|Scanner N"""

    path = ls.ALERT_FILE

    if not os.path.isfile(path):
        return None, 0, path

    try:

        with open(path, "r") as f:
            keys = json.load(f)

    except Exception:
        return None, 0, path

    if isinstance(keys, dict):
        keys = list(keys.keys())

    cutoff = ls.now_ms() - days * 24 * 60 * 60 * 1000

    rows = []

    for key in keys:

        ms = ls.parse_alert_key_ms(key)

        if ms is None or ms < cutoff:
            continue

        parts = key.split("|")

        rows.append({
            "symbol": parts[0],
            "timeframe": parts[1],
            "scanner": parts[3] if len(parts) > 3 else "?",
            "ms": ms,
        })

    rows.sort(key=lambda r: r["ms"])

    return rows, len(keys), path


# ============================================================
# AHAVAL
# ============================================================

def report(ls, args):

    days = args.days

    now = ls.now_ms()

    win_end = now
    win_start = now - days * 24 * 60 * 60 * 1000

    fetch_start = win_start - 8 * 60 * 60 * 1000      # 8h cushion
    need = int((now - fetch_start) / (15 * 60 * 1000)) + 20

    print("=" * 72)
    print(" MAAGCHE SETUPS — maagchya divsांcha ahaval")
    print("=" * 72)
    print(f" kaalावधी   : {ls.format_ist(win_start)}")
    print(f"              te {ls.format_ist(win_end)}")
    print(f" indicator : "
          + (f"CHALU  (khambа 2 >= {ls.MOMENTUM_MULTIPLIER:.2f} x khambа 1)"
             if ls.MOMENTUM_ENABLED else "BAND"))
    print()

    # ---- symbols -------------------------------------------
    symbols = sorted(ls.fetch_active_symbols())

    if args.symbols:
        symbols = symbols[:args.symbols]

    print(f" symbols   : {len(symbols)}")
    print(f" kaaLi     : {need} 15m meणbattya pratyek symbol sathi")
    print()
    print(" meणbattya yet aahеt … (thoda vela lagto, 2-4 minut)")
    print()

    rows = []
    rows_no_gate = 0
    errors = 0

    for i, symbol in enumerate(symbols, 1):

        try:

            candles = fetch_15m(ls, symbol, fetch_start, need)

            if len(candles) < 40:
                continue

            rows.extend(scan_symbol(ls, symbol, candles, win_start, win_end))

            # ---- indicator BAND thevun punha (kitI raddh zhale) ----
            saved = ls.MOMENTUM_ENABLED
            ls.MOMENTUM_ENABLED = False
            try:
                rows_no_gate += len(
                    scan_symbol(ls, symbol, candles, win_start, win_end)
                )
            finally:
                ls.MOMENTUM_ENABLED = saved

        except Exception:
            errors += 1

        if i % 50 == 0 or i == len(symbols):
            print(f"   … {i}/{len(symbols)}   (setups aathवat: {len(rows)})",
                  flush=True)

    rows.sort(key=lambda r: r["setup_ms"])

    print()
    print("=" * 72)
    print(" [1] KHARE pathवलेले ALERTS  (alerts_sent.json)")
    print("=" * 72)

    sent, total_keys, path = read_sent_alerts(ls, days)

    if sent is None:
        print(f"  ⚠️ {path} vaachalI nahi (file nahi kiva format vegla).")
    else:
        print(f"  file : {path}   ({total_keys} ekuण नोंदी, sगळ्या kaalावधीt)")
        print(f"  ya {days} divsांt pathवलेले : {len(sent)}")
        print()
        if sent:
            per_day = {}
            for r in sent:
                day = ls.format_ist(r["ms"])[:10]
                per_day.setdefault(day, []).append(r)
            print("     tareekh    | alerts | pairs")
            print("     -----------|--------|------------------------------")
            for day in sorted(per_day, reverse=True):
                lst = per_day[day]
                pairs = sorted({x["symbol"] for x in lst})
                print(f"     {day} |  {len(lst):>4}  | {', '.join(pairs[:6])}"
                      + (" …" if len(pairs) > 6 else ""))
        else:
            print("     (ya kaalावधीt ekहI alert nahi)")

    print()
    print("=" * 72)
    print(" [2] ऐतिहासिक तपासणी — sadyachya niyamांvar kiti setups hote")
    print("=" * 72)

    fired = [r for r in rows if r["breakout"] is True]
    notfired = [r for r in rows if r["breakout"] is False]
    running = [r for r in rows if r["breakout"] is None]

    print(f"  jhालेले setups (donhi niyam jhाले)   : {len(rows)}")
    print(f"  tya-paiki breakout zhala asता (alert) : {len(fired)}")
    print(f"  breakout nahi zhala (alert nahi)      : {len(notfired)}")
    print(f"  ajun chaalu (ha khaंड sampla nahi)    : {len(running)}")
    print()
    print(f"  ⚖️  indicator BAND asता setups : {rows_no_gate}"
          f"   -> indicator ne {rows_no_gate - len(rows)} setups RADD kele")
    print()

    if rows:

        print("     tareekh    | setups | alert zhala asता")
        print("     -----------|--------|----------------")

        per_day = {}

        for r in rows:
            day = ls.format_ist(r["setup_ms"])[:10]
            per_day.setdefault(day, []).append(r)

        for day in sorted(per_day, reverse=True):

            lst = per_day[day]

            f = sum(1 for x in lst if x["breakout"] is True)

            print(f"     {day} |  {len(lst):>4}  |  {f:>4}")

        print()
        print("=" * 72)
        print(" [3] KONTYA PAIRS MADHE  (setups … chart)")
        print("=" * 72)

        per_pair = {}

        for r in rows:
            key = (r["symbol"], r["timeframe"], r["scanner"])
            per_pair.setdefault(key, []).append(r)

        ranked = sorted(per_pair.items(), key=lambda kv: -len(kv[1]))

        print("     #   symbol           tf  scanner    setups  alert")
        print("     ----|----------------|----|----------|-------|------")

        for i, (key, lst) in enumerate(ranked[:25], 1):

            sym, tf, sc = key
            f = sum(1 for x in lst if x["breakout"] is True)

            print(f"     {i:>3} | {sym:<15}| {tf:<3}| {sc:<9}| {len(lst):>5} | {f:>5}")

        if len(ranked) > 25:
            print(f"     … ajun {len(ranked) - 25} jodya — sगळी CSV madhe")

        print()
        print("=" * 72)
        print(" [4] SAGALI YADI  (ha khaंड = breakout cha वेळ अंदाजे)")
        print("=" * 72)

        print("     #  setups chi vela       | symbol        | tf  | scanner   | पट    | alert")

        shown = rows if args.all else rows[:40]

        for i, r in enumerate(shown, 1):

            if r["breakout"] is True:
                tag = "✅ " + ls.format_ist(r["breakout_ms"])[11:16]
            elif r["breakout"] is None:
                tag = "⏳ chaalu"
            else:
                tag = "— nahi"

            pat = "  ?  " if r["ratio"] is None else f"{r['ratio']:5.2f}x"

            print(f"     {i:>3} {ls.format_ist(r['setup_ms'])[:16]} | "
                  f"{r['symbol']:<13} | {r['timeframe']:<3} | {r['scanner']:<9} |"
                  f" {pat} | {tag}")

        if not args.all and len(rows) > 40:
            print(f"     … ajun {len(rows) - 40} — CSV madhe sगळे (--all dya tar ithे pण)")

    # ---- CSV ----------------------------------------------
    if args.csv:

        with open(args.csv, "w", newline="", encoding="utf-8-sig") as f:

            w = csv.writer(f)

            w.writerow([
                "setup_ist", "symbol", "timeframe", "scanner", "direction",
                "pat", "level", "alert_zhala", "alert_ist",
            ])

            for r in rows:

                w.writerow([
                    ls.format_ist(r["setup_ms"]),
                    r["symbol"],
                    r["timeframe"],
                    r["scanner"],
                    r["direction"],
                    "" if r["ratio"] is None else f"{r['ratio']:.2f}",
                    f"{r['level']:.8f}",
                    {True: "ho", False: "nahi", None: "chaalu"}[r["breakout"]],
                    ls.format_ist(r["breakout_ms"]) if r["breakout_ms"] else "",
                ])

        print()
        print(f" 📄 CSV tayar : {args.csv}   ({len(rows)} oळi)")
        print("    (Excel madhe ughडून baghu shakta)")

    if errors:
        print()
        print(f" ⚠️ {errors} symbols var error aaला (te sodle)")

    print()
    print("=" * 72)
    print(" MAHATVACHE :")
    print("  • 'setup' = donhi niyam jhाले.  'alert' = + breakout zhala.")
    print("  • breakout cha वेळ अंदाजे (15m meणbatti chya high/low varun).")
    print("  • खरा alert Breakout cha pratyakSh kinnat varun tharto —")
    print("    tyamuळe ithे जरा जास्त दिसू शakto.")
    print("  • alerts_sent.json la ha script kाहi karat nahi (fakt vaachan).")
    print("=" * 72)


# ============================================================
# SWATAHCHI CHAचणी (network nahit)
# ============================================================

def selftest(ls):

    global PASS, FAIL

    def check(name, cond, extra=""):
        global PASS, FAIL
        if cond:
            PASS += 1
            print(f"  ✅ {name}" + (f"   {extra}" if extra else ""))
        else:
            FAIL += 1
            print(f"  ❌ {name}" + (f"   {extra}" if extra else ""))

    print("=" * 72)
    print(" SWATAHCHI CHAचणी — network vaparat nahi")
    print("=" * 72)

    B = ls.BASE_INTERVAL_MS

    t0 = 1_700_000_000_000 // (60 * 60 * 1000) * (60 * 60 * 1000)

    def two(o, h, l, c, mid, start):
        """30m component = don 15m meणbattya (aggregate tashiच yete)."""
        return [
            {"open_time": start, "open": o, "high": h, "low": l, "close": mid,
             "close_time": start + B - 1},
            {"open_time": start + B, "open": mid, "high": h, "low": l, "close": c,
             "close_time": start + 2 * B - 1},
        ]

    # 1h cha khaंड : 1ली aani 2री donhi EKA 1h madhe, aadhi-chi tya-ahI
    # 1ल्याच्या aadhi-chi 30m
    prev = two(154.4033, 154.4150, 154.2867, 154.2967, 154.35, t0 + 30 * 60 * 1000)
    # 1ली 30m  (laal)
    first = two(154.2967, 154.2983, 153.9850, 154.0317, 154.10, t0 + 60 * 60 * 1000)
    # 2री 30m  (hiravi, 1ल्याच्या aat)
    second = two(154.0317, 154.2617, 154.0317, 154.2583, 154.15, t0 + 90 * 60 * 1000)

    # confirmation khaंड (30m) — ha high level (154.2983) chya var
    conf_hit = two(154.2583, 154.3500, 154.2500, 154.3400, 154.30, t0 + 120 * 60 * 1000)
    # pan ha level chya khali
    conf_miss = two(154.2583, 154.2900, 154.2500, 154.2800, 154.27, t0 + 120 * 60 * 1000)

    win_start = t0
    win_end = t0 + 200 * 60 * 1000

    rows = scan_timeframe(
        ls, "TESTUSDT", "1h", prev + first + second + conf_hit, win_start, win_end
    )

    check("setup sapadला (1h)", len(rows) == 1, f"{len(rows)}")

    if rows:

        r = rows[0]

        check("scanner : Scanner 2 (bullish reversal)", r["scanner"] == "Scanner 2",
              r["scanner"])

        check("pat = 3.10x", r["ratio"] is not None and abs(r["ratio"] - 3.10) < 0.05,
              f"{r['ratio']:.2f}x" if r["ratio"] else "-")

        check("level = final cha high (154.2983)", abs(r["level"] - 154.2983) < 1e-6,
              f"{r['level']:.4f}")

        check("breakout sapadला (alert zhala asता)", r["breakout"] is True,
              ls.format_ist(r["breakout_ms"]) if r["breakout_ms"] else "-")

    rows2 = scan_timeframe(
        ls, "TESTUSDT", "1h", prev + first + second + conf_miss, win_start, win_end
    )

    check("level toडला nahi tar alert nahi",
          len(rows2) == 1 and rows2[0]["breakout"] is False)

    # ---- indicator niyamane RADD hoto ka? ----
    saved = ls.MOMENTUM_MULTIPLIER

    ls.MOMENTUM_MULTIPLIER = 4.0        # 3.10x peksha मोठा aakडा

    rows3 = scan_timeframe(
        ls, "TESTUSDT", "1h", prev + first + second + conf_hit, win_start, win_end
    )

    ls.MOMENTUM_MULTIPLIER = saved

    check("indicator niyamane RADD (4x thevला tar 3.10x setup nahi)", len(rows3) == 0,
          f"{len(rows3)}")

    # ---- CSV ----
    tmp = "maagche_setups_selftest.csv"

    try:

        with open(tmp, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["a"])
            w.writerow(["b"])

        ok = os.path.getsize(tmp) > 0

    finally:

        if os.path.isfile(tmp):
            os.remove(tmp)

    check("CSV lihta yeto", ok)

    print()
    print("=" * 72)
    print(f" निकाल : {PASS} pass, {FAIL} fail")
    print("=" * 72)

    return 0 if FAIL == 0 else 1


# ============================================================
# MAIN
# ============================================================

def main():

    ap = argparse.ArgumentParser(
        description="maagchya N divsांcha setups cha ahaval (fakt vaachan)"
    )

    ap.add_argument("--days", type=float, default=3.0,
                    help="kiti divas maage (default 3)")
    ap.add_argument("--symbols", type=int, default=0,
                    help="fakt pahlे itke symbols (vegaLya chachणीसाठी)")
    ap.add_argument("--csv", default="",
                    help="CSV file cha naav (default: maagche_setups_<N>din.csv)")
    ap.add_argument("--all", action="store_true",
                    help="sagली yadi s्क्रीनवर dakhva")
    ap.add_argument("--selftest", action="store_true",
                    help="network shivay swatahchi chaचणी")

    args = ap.parse_args()

    ls, path = load_scanner()

    print(f" scanner file : {path}")
    print(f" rules        : khालच्या file madhून (ithе parat liht nahit)")
    print()

    if args.selftest:
        sys.exit(selftest(ls))

    if not args.csv:
        args.csv = f"maagche_setups_{args.days:g}din.csv"

    try:
        report(ls, args)
    except KeyboardInterrupt:
        print("\n (tumhi थांबवले)")


if __name__ == "__main__":
    main()

