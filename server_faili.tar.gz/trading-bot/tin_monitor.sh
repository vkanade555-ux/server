#!/bin/bash
# ============================================================
#  TIN CANDLE MONITOR — बाहेरून तपासणी (scanner code ला हात नाही)
#
#    tin_monitor.sh check   -> दर 5 मिनिटाला: 4h चा scan झाला का? जागा आहे का?
#    tin_monitor.sh daily   -> रोज 09:00 IST ला Telegram वर अहवाल
#    tin_monitor.sh test    -> एक test message पाठवतो (एकदा हेच चालवा)
#
#  नियम: दिवसातून 6 scan — 00:30 · 04:30 · 08:30 · 12:30 · 16:30 · 20:30 IST
#        (प्रत्येक 4h block ची 3री मेणबत्ती बंद होते तेव्हा)
#
#  हा script स्वतंत्र आहे — tin_candle_scanner.py मध्ये काहीच बदलत नाही.
# ============================================================

DIR="${TIN_DIR:-/home/ubuntu/trading-bot}"
SVC="${TIN_SVC:-tin-candle-scanner.service}"
ENV_FILE="$DIR/.env"
STATE_DIR="${TIN_MON_STATE_DIR:-/var/lib/tin-monitor}"
STATE_FILE="$STATE_DIR/state"
LOG_FILE="$STATE_DIR/monitor.log"
STRIKE_FILE="$STATE_DIR/strikes"

# IST मध्ये scan च्या वेळा (दिवसाचे सेकंद) : 00:30 04:30 08:30 12:30 16:30 20:30
SCAN_TIMES="1800 16200 30600 45000 59400 73800"

DUE_SLACK_SEC=480      # scan च्या वेळेपासून 8 मिनिटं — मग तपासतो
GRACE_SEC=240          # सेवा इतक्यात नुकतीच सुरू झाली असेल तर शांत
LOW_DISK_MB=500        # इतक्यापेक्षा कमी जागा = कळवा
REPEAT_SEC=21600       # एकच त्रुटी 6 तासांत एकदाच कळवा
NEED_STRIKES=2         # 2 वेळा (~10 मिनिटं) scan नाही मिळाला तरच restart
RESTART_WAIT="${TIN_RESTART_WAIT:-30}"

mkdir -p "$STATE_DIR" 2>/dev/null

# ---------- वेळ ----------
now_epoch(){ echo "${TIN_NOW_EPOCH:-$(date +%s)}"; }

log(){ echo "$(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M:%S IST') $*" >>"$LOG_FILE" 2>/dev/null; }

hhmm(){ printf '%02d:%02d' $(( $1 / 3600 )) $(( ($1 % 3600) / 60 )); }

# ---------- .env मधून value ----------
get_env(){
  [ -f "$ENV_FILE" ] || return 1
  grep -E "^[[:space:]]*$1=" "$ENV_FILE" 2>/dev/null | head -1 | cut -d= -f2- \
    | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
          -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//" | tr -d '\r'
}

# ---------- Telegram ----------
send_tg(){
  TOKEN=$(get_env TIN_TELEGRAM_BOT_TOKEN); [ -n "$TOKEN" ] || TOKEN=$(get_env TELEGRAM_BOT_TOKEN)
  CHAT=$(get_env TIN_TELEGRAM_CHAT_ID);   [ -n "$CHAT" ]  || CHAT=$(get_env TELEGRAM_CHAT_ID)
  if [ -z "$TOKEN" ] || [ -z "$CHAT" ]; then
    log "TRUTI: .env madhe TELEGRAM_BOT_TOKEN/CHAT_ID sapadla nahi ($ENV_FILE)"
    return 1
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -s -m 20 -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
         --data-urlencode "chat_id=$CHAT" \
         --data-urlencode "text=$1" >/dev/null 2>&1
  else
    python3 - "$TOKEN" "$CHAT" "$1" <<'PYEOF' >/dev/null 2>&1
import sys, urllib.parse, urllib.request
t, c, m = sys.argv[1], sys.argv[2], sys.argv[3]
d = urllib.parse.urlencode({"chat_id": c, "text": m}).encode()
try:
    urllib.request.urlopen(f"https://api.telegram.org/bot{t}/sendMessage", d, timeout=20)
except Exception:
    pass
PYEOF
  fi
  return 0
}

# ---------- सेवेची माहिती ----------
svc_uptime_sec(){
  TS=$(systemctl show "$SVC" -p ActiveEnterTimestamp --value 2>/dev/null)
  [ -n "$TS" ] || { echo 0; return; }
  S=$(date -d "$TS" +%s 2>/dev/null) || { echo 0; return; }
  echo $(( $(now_epoch) - S ))
}

# ---------- वेळापत्रक (IST) ----------
due_info(){   # DUE = शेवटची scan ची वेळ (sec), ELAPSED = तेव्हापासून किती सेकंद
  SOD=$(( ($(now_epoch) + 19800) % 86400 ))
  DUE=0
  for t in $SCAN_TIMES; do
    if [ "$t" -le "$SOD" ]; then DUE=$t; else break; fi
  done
  if [ "$DUE" -eq 0 ]; then
    DUE=73800
    ELAPSED=$(( SOD + 86400 - 73800 ))
  else
    ELAPSED=$(( SOD - DUE ))
  fi
}

next_scan_hm(){
  SOD=$(( ($(now_epoch) + 19800) % 86400 ))
  for t in $SCAN_TIMES; do
    if [ "$t" -gt "$SOD" ]; then hhmm "$t"; return; fi
  done
  hhmm 1800
}

# ---------- state ----------
set_state(){ echo "$1|$(date +%s)" >"$STATE_FILE" 2>/dev/null; }

notify_once(){   # $1 = key, $2 = message (एकच त्रुटी वारंवार नको)
  KEY="$1"
  LAST_KEY=""; LAST_TS=0
  [ -f "$STATE_FILE" ] && IFS='|' read -r LAST_KEY LAST_TS <"$STATE_FILE"
  NOW=$(date +%s)
  if [ "$KEY" = "$LAST_KEY" ] && [ $((NOW - ${LAST_TS:-0})) -lt "$REPEAT_SEC" ]; then
    log "purvicha majkur dila aahe ($KEY) - punha pathvat nahi"
    return 0
  fi
  send_tg "$2"
  set_state "$KEY"
}

# ---------- जागा (disk) ----------
check_disk(){
  FREE_MB=$(df -Pk "$DIR" 2>/dev/null | awk 'NR==2 {print int($4/1024)}')
  case "$FREE_MB" in ''|*[!0-9]*) FREE_MB="" ;; esac
  if [ -n "$FREE_MB" ] && [ "$FREE_MB" -lt "$LOW_DISK_MB" ]; then
    notify_once "disk" "⚠️ JAGAA KAMI AAHE — TIN CANDLE SCANNER

Fakt ${FREE_MB}MB free aahe ($DIR).
Jaga mokli kara (junya backup files kadhun taka).

Tapat kara:  df -h $DIR
Vela: $(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M:%S IST')"
    log "JAGA KAMI: ${FREE_MB}MB free"
  fi
}

# ============================================================
#  CHECK — दर 5 मिनिटाला
# ============================================================
do_check(){

  ACTIVE=$(systemctl is-active "$SVC" 2>/dev/null)

  if [ "$ACTIVE" != "active" ]; then
    notify_once "down" "❌ TIN CANDLE SCANNER BAND AAHE

Seva: $ACTIVE
Monitor swatahun suru kart nahi (jaanun band kelela asu shakto).

Tapat kara:  sudo systemctl status $SVC
Vela: $(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M:%S IST')"
    log "DOWN: seva $ACTIVE"
    return 0
  fi

  UP=$(svc_uptime_sec)

  if [ "$UP" -lt "$GRACE_SEC" ]; then
    log "OK: seva navin suru ($UP sec) - grace madhe"
    return 0
  fi

  due_info
  DUE_HM=$(hhmm "$DUE")

  # ---- 1) scan ची वेळ अजून झाली नाही (8 मिनिटं सूट) ----
  if [ "$ELAPSED" -lt "$DUE_SLACK_SEC" ]; then
    rm -f "$STRIKE_FILE" 2>/dev/null
    check_disk
    set_state "ok"
    log "OK: $DUE_HM chya scan chi vel (${ELAPSED}s) - ajun thambto"
    return 0
  fi

  # ---- 2) सेवा त्या scan नंतर सुरू झाली असेल तर सूट ----
  if [ "$UP" -lt "$ELAPSED" ]; then
    rm -f "$STRIKE_FILE" 2>/dev/null
    set_state "ok"
    log "OK: seva ${UP}s purvi suru - $DUE_HM cha scan tine baghitla nahi (grace)"
    return 0
  fi

  # ---- 3) journal मध्ये SCAN आहे का? ----
  SINCE=$(( $(now_epoch) - ELAPSED - 300 ))
  FOUND=$(journalctl -u "$SVC" --since "@$SINCE" --no-pager -o cat 2>/dev/null | grep -c 'SCAN :')

  if [ "${FOUND:-0}" -ge 1 ]; then
    rm -f "$STRIKE_FILE" 2>/dev/null
    check_disk
    set_state "ok"
    log "OK: $DUE_HM cha scan zala"
    return 0
  fi

  # ---- 4) scan नाही : 2 वेळा थांबून मग restart ----
  STRIKES=$(cat "$STRIKE_FILE" 2>/dev/null)
  [ -n "$STRIKES" ] || STRIKES=0
  STRIKES=$(( STRIKES + 1 ))
  echo "$STRIKES" >"$STRIKE_FILE" 2>/dev/null

  if [ "$STRIKES" -lt "$NEED_STRIKES" ]; then
    log "SHANKA: $DUE_HM cha scan sapadla nahi ($STRIKES/$NEED_STRIKES) - ajun thambto"
    return 0
  fi

  log "TRAS: $DUE_HM cha scan nahi ($STRIKES/$NEED_STRIKES) - restart karto..."
  systemctl restart "$SVC" >/dev/null 2>&1
  sleep "$RESTART_WAIT"
  NEW=$(systemctl is-active "$SVC" 2>/dev/null)

  if [ "$NEW" = "active" ]; then
    MSG="⚠️ TIN CANDLE SCANNER ADKALA HOTA — MONITOR NE PARAT SURU KELA

$DUE_HM IST chya scan chi vel zhali, pan scan zala nahi hota
(donhi velya tapasani kelyavar pan kाहich nahi sapadla).

✅ Restart nantar: $NEW
Vela: $(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M:%S IST')"
  else
    MSG="🚨 TIN CANDLE SCANNER PARAT SURU ZALA NAHI!

Monitor ne restart kela, pan seva aata: $NEW

Lagech tapat kara:
  sudo systemctl status $SVC
  sudo journalctl -u $SVC -n 40 --no-pager"
  fi

  send_tg "$MSG"
  set_state "restarted"
  log "RESTART kela -> $NEW"
}

# ============================================================
#  DAILY — रोज 09:00 IST
# ============================================================
do_daily(){

  ACTIVE=$(systemctl is-active "$SVC" 2>/dev/null)
  ENABLED=$(systemctl is-enabled "$SVC" 2>/dev/null)
  UP=$(svc_uptime_sec)
  UP_H=$(( UP / 3600 ))
  RESTARTS=$(systemctl show "$SVC" -p NRestarts --value 2>/dev/null)
  [ -n "$RESTARTS" ] || RESTARTS="?"

  J=$(journalctl -u "$SVC" --since "24 hours ago" --no-pager -o cat 2>/dev/null)

  SCANS=$(printf '%s' "$J" | grep -c 'SCAN :')
  SUMS=$(printf '%s' "$J" | grep 'pairs jhale' \
         | sed -nE 's/^ *([0-9]+) pairs jhale.*\| ([0-9]+) errors$/\1 \2/p')
  MATCHED=$(printf '%s\n' "$SUMS" | awk '{s+=$1} END{print s+0}')
  ERRORS=$(printf '%s\n' "$SUMS"  | awk '{s+=$2} END{print s+0}')
  DIG=$(printf '%s' "$J" | grep -c 'DIGAST DELIVERED')
  RESTARTED=$(printf '%s' "$J" | grep -c 'TRAS:')

  LAST=$(printf '%s' "$J" | grep 'SCAN :' | tail -1 | sed 's/.*SCAN : //; s/^block //; s/  *(.*//')
  [ -n "$LAST" ] || LAST="-"

  DISK=$(df -h "$DIR" 2>/dev/null | awk 'NR==2 {print $4}')
  [ -n "$DISK" ] || DISK="?"

  if [ "$ACTIVE" = "active" ] && [ "${SCANS:-0}" -gt 0 ]; then
    LIVE="✅ हो — गेल्या 24 तासांत $SCANS scan झाले"
  elif [ "$ACTIVE" = "active" ]; then
    LIVE="⚠️ सेवा चालू आहे, पण scan ची नोंद नाही — पुढच्या तपासणीत कळेल"
  else
    LIVE="❌ नाही — सेवा $ACTIVE आहे"
  fi

  EXTRA=""
  if [ "${DIG:-0}" = "0" ]; then
    EXTRA="
ℹ️ अहवाल आला नाही = अट पूर्ण झाली नाही (यंत्र ठीक आहे)"
  fi

  MSG="📊 TIN CANDLE दैनंदिन अहवाल
$(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M') IST

सेवा        : $ACTIVE (enabled: $ENABLED)
चालू        : ${UP_H} तास | restarts: $RESTARTS

गेल्या 24 तासांत (अपेक्षित 6 scan):
  🔍 scans झाले     : $SCANS
  🎯 जुळलेले pairs  : $MATCHED
  🚨 अहवाल पाठवले  : $DIG
  ⚠️  errors        : $ERRORS

💓 जिवंत       : $LIVE
🕐 शेवटचा scan : $LAST
⏰ पुढचा scan  : $(next_scan_hm) IST
💾 जागा        : $DISK free
$EXTRA"

  send_tg "$MSG"
  log "DAILY pathvला (scans=$SCANS matched=$MATCHED dig=$DIG err=$ERRORS restart=$RESTARTED)"
}

# ============================================================
case "${1:-}" in
  check) do_check ;;
  daily) do_daily ;;
  test)  send_tg "🧪 TIN CANDLE MONITOR TEST

Majkur tech yet aahe - monitor barobar jodlela aahe. ✅
Seva: $(systemctl is-active "$SVC" 2>/dev/null)
Pudhचa scan: $(next_scan_hm) IST
Vela: $(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M:%S IST')" ; log "TEST majkur pathvla" ;;
  *) echo "Use: $0  check | daily | test" ; exit 2 ;;
esac

