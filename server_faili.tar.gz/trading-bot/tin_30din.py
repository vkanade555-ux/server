
#!/usr/bin/env python3
# ============================================================
#  TIN CANDLE — MAGIL N DIVSANCHA AHWAL   (30 divas default)
#
#  HE NIYAM VAPARTO (tin_candle_scanner.py madhला check_three()) :
#
#    1ली 1h : CLOSE >= 70%   (body chi aट nahi)
#    2री 1h : CLOSE >= 70%
#    3री 1h : CLOSE >= 70%   (body chi aट nahi)
#    AANI : 3री chi RANGE >= scanner cha ratio (aata 1.00x) x (1ली cha low → 2री cha high)
#    (aakडे scanner kadun tech yetat — niyam badalला tar ha abhyas pan badalतो)
#    Alert = 3री meणbatti BAND zhालi ki (dar 4h block)
#
#  KAाहीच PATHवत NAHI · KAाहीच BADALAT NAHI · NOD (state) file la haat nahi
#  — fakt data vaachto aani ahwal + CSV tayaar karto.
#
#  CHALAVA :
#    ./venv/bin/python tin_30din.py --selftest          # chaanणी (network nahit)
#    ./venv/bin/python tin_30din.py                     # magil 30 divas
#    ./venv/bin/python tin_30din.py --days 60           # magil 60 divas
#    ./venv/bin/python tin_30din.py --funnel            # NIYAM KOTHE THAMBतो te dakhva
#    ./venv/bin/python tin_30din.py --symbol BTCUSDT    # fakt ek pair
# ============================================================

import argparse
import csv
import os
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

import tin_candle_scanner as tc

def rule_word(spec):
    """meणbattiche niyamache nाव : 'body' / 'close' / 'body+close'."""

    _, bmin, cmin = spec[0], spec[1], spec[2]

    if bmin is not None and cmin is not None:
        return "body+close"
    if bmin is not None:
        return "body"
    if cmin is not None:
        return "close"
    return "-"


def rule_text(spec):
    _, bmin, cmin = spec[0], spec[1], spec[2]

    parts = []

    if bmin is not None:
        parts.append(f"body >= {bmin * 100:.0f}%")
    if cmin is not None:
        parts.append(f"close >= {cmin * 100:.0f}%")

    return " + ".join(parts) if parts else "kाहich nahi"


def rule_value(candle, spec):
    """mоjaणी : body asel tar body, warna close (0.70 = 70%)."""

    _, bmin, cmin = spec[0], spec[1], spec[2]

    if bmin is not None:
        return tc.body_ratio(candle)
    if cmin is not None:
        return tc.close_position(candle)
    return 0.0


def rule_ok(candle, spec):
    """"ti aट" paLali ka (scanner cha tech niyam)."""

    _, bmin, cmin = spec[0], spec[1], spec[2]

    if bmin is not None and tc.body_ratio(candle) < bmin - 1e-12:
        return False
    if cmin is not None and tc.close_position(candle) < cmin - 1e-12:
        return False
    return True


SPEC1, SPEC2, SPEC3 = tc.CANDLES[0], tc.CANDLES[1], tc.CANDLES[2]
NEW_RULES = SPEC3[1] is None      # 3री cha body aट kadhली = nava niyam (24-09)

# june scanner asatil tar 3री la BODY + CLOSE doni chi aट chaltे
# (nava : fakt close chi aट).  ha 'dusरी aट' cha aakडा:
EXTRA3_MIN = SPEC3[2] if SPEC3[1] is not None else None
T1 = SPEC1[1] if SPEC1[1] is not None else SPEC1[2]
T2 = SPEC2[1] if SPEC2[1] is not None else SPEC2[2]
T3 = SPEC3[1] if SPEC3[1] is not None else SPEC3[2]
W1, W2, W3 = rule_word(SPEC1), rule_word(SPEC2), rule_word(SPEC3)

def pair_base(a, b):
    """scanner madhला pair_base vaparto; juna file asel tar 'sum' (juna paddhat)."""

    f = getattr(tc, "pair_base", None)

    if f is not None:
        return f(a, b)

    return tc.candle_range(a) + tc.candle_range(b)


BASE_LABEL = getattr(tc, "BASE_LABELS", {}).get(
    getattr(tc, "BASE_OF_2X", "sum"),
    "1ली + 2री chi range" if not hasattr(tc, "BASE_OF_2X") else str(getattr(tc, "BASE_OF_2X")))

IST = tc.IST
DAY_MS = tc.DAY_MS
HOUR_MS = 60 * 60 * 1000
FOUR_H_MS = 4 * HOUR_MS

# 4h block chi suruवात (UTC मिनिटं) = IST 05:30 · 09:30 · 13:30 · 17:30 · 21:30 · 01:30
BLOCK_MIN_UTC = [0, 240, 480, 720, 960, 1200]

CSV_COLUMNS = [
    "symbol", "alert_ist", "block_ist",
    "r1", "r2", "r3", "base_1_2", "ratio",
    "body1_pct", "close1_pct", "body2_pct", "close2_pct", "body3_pct", "close3_pct",
    "alert_price", "chg_1h_pct", "chg_4h_pct", "chg_24h_pct", "max_up_24h_pct",
]

PASS = 0
FAIL = 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  ✅ {name}" + (f"   {extra}" if extra else ""))
    else:
        FAIL += 1
        print(f"  ❌ {name}" + (f"   {extra}" if extra else ""))


def ist_str(ms):
    return tc.format_ist(ms)


def hm_ist(ms):
    return tc.hhmm_ist(ms)


# ============================================================
# DATA
# ============================================================

def fetch_rows(symbol, days):
    limit = min(1500, days * 24 + 48)
    return tc.fetch_closed_1h(symbol, limit=limit)


def forward_stats(index, block_ms, alert_price):
    """alert nantar +1h / +4h / +24h (close-chya tulनेत) aani 24h madhla uchch."

    य़ाची काहीही भविष्यवाणी नाही — फक्त 'nantar kay zhala' हा data."""

    def close_after(hours):
        c = index.get(block_ms + (2 + hours) * HOUR_MS)
        return c["close"] if c else None

    def pct(x):
        if x is None or not alert_price:
            return None
        return (x - alert_price) / alert_price * 100.0

    c1 = close_after(1)
    c4 = close_after(4)
    c24 = close_after(24)

    hi = None
    for k in range(1, 25):
        c = index.get(block_ms + (2 + k) * HOUR_MS)
        if c is None:
            continue
        hi = c["high"] if hi is None else max(hi, c["high"])

    up = None
    if hi is not None and alert_price:
        up = (hi - alert_price) / alert_price * 100.0

    return {
        "chg_1h_pct": pct(c1),
        "chg_4h_pct": pct(c4),
        "chg_24h_pct": pct(c24),
        "max_up_24h_pct": up,
    }


def find_matches(symbol, rows, days, now_ms):
    """magil `days` divsat jhालेले sगळे tin-candle matches."""

    if not rows:
        return []

    index = {r["open_time"]: r for r in rows}

    from_ms = now_ms - days * DAY_MS

    block = (from_ms // FOUR_H_MS) * FOUR_H_MS
    if block < from_ms:
        block += FOUR_H_MS

    out = []

    while block + 3 * HOUR_MS <= now_ms:

        three = tc.pick_candles(rows, block)

        if three is not None:
            res = tc.check_three(three)

            if res:
                price = three[2]["close"]
                d1, d2, d3 = res["details"]

                row = {
                    "symbol": symbol,
                    "block_ms": block,
                    "alert_ms": block + 3 * HOUR_MS,
                    "alert_ist": ist_str(block + 3 * HOUR_MS),
                    "block_ist": f"{hm_ist(block)} – {hm_ist(block + 3 * HOUR_MS)}",
                    "r1": d1["range"], "r2": d2["range"], "r3": d3["range"],
                    "base_1_2": res["base"], "ratio": res["ratio"],
                    "body1_pct": d1["body"] * 100, "close1_pct": d1["pos"] * 100,
                    "body2_pct": d2["body"] * 100, "close2_pct": d2["pos"] * 100,
                    "body3_pct": d3["body"] * 100, "close3_pct": d3["pos"] * 100,
                    "alert_price": price,
                }
                row.update(forward_stats(index, block, price))
                out.append(row)

        block += FOUR_H_MS

    return out


def funnel_symbol(symbol, rows, days, now_ms):
    """dar tapyavar kiti windows thambतात (cumulative) + javalche miss + aakडे."""

    counts = [0] * 8          # 0 = ekun | 1..7 = tapasणी
    near = []
    values = []               # [(body1, body2, body3, ratio)] — what-if sathi

    if not rows:
        return counts, near, values

    ratio_min = tc.THIRD_RATIO

    from_ms = now_ms - days * DAY_MS

    block = (from_ms // FOUR_H_MS) * FOUR_H_MS
    if block < from_ms:
        block += FOUR_H_MS

    while block + 3 * HOUR_MS <= now_ms:

        three = tc.pick_candles(rows, block)

        if three is not None:

            a, b, c = three

            ra, rb, rc = (tc.candle_range(a), tc.candle_range(b), tc.candle_range(c))

            if ra > 0 and rb > 0 and rc > 0:

                counts[0] += 1

                base_v = pair_base(a, b)

                # hiravi aट nehmich aahe — m्हणून fakt tinte hirvi asताना aakडे jamवतो
                if (base_v > 0 and tc.is_green(a) and tc.is_green(b)
                        and tc.is_green(c)):
                    values.append((
                        rule_value(a, SPEC1), rule_value(b, SPEC2),
                        rule_value(c, SPEC3),
                        (tc.close_position(c) if not NEW_RULES else None),
                        rc / base_v))

                if tc.is_green(a):
                    counts[1] += 1

                    if rule_ok(a, SPEC1):
                        counts[2] += 1

                        if tc.is_green(b):
                            counts[3] += 1

                            if rule_ok(b, SPEC2):
                                counts[4] += 1

                                if tc.is_green(c):
                                    counts[5] += 1

                                    base = pair_base(a, b)

                                    ratio = rc / base if base > 0 else 0.0
                                    v3 = rule_value(c, SPEC3)

                                    ok_third = rule_ok(c, SPEC3)
                                    ok_ratio = ratio >= ratio_min - 1e-12

                                    if ok_third:
                                        counts[6] += 1

                                    if ok_third and ok_ratio:
                                        counts[7] += 1
                                    elif len(near) < 8000:
                                        near.append({
                                            "symbol": symbol, "block": block,
                                            "ratio": ratio, "v3": v3,
                                            "v3_ok": ok_third,
                                            "body3": tc.body_ratio(c),
                                        })

        block += FOUR_H_MS

    return counts, near, values


_UNSET = object()


def count_if(values, m1, m2, m3, ratio_min, extra_min=_UNSET):
    """itkya aakड्यांनी kiti matches yetat."""

    if extra_min is _UNSET:
        extra_min = EXTRA3_MIN

    n = 0

    for b1, b2, b3, x3, r in values:

        if (b1 >= m1 - 1e-12 and b2 >= m2 - 1e-12 and b3 >= m3 - 1e-12
                and r >= ratio_min - 1e-12
                and (extra_min is None or x3 is None or x3 >= extra_min - 1e-12)):
            n += 1

    return n


def build_whatif(values, b1, b2, b3, ratio):

    lines = []

    def w(s=""):
        lines.append(s)

    cur = count_if(values, b1, b2, b3, ratio)

    w("KAY BADALAL TAR KITI MATCHES?   (aajche data var, ekun hirviya windows "
      f"{len(values):,})")
    w()
    w(f"   ✅ aajche niyam ({rule_text(SPEC1)} / {rule_text(SPEC2)} / "
      f"{rule_text(SPEC3)}, ratio {ratio:.2f}x) : {cur:>6,}")

    w(f"   ---- fakt 3री {W3} ----")

    for v in (round(b3 - 0.05, 2), round(b3 - 0.10, 2), round(b3 - 0.15, 2)):
        if v > 0:
            lbl = f"3री {W3} {b3*100:.0f}% → {v*100:.0f}%"
            w(f"      {lbl:<34}: {count_if(values, b1, b2, v, ratio):>6,}")

    w("   ---- fakt ratio (kadक keLya tar) ----")

    for v in (round(ratio + 0.25, 2), round(ratio + 0.50, 2), round(ratio + 1.00, 2)):
        w(f"      ratio {ratio:.2f}x → {v:.2f}x"
          f"{' ' * 26}: {count_if(values, b1, b2, b3, v):>6,}")

    w("   ---- fakt ratio (sोडLa tar) ----")

    for v in (round(ratio - 0.10, 2), round(ratio - 0.25, 2), round(ratio - 0.50, 2)):
        if v > 0:
            w(f"      ratio {ratio:.2f}x → {v:.2f}x"
              f"{' ' * 26}: {count_if(values, b1, b2, b3, v):>6,}")


    w(f"   ---- fakt 1ली/2री {W1} ----")

    for v in (round(b1 - 0.05, 2), round(b1 - 0.10, 2)):
        if v > 0:
            lbl = f"1ली/2री {W1} {b1*100:.0f}% → {v*100:.0f}%"
            w(f"      {lbl:<34}: {count_if(values, v, v, b3, ratio):>6,}")

    w("   ---- doni-teen ekत्र ----")

    r_lo1 = round(ratio - 0.25, 2)
    r_lo2 = round(ratio - 0.50, 2)

    for m3v, rv in ((round(b3 - 0.10, 2), r_lo1), (round(b3 - 0.05, 2), r_lo1),
                    (round(b3 - 0.10, 2), r_lo2)):
        if m3v > 0 and rv > 0:
            lbl = f"3री {W3} {m3v*100:.0f}% + ratio {rv:.2f}x"
            w(f"      {lbl:<34}: {count_if(values, b1, b2, m3v, rv):>6,}")


    w(f"      {'sगळं sोडun (fakt hirviya)':<34}: "
      f"{count_if(values, 0.0, 0.0, 0.0, 0.0, extra_min=None):>6,}")
    w()

    return lines


def build_funnel_text(counts, near, days, symbols, scanned, errors, now_ms,
                      values=None, thresholds=None):

    lines = []

    def w(s=""):
        lines.append(s)

    w("=" * 70)
    w(" TIN CANDLE — NIYAM KOTHE THAMBतो  (funnel)")
    w(f" magil {days} divas  |  {scanned}/{symbols} pairs chi data  |  errors {errors}")
    w("=" * 70)
    w()

    steps = [
        ("ekun 4h windows (pair x block)", 0),
        ("1ली हिरवी", 1),
        (f"1ली {rule_text(SPEC1)}", 2),
        ("2री हिरवी", 3),
        (f"2री {rule_text(SPEC2)}", 4),
        ("3री हिरवी", 5),
        (f"3री {rule_text(SPEC3)}", 6),
        (f"3री range >= {tc.THIRD_RATIO:.2f}x ({BASE_LABEL})  ==>  MATCH", 7),
    ]

    prev = None

    for label, idx in steps:

        n = counts[idx]

        if prev is None or prev == 0:
            extra = ""
        else:
            extra = f"   ({n / prev * 100:.0f}% tile)"

        w(f"   {label:<40} : {n:>9,}{extra}")
        prev = n

    w()

    if counts[7] == 0:
        w("   ❗ सगळ्यात motha galणी kothe?  varच्या % bgha — tithe mothi tap (drop) aahe.")
        w()

    if values:

        b1m, b2m, b3m, rtm = thresholds or (T1, T2, T3, tc.THIRD_RATIO)

        lines.extend(build_whatif(values, b1m, b2m, b3m, rtm))

    if near:

        near.sort(key=lambda m: -m["ratio"])

        w(f"JAVALCHE MISSES — top 12 (ekun {len(near)}) : ratio motha, pan niyam poorn nahi")
        w(f"   (hya ओळी sanganतat: 'adकलं' kuthे — 3री {W3} ki ratio)")

        for m in near[:12]:

            why = f"3री {W3} kami" if not m["v3_ok"] else "ratio kami"

            w(f"   {m['symbol']:<14} {ist_str(m['block']):>21} | "
              f"ratio {m['ratio']:.2f}x | 3री {W3} {m['v3'] * 100:.0f}% "
              f"(body {m['body3'] * 100:.0f}%) | adकलं: {why}")

    else:
        w("   (ekhi javalcha miss nahi — m्हणजे 1ली/2री chya niyamातch mothi galणी aahe)")

    w()
    w("=" * 70)

    return "\n".join(lines)


def scan_funnel(symbols, days, workers, now_ms):

    counts = [0] * 8
    near = []
    values = []
    errors = 0
    scanned = 0
    done = 0

    with ThreadPoolExecutor(max_workers=workers) as pool:

        jobs = {pool.submit(fetch_rows, s, days): s for s in symbols}

        for job in as_completed(jobs):

            symbol = jobs[job]
            done += 1

            try:
                rows = job.result()
            except Exception:
                errors += 1
                continue

            if not rows:
                continue

            scanned += 1

            try:
                c, n, v = funnel_symbol(symbol, rows, days, now_ms)
                counts = [x + y for x, y in zip(counts, c)]
                near.extend(n)
                if len(values) < 400000:
                    values.extend(v)
            except Exception as e:
                errors += 1
                print("funnel error:", symbol, e, flush=True)

            if done % 100 == 0:
                print(f"   … {done}/{len(symbols)} pairs", flush=True)

    return counts, near, values, scanned, errors


def scan_all(symbols, days, workers, now_ms, quiet=False):
    matches = []
    errors = 0
    scanned = 0
    done = 0

    with ThreadPoolExecutor(max_workers=workers) as pool:

        jobs = {pool.submit(fetch_rows, s, days): s for s in symbols}

        for job in as_completed(jobs):
            symbol = jobs[job]
            done += 1

            try:
                rows = job.result()
            except Exception:
                errors += 1
                continue

            if not rows:
                continue

            scanned += 1

            try:
                matches.extend(find_matches(symbol, rows, days, now_ms))
            except Exception as e:
                errors += 1
                print("scan error:", symbol, e, flush=True)

            if not quiet and done % 50 == 0:
                print(f"   … {done}/{len(symbols)} pairs tapaसले | "
                      f"{len(matches)} matches yet", flush=True)

    matches.sort(key=lambda m: -m["block_ms"])
    return matches, scanned, errors


# ============================================================
# AHWAL
# ============================================================

def avg(values):
    vals = [v for v in values if v is not None]
    return sum(vals) / len(vals) if vals else None


def num(x, unit=""):
    if x is None:
        return "-"
    if abs(x) >= 1000:
        return f"{x:,.0f}{unit}"
    if abs(x) >= 10:
        return f"{x:.1f}{unit}"
    return f"{x:.2f}{unit}"


def build_report(matches, days, symbols, scanned, errors, t_from, t_to, csv_path):
    lines = []

    def w(s=""):
        lines.append(s)

    total = len(matches)

    w("=" * 70)
    w(" TIN CANDLE — MAGIL DATA AHWAL")
    w(f" {ist_str(t_to)}   |   {days} divas ({ist_str(t_from)} pasun)")
    w("=" * 70)
    w()
    w(" NIYAM (tin_candle_scanner.py madhil tech) :")
    w(f"   1ली 1h : {rule_text(SPEC1)}")
    w(f"   2री 1h : {rule_text(SPEC2)}")
    w(f"   3री 1h : {rule_text(SPEC3)}")
    w(f"            +  3री range >= {tc.THIRD_RATIO:.2f} x ({BASE_LABEL})")
    w("   Alert = 3री meणbatti band zhालi ki (dar 4h block)")
    w()

    # ---- [1] ----
    w("[1] EKUN NIKAL")
    w(f"    tapaसलेले pairs : {scanned}/{symbols}   (errors: {errors})")
    w(f"    ekun matches   : {total}")
    if days > 0:
        w(f"    divasातun sarasarI : {total / days:.1f}")
    if matches:
        w(f"    pahila  : {matches[-1]['alert_ist']}  ({matches[-1]['symbol']})")
        w(f"    shevatча : {matches[0]['alert_ist']}  ({matches[0]['symbol']})")
    w()

    if not matches:
        w("    (ya kaलावधीत ekhi match nahi — niyam kadak aahet, he sामान्य)")
        w()
        return "\n".join(lines)

    # ---- [2] ----
    ratios = [m["ratio"] for m in matches]

    w("[2] AAKDE (matches chya)")
    w(f"    3री ÷ base : kamiत-kami {num(min(ratios), 'x')} | "
      f"sarasarI {num(avg(ratios), 'x')} | jastiत-jasti {num(max(ratios), 'x')}")
    third_key = "close3_pct" if W3 == "close" else "body3_pct"

    w(f"    1ली body sarasarI : {num(avg([m['body1_pct'] for m in matches]), '%')}   |   "
      f"2री body : {num(avg([m['body2_pct'] for m in matches]), '%')}   |   "
      f"3री {W3} : {num(avg([m[third_key] for m in matches]), '%')}")
    w(f"    3री chi range : sगळ्यात motha {num(max([m['r3'] for m in matches]))}"
      f"   |   kamiत-kami {num(min([m['r3'] for m in matches]))}")
    w()

    # ---- [3] ----
    blocks = Counter(m["block_ist"] for m in matches)
    w("[3] KONTA BLOCK (IST) KITI VELA")
    for b, c in sorted(blocks.items(), key=lambda kv: -kv[1]):
        w(f"    block {b}  →  {c} vela")
    w()

    # ---- [4] ----
    pairs = Counter(m["symbol"] for m in matches)
    w("[4] JASTI VELA AALELI PAIRS (top 15)")
    for s, c in pairs.most_common(15):
        w(f"    {s:<16} {c} vela")
    if len(pairs) > 15:
        w(f"    … ekun {len(pairs)} vegळ्या pairs")
    w()

    # ---- [5] ----
    byday = {}
    for m in matches:
        day = ist_str(m["alert_ms"])[:10]
        byday.setdefault(day, []).append(m["symbol"])

    w("[5] MATCHES ASLELE DIVAS")
    for day in sorted(byday, reverse=True):
        syms = byday[day]
        short = ", ".join(s.replace("USDT", "") for s in syms[:6])
        more = f" +{len(syms) - 6}" if len(syms) > 6 else ""
        w(f"    {day}  →  {len(syms)}  ({short}{more})")
    w()

    # ---- [6] ----
    c1 = [m["chg_1h_pct"] for m in matches]
    c4 = [m["chg_4h_pct"] for m in matches]
    c24 = [m["chg_24h_pct"] for m in matches]
    up24 = [m["max_up_24h_pct"] for m in matches]

    def updown(vals):
        v = [x for x in vals if x is not None]
        if not v:
            return "-"
        up = sum(1 for x in v if x > 0)
        return f"{up} var / {len(v) - up} khalI (sarasarI {num(avg(v), '%')})"

    w("[6] NANTAR KAY ZHALA (fakt mahiti — hi shifaras nahi)")
    w(f"    +1 तास  : {updown(c1)}")
    w(f"    +4 तास  : {updown(c4)}")
    w(f"    +24 तास : {updown(c24)}")
    w(f"    24 तासांत sर्वोच्च unchi : sarasarI {num(avg(up24), '%')}   "
      f"|   jastiत-jasti {num(max([x for x in up24 if x is not None] or [0]), '%')}")
    w(f"    (jithe data nahi — shevatचे matches — tithे '-' )")
    w()

    w(f"CSV : {csv_path}   ({total} rows)")
    w("=" * 70)

    return "\n".join(lines)


# ============================================================
# CSV
# ============================================================

def write_csv(path, matches):

    with open(path, "w", newline="") as f:

        w = csv.DictWriter(f, fieldnames=CSV_COLUMNS, extrasaction="ignore")
        w.writeheader()

        for m in matches:
            row = dict(m)

            for k in ("r1", "r2", "r3", "base_1_2", "alert_price"):
                row[k] = f"{m[k]:.10g}"

            row["ratio"] = f"{m['ratio']:.4f}"

            for k in ("body1_pct", "close1_pct", "body2_pct", "close2_pct",
                      "body3_pct", "close3_pct", "chg_1h_pct", "chg_4h_pct",
                      "chg_24h_pct", "max_up_24h_pct"):
                row[k] = "" if m[k] is None else f"{m[k]:.2f}"

            w.writerow(row)


# ============================================================
# SWATAHCHI CHAचणी  (network nahit)
# ============================================================

def c1h(start, o, h, l, c):
    return {"open_time": start, "open": o, "high": h, "low": l, "close": c,
            "close_time": start + HOUR_MS - 1}


def up(start, rng, body, pos, base=100.0):
    low = base
    high = base + rng
    close = low + pos * rng
    return c1h(start, close - body * rng, high, low, close)


def flat(start, base=100.0):
    """kाहich nahi asलेली nanD meणbatti — hiravi (5% body)."""

    return c1h(start, base, base + 1.0, base - 1.0, base + 0.1)


def selftest():
    global PASS, FAIL

    print("=" * 70)
    print(" SWATAHCHI CHAचणी — network nahit, kाहich pathवत nahi")
    print("=" * 70)

    # ---- [1] niyam tech aahet ka ----
    print()
    print("[1] NIYAM (scanner shी tech)")
    check(f"1ली : {rule_text(SPEC1)}  (scanner kadun tech)", True, rule_text(SPEC1))
    check(f"2री : {rule_text(SPEC2)}  (scanner kadun tech)", True, rule_text(SPEC2))
    check(f"3री : {rule_text(SPEC3)}  (scanner kadun tech)", True, rule_text(SPEC3))
    check("3री chi range >= scanner cha ratio (tc.THIRD_RATIO)",
          tc.THIRD_RATIO > 0, f"{tc.THIRD_RATIO:.2f}x")
    _bm = getattr(tc, "BASE_OF_2X", None)

    if _bm is None:
        check("base : juna scanner (1ली + 2री chi beriज paddhat) — abhyas tich vaparel ✅",
              True, "scanner madhe BASE_OF_2X nahi")
    elif _bm == "low1_high2":
        check("base = 1ली cha low → 2री cha high (nava niyam) ✅", True)
    else:
        check(f"base = '{_bm}' — scanner sanganतो tya pramाणे abhyas ✅", True, _bm)
    check("6 blocks : 05:30 09:30 13:30 17:30 21:30 01:30 (UTC min)",
          BLOCK_MIN_UTC == [0, 240, 480, 720, 960, 1200])

    # ---- [2] fixture ----
    print()
    print("[2] FIXTURE (kalthi meणbattya — network nahit)")
    # 1 divas = UTC madhya-ratri pasun; sगळ्या 1h meणbattya
    t0 = 1_700_000_000_000 // DAY_MS * DAY_MS
    now = t0 + 10 * DAY_MS

    RT = tc.THIRD_RATIO            # 1.00 = nava niyam | 2.00 = juna
    RB = 2.2                      # 1ली low 100 → 2री high 102.2

    rows = [flat(t0 + i * HOUR_MS) for i in range(0, 10 * 24)]

    def put(lst, start):
        for c in lst:
            idx = (c["open_time"] - t0) // HOUR_MS
            if 0 <= idx < len(rows):
                rows[idx] = c

# (a) jhuणणारा : base (1ली low 100 → 2री high 102.2) = 2.2 → 3री = 2.2 x RT
    b1 = t0 + 1 * DAY_MS + 4 * HOUR_MS          # UTC 04:00 = IST 09:30 block
    put([up(b1, 1.0, 0.70, 0.70),
         up(b1 + HOUR_MS, 1.2, 0.75, 0.80, base=101.0),
         up(b1 + 2 * HOUR_MS, 2.2 * RT, 0.85, 0.90, base=102.2)], start=b1)

    # alert nantar cha bhava ठरवलेला : block+3h la close 110 (alert price 105.4)
    put([c1h(b1 + 3 * HOUR_MS, 105.4, 110.5, 105.0, 110.0)], start=b1)

    # (b) ratio thoda kami (RT − 0.01) → nahi
    b2 = t0 + 2 * DAY_MS + 12 * HOUR_MS         # UTC 12:00 = IST 17:30 block
    put([up(b2, 1.0, 0.70, 0.70),
         up(b2 + HOUR_MS, 1.2, 0.75, 0.80, base=101.0),
         up(b2 + 2 * HOUR_MS, 2.2 * (RT - 0.01), 0.85, 0.90, base=102.2)], start=b2)

    # (c) 3री chi CLOSE 65% → nahi (70% havi) — ratio poorn aahe (RT)
    b3 = t0 + 3 * DAY_MS + 20 * HOUR_MS         # UTC 20:00 = IST 01:30 block
    put([up(b3, 1.0, 0.70, 0.70),
         up(b3 + HOUR_MS, 1.2, 0.70, 0.80, base=101.0),
         up(b3 + 2 * HOUR_MS, 2.2 * RT, 0.60, 0.65, base=102.2)], start=b3)

    # (d) motha jhuणणारा : base 1.0 + 1.0 = 2.0 → 3री 10 = 5x
    b4 = t0 + 5 * DAY_MS + 0 * HOUR_MS          # UTC 00:00 = IST 05:30 block
    put([up(b4, 1.0, 0.72, 0.75),
         up(b4 + HOUR_MS, 1.0, 0.80, 0.82, base=101.0),
         up(b4 + 2 * HOUR_MS, 10.0, 0.90, 0.95, base=102.0)], start=b4)

    # (e) shevatla jhuणणारा : +24 तास cha data nahit (data sampaला)
    b5 = t0 + 9 * DAY_MS + 20 * HOUR_MS         # UTC 20:00 = IST 01:30 block
    put([up(b5, 1.0, 0.70, 0.70),
         up(b5 + HOUR_MS, 1.2, 0.75, 0.80, base=101.0),
         up(b5 + 2 * HOUR_MS, 2.2 * RT, 0.85, 0.90, base=102.2)], start=b5)

    # (f) 3री cha BODY fakt 35% PAN close 88% → MATCH (body chi aट nahi)
    b6 = t0 + 6 * DAY_MS + 8 * HOUR_MS          # UTC 08:00 = IST 13:30 block
    put([up(b6, 1.0, 0.74, 0.78),
         up(b6 + HOUR_MS, 1.2, 0.75, 0.82, base=101.0),
         up(b6 + 2 * HOUR_MS, 2.2 * RT + 0.05, 0.35, 0.88, base=102.2)], start=b6)

    # ---- [3] shodhणी ----
    print()
    print("[3] SHODHणी (fixture var)")

    ms = []
    for sym in ("AAAUSDT", "BBBUSDT"):
        ms += find_matches(sym, rows, 10, now)

    exp_matches = 8 if NEW_RULES else 6

    check(f"ekun {exp_matches} matches (2 pairs x {exp_matches // 2} jhuणणारे)",
          len(ms) == exp_matches, f"{len(ms)} sapadले")
    check(f"b1 ({RT:.2f}x) sapadla",
          any(m["block_ms"] == b1 for m in ms))
    check("b4 (5x) sapadla",
          any(m["block_ms"] == b4 for m in ms))
    check("b5 (shevatचा) sapadla",
          any(m["block_ms"] == b5 for m in ms))
    if NEW_RULES:
        check("b6 (3री body 35% pan close 88%) sapadla — body aट nahi ✅",
              any(m["block_ms"] == b6 for m in ms))
    else:
        check("b6 (juna niyam : 3री body 35% < 80%) sapadla NAHI", 
              not any(m["block_ms"] == b6 for m in ms))
    check(f"b2 ({RT - 0.01:.2f}x) sapadla NAHI",
          not any(m["block_ms"] == b2 for m in ms))
    check("b3 (3री chi close 65%) sapadla NAHI",
          not any(m["block_ms"] == b3 for m in ms))

    my = [m for m in ms if m["block_ms"] == b1][0]
    check(f"ratio = {RT:.2f}x", abs(my["ratio"] - RT) < 1e-9, f"{my['ratio']:.3f}x")
    check("base = 2.2 (1ली low → 2री high)", abs(my["base_1_2"] - 2.2) < 1e-9)
    check("block 09:30 (IST)", my["block_ist"].startswith("09:30"), my["block_ist"])

    # ---- [4] scanner shी tech niyam vaparla ka? ----
    print()
    print("[4] SCANNER SHी TECH NIYAM (brute force tulna)")

    brute = []
    blk = (now - 10 * DAY_MS) // FOUR_H_MS * FOUR_H_MS
    while blk + 3 * HOUR_MS <= now:
        three = tc.pick_candles(rows, blk)
        if three and tc.check_three(three):
            brute.append(blk)
        blk += FOUR_H_MS

    mine = sorted(m["block_ms"] for m in ms if m["symbol"] == "AAAUSDT")
    check("brute force shी identical nikaal", mine == sorted(set(brute)),
          f"{len(mine)} vs {len(set(brute))}")

    # ---- [5] nantar kay zhala ----
    print()
    print("[5] NANTAR KAY ZHALA")

    my2 = [m for m in ms if m["block_ms"] == b1][0]

    px = 102.2 + 0.90 * (2.2 * RT)
    exp1 = (110.0 / px - 1.0) * 100.0
    exp24 = (100.1 / px - 1.0) * 100.0

    check(f"alert price = 3री cha close ({px:.2f})",
          abs(my2["alert_price"] - px) < 1e-9, f"{my2['alert_price']:.2f}")
    check(f"+1 तास : {px:.2f} → 110.0 = {exp1:+.2f}%",
          my2["chg_1h_pct"] is not None and abs(my2["chg_1h_pct"] - exp1) < 0.02,
          f"{my2['chg_1h_pct']:.2f}%")
    check(f"+24 तास : {px:.2f} → 100.1 = {exp24:+.2f}%",
          my2["chg_24h_pct"] is not None and abs(my2["chg_24h_pct"] - exp24) < 0.02,
          f"{my2['chg_24h_pct']:.2f}%")


    my5 = [m for m in ms if m["block_ms"] == b5][0]
    check("+24 तास cha data nahit → None (sahi vaagणं)",
          my5["chg_24h_pct"] is None)

    # ---- [5b] funnel ----
    print()
    print("[5b] FUNNEL (niyam kothe thambतो)")

    fc, fn, fv = funnel_symbol("AAAUSDT", rows, 10, now)
    check("ekun windows = 60 (10 divas x 6 blocks)", fc[0] == 60, f"{fc[0]}")
    check("shaKha kधीच vadhat nahi (cumulative)",
          all(fc[i] >= fc[i + 1] for i in range(7)), f"{fc[1:]}")
    exp_f7 = 4 if NEW_RULES else 3

    check(f"poorn matches = {exp_f7}", fc[7] == exp_f7, f"{fc[7]}")
    check("javalche misses aahet (b2 1.99x, b3 close 65%)", len(fn) >= 2, f"{len(fn)}")

    fr2 = [m for m in fn if abs(m["ratio"] - (RT - 0.01)) < 0.001]
    if NEW_RULES:
        check(f"b3 (ratio {RT:.2f} pan 3री close 65%) miss madhe — 'close kami'",
              any(abs(m["ratio"] - RT) < 1e-6 and not m["v3_ok"] for m in fn))
    else:
        check("b3 (juna niyam : 3री body 60% / close 65% < 80%) miss madhe",
              any(abs(m["ratio"] - RT) < 1e-6 and not m["v3_ok"] for m in fn))
    check(f"b2 ({RT - 0.01:.2f}x) miss madhe — karan 'ratio kami'",
          len(fr2) == 1 and fr2[0]["v3_ok"])

    check("aakडे jamले = 60 windows (sगळे hirviya — fixture madhe)", len(fv) == 60,
          f"{len(fv)}")

    check(f"what-if : aajche niyam = {exp_f7}",
          count_if(fv, T1, T2, T3, RT) == exp_f7,
          f"{count_if(fv, T1, T2, T3, RT)}")
    check(f"what-if : 3री {W3} {T3*100:.0f}% → {(T3-0.05)*100:.0f}%  (kami hot nahi)",
          count_if(fv, T1, T2, T3 - 0.05, RT) >= exp_f7,
          f"{count_if(fv, T1, T2, T3 - 0.05, RT)}")
    check(f"what-if : ratio {RT:.2f} → {RT-0.01:.2f}  (jast matches yetat)",
          count_if(fv, T1, T2, T3, RT - 0.01) >= exp_f7,
          f"{count_if(fv, T1, T2, T3, RT - 0.01)}")
    check("what-if : doni sोडlyavar (sगळ्यात jast)",
          count_if(fv, T1, T2, T3 - 0.05, RT - 0.01) >= count_if(fv, T1, T2, T3 - 0.05, RT),
          f"{count_if(fv, T1, T2, T3 - 0.05, RT - 0.01)}")
    check("what-if : sгळं sोडun = 60 (sगळे hirviya)",
          count_if(fv, 0.0, 0.0, 0.0, 0.0, extra_min=None) == 60,
          f"{count_if(fv, 0.0, 0.0, 0.0, 0.0, extra_min=None)}")

    ftxt = build_funnel_text(fc, fn, 10, 1, 1, 0, now, fv)
    for bit in ["NIYAM KOTHE THAMBतो", "ekun 4h windows", "1ली हिरवी",
                "MATCH", BASE_LABEL, "JAVALCHE MISSES",
                "KAY BADALAL TAR KITI MATCHES", "aajche niyam",
                "doni-teen ekत्र"]:
        check(f"funnel text madhe '{bit}'", bit in ftxt)

    # ---- [6] CSV ----
    print()
    print("[6] CSV")

    tmp_csv = "/tmp/tin_30din_selftest.csv"
    write_csv(tmp_csv, ms)

    with open(tmp_csv) as f:
        data = list(csv.DictReader(f))

    check(f"CSV madhe {exp_matches} rows", len(data) == exp_matches, f"{len(data)}")
    check("CSV header madhe symbol + ratio + chg_24h_pct",
          all(k in data[0] for k in ("symbol", "ratio", "chg_24h_pct", "alert_ist")))
    check(f"CSV madhe {RT:.2f}x chi row aahe",
          any(abs(float(r["ratio"]) - RT) < 1e-6 for r in data))
    os.remove(tmp_csv)

    # ---- [7] ahwal ----
    print()
    print("[7] AHWAL (report)")

    rep = build_report(ms, 10, 2, 2, 0, now - 10 * DAY_MS, now, "test.csv")
    bits = ["[1] EKUN NIKAL", "[2] AAKDE", "[3] KONTA BLOCK",
            "[4] JASTI VELA", "[5] MATCHES ASLELE DIVAS",
            "[6] NANTAR KAY ZHALA", f"ekun matches   : {exp_matches}",
            rule_text(SPEC1), rule_text(SPEC3), BASE_LABEL.split(" (")[0]]

    for bit in bits:
        check(f"report madhe '{bit}'", bit in rep)

    rep0 = build_report([], 10, 2, 2, 0, now - 10 * DAY_MS, now, "test.csv")
    check("kाहich nahi asel tar report तरी येतो", "ekhi match nahi" in rep0)

    print()
    print("=" * 70)
    print(f" निकाल : {PASS} pass, {FAIL} fail")
    print("=" * 70)

    return 0 if FAIL == 0 else 1


# ============================================================
# MAIN
# ============================================================

def main():

    ap = argparse.ArgumentParser(
        description="TIN CANDLE — magil N divsancha ahwal (fakt vaachte)")

    ap.add_argument("--days", type=int, default=30, help="kiti divas (default 30)")
    ap.add_argument("--csv", default="tin_30din.csv", help="CSV file (default tin_30din.csv)")
    ap.add_argument("--symbol", default="", help="fakt ha ek symbol")
    ap.add_argument("--symbols", type=int, default=0, help="fakt pahlе itke symbols")
    ap.add_argument("--workers", type=int, default=12)
    ap.add_argument("--selftest", action="store_true", help="chaanणी (network nahit)")
    ap.add_argument("--funnel", action="store_true",
                    help="niyam kothe thambतो te dakhva (matches kadhi 0 ka yetat)")

    args = ap.parse_args()

    if args.selftest:
        sys.exit(selftest())

    now_ms = tc.now_ms()
    t_from = now_ms - args.days * DAY_MS

    print()
    print("=" * 70)
    print(f" TIN CANDLE — MAGIL {args.days} DIVSANCHA DATA")
    print(f" aata : {ist_str(now_ms)}")
    print("=" * 70)

    try:
        if args.symbol:
            symbols = [args.symbol.upper()]
        else:
            symbols = tc.fetch_active_symbols()
            if args.symbols:
                symbols = symbols[:args.symbols]
    except Exception as e:
        print("symbols aणता alе nahit:", e)
        sys.exit(1)

    print(f" pairs : {len(symbols)}   |   workers : {args.workers}", flush=True)

    if args.funnel:

        counts, near, values, scanned, errors = scan_funnel(symbols, args.days,
                                                             args.workers, now_ms)

        print()
        print(build_funnel_text(counts, near, args.days, len(symbols),
                                scanned, errors, now_ms, values))
        print()
        sys.exit(0)

    matches, scanned, errors = scan_all(symbols, args.days, args.workers, now_ms)

    rep = build_report(matches, args.days, len(symbols), scanned, errors,
                       t_from, now_ms, os.path.abspath(args.csv))

    print()
    print(rep)
    print()

    write_csv(args.csv, matches)
    print(f"CSV tayaar : {os.path.abspath(args.csv)}   ({len(matches)} rows)")
    print()


if __name__ == "__main__":
    main()

