
#!/bin/bash
# ============================================================
#  v7 STICK MONITOR — बाहेरून तपासणी (scanner code ला हात नाही)
#
#    v7_monitor.sh check   -> दर 5 मिनिटाला: heartbeat आहे का? scan झाला का? जागा आहे का?
#    v7_monitor.sh daily   -> रोज 09:00 IST ला Telegram वर अहवाल
#    v7_monitor.sh test    -> एक test message (एकदा हेच चालवा)
#    v7_monitor.sh selftest-> offline चाचणी (network नाही, Telegram नाही)
#
#  v7 चे वेळापत्रक : दर तासाला (:00 वाजता) scan — 1h · दर 2 तासांनी 2h ·
#                     दर 4 तासांनी 4h · दर 8 तासांनी 8h  (सगळे IST)
#                    दर 60 सेकंदाला heartbeat journal मध्ये येतो.
#
#  हा script स्वतंत्र आहे — live_scanner.py मध्ये काहीच बदलत नाही.
#  आणि tin-candle-scanner ला काहीच हात लागत नाही.
# ============================================================

DIR="${V7_DIR:-/home/ubuntu/trading-bot}"
SVC="${V7_SVC:-binance-scanner.service}"
SCRIPT="${V7_SCRIPT:-$DIR/live_scanner.py}"
ENV_FILE="$DIR/.env"
STATE_DIR="${V7_MON_STATE_DIR:-/var/lib/v7-monitor}"
STATE_FILE="$STATE_DIR/state"
LOG_FILE="$STATE_DIR/monitor.log"
STRIKE_FILE="$STATE_DIR/strikes"
DAILY_FLAG="$STATE_DIR/daily.flag"
ALERTS_FILE="$DIR/alerts_sent.json"

# ---- आकडे (बदलायचे असल्यास इथे) ----
HEART_SLACK_SEC=300     # इतक्या सेकंदांत heartbeat नाही = शंका (5 मिनिटं)
SCAN_SLACK_SEC=4800     # इतक्यात पूर्ण scan नाही = शंका (80 मिनिटं; अपेक्षा दर तासाला)
GRACE_SEC=240           # सेवा नुकतीच सुरू झाली असेल तर शांत
LOW_DISK_MB=500         # इतक्यापेक्षा कमी जागा = कळवा
REPEAT_SEC=21600        # एकच त्रुटी 6 तासांत एकदाच कळवा
NEED_STRIKES=2          # 2 वेळा (~10 मिनिटं) शंका आली तरच restart
RESTART_WAIT="${V7_RESTART_WAIT:-30}"
# restart कसा करायचा (चाचणीत 'true' ठेवतो — खऱ्या सेवेला हात लागू नये)
RESTART_CMD="${V7_RESTART_CMD:-systemctl restart $SVC}"
DAILY_WINDOW_SEC=32400  # 09:00 IST (दिवसातले सेकंद) — यानंतर रोजचा अहवाल

mkdir -p "$STATE_DIR" 2>/dev/null

# ---------- वेळ ----------
now_epoch(){ echo "${V7_NOW_EPOCH:-$(date +%s)}"; }
ist_now(){ TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M:%S IST'; }
ist_today(){ TZ=Asia/Kolkata date '+%d-%m-%Y'; }
sod_ist(){ echo $(( ($(now_epoch) + 19800) % 86400 )); }   # दिवसातले सेकंद (IST)

log(){ echo "$(ist_now) $*" >>"$LOG_FILE" 2>/dev/null
       if [ -n "${V7_DRY:-}" ] && [ -z "${V7_LOG_QUIET:-}" ]; then echo "[LOG] $*"; fi ; }

hhmm(){ printf '%02d:%02d' $(( $1 / 3600 )) $(( ($1 % 3600) / 60 )); }

# ---------- .env मधून value ----------
get_env(){
  [ -f "$ENV_FILE" ] || return 1
  grep -E "^[[:space:]]*$1=" "$ENV_FILE" 2>/dev/null | head -1 | cut -d= -f2- \
    | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
          -e 's/^"//' -e 's/"$//' -e "s/^'//" -e "s/'$//" | tr -d '\r'
}

# ---------- Telegram ----------
send_tg(){
  if [ -n "${V7_DRY:-}" ]; then
    echo "----- TELEGRAM (dry) -----"; echo "$1"; echo "--------------------------"
    return 0
  fi
  TOKEN=$(get_env V7_TELEGRAM_BOT_TOKEN); [ -n "$TOKEN" ] || TOKEN=$(get_env TELEGRAM_BOT_TOKEN)
  CHAT=$(get_env V7_TELEGRAM_CHAT_ID);    [ -n "$CHAT" ]  || CHAT=$(get_env TELEGRAM_CHAT_ID)
  if [ -z "$TOKEN" ] || [ -z "$CHAT" ]; then
    log "TRUTI: .env madhe TELEGRAM_BOT_TOKEN/CHAT_ID sapadla nahi ($ENV_FILE)"
    return 1
  fi
  if command -v curl >/dev/null 2>&1; then
    curl -s -m 20 -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" \
         --data-urlencode "chat_id=$CHAT" \
         --data-urlencode "text=$1" >/dev/null 2>&1
  else
    python3 - "$TOKEN" "$CHAT" "$1" <<'PYEOF' >/dev/null 2>&1
import sys, urllib.parse, urllib.request
t, c, m = sys.argv[1], sys.argv[2], sys.argv[3]
d = urllib.parse.urlencode({"chat_id": c, "text": m}).encode()
try:
    urllib.request.urlopen(f"https://api.telegram.org/bot{t}/sendMessage", d, timeout=20)
except Exception:
    pass
PYEOF
  fi
  return 0
}

# ---------- सेवेची माहिती ----------
svc_active(){ [ -n "${V7_FAKE_ACTIVE:-}" ] && { echo "$V7_FAKE_ACTIVE"; return; }
              systemctl is-active "$SVC" 2>/dev/null; }
svc_enabled(){ [ -n "${V7_FAKE_ENABLED:-}" ] && { echo "$V7_FAKE_ENABLED"; return; }
               systemctl is-enabled "$SVC" 2>/dev/null; }
svc_uptime_sec(){
  if [ -n "${V7_FAKE_UPTIME:-}" ]; then echo "$V7_FAKE_UPTIME"; return; fi
  TS=$(systemctl show "$SVC" -p ActiveEnterTimestamp --value 2>/dev/null)
  [ -n "$TS" ] || { echo 0; return; }
  S=$(date -d "$TS" +%s 2>/dev/null) || { echo 0; return; }
  echo $(( $(now_epoch) - S ))
}
svc_restarts(){
  if [ -n "${V7_FAKE_RESTARTS:-}" ]; then echo "$V7_FAKE_RESTARTS"; return; fi
  R=$(systemctl show "$SVC" -p NRestarts --value 2>/dev/null); echo "${R:-0}"
}

# ---------- journal ----------
#  V7_JOURNAL_FILE दिले तर तीच फाइल वाचतो (चाचणीसाठी) — नाहीतर खरा journal
journal_window(){   # $1 = किती सेकंद मागे
  if [ -n "${V7_JOURNAL_FILE:-}" ]; then cat "$V7_JOURNAL_FILE" 2>/dev/null; return; fi
  journalctl -u "$SVC" --since "@$(( $(now_epoch) - $1 ))" --no-pager -o cat 2>/dev/null
}
count_in(){  # $1 = किती सेकंद मागे, $2 = नमुना
  journal_window "$1" | grep -c -F "$2"
}
last_in(){   # $1 = किती सेकंद मागे, $2 = नमुना
  journal_window "$1" | grep -F "$2" | tail -1
}

# ---------- पुढचा scan ----------
#  scanner चे मेणबत्ते UTC वर आधारित आहेत → scan चा झटका दर UTC तासाला (:00 UTC)
#  म्हणजे IST मध्ये प्रत्येक तासाला :30 ला (उदा. 15:30, 16:30 ...)
next_scan_info(){
  NOW=$(now_epoch)
  NEXT_UTC=$(( (NOW / 3600 + 1) * 3600 ))      # पुढचा UTC तासाचा ठोका
  UH=$(( (NEXT_UTC / 3600) % 24 ))             # तो UTC तास
  NEXT_IST=$(( (NEXT_UTC + 19800) % 86400 ))   # तोच क्षण IST मध्ये
  TFS="1h"
  [ $(( UH % 2 )) -eq 0 ] && TFS="$TFS, 2h"
  [ $(( UH % 4 )) -eq 0 ] && TFS="$TFS, 4h"
  [ $(( UH % 8 )) -eq 0 ] && TFS="$TFS, 8h"
  echo "$(hhmm "$NEXT_IST") IST ($TFS)"
}

# ---------- state ----------
set_state(){ echo "$1|$(date +%s)" >"$STATE_FILE" 2>/dev/null; }

notify_once(){   # $1 = key, $2 = message (एकच त्रुटी वारंवार नको)
  KEY="$1"
  LAST_KEY=""; LAST_TS=0
  [ -f "$STATE_FILE" ] && IFS='|' read -r LAST_KEY LAST_TS <"$STATE_FILE"
  NOW=$(date +%s)
  if [ "$KEY" = "$LAST_KEY" ] && [ $((NOW - ${LAST_TS:-0})) -lt "$REPEAT_SEC" ]; then
    log "purvicha majkur dila aahe ($KEY) - punha pathvat nahi"
    return 0
  fi
  send_tg "$2"
  set_state "$KEY"
}

# ---------- जागा (disk) ----------
check_disk(){
  FREE_MB=$(df -Pk "$DIR" 2>/dev/null | awk 'NR==2 {print int($4/1024)}')
  case "$FREE_MB" in ''|*[!0-9]*) FREE_MB="" ;; esac
  if [ -n "$FREE_MB" ] && [ "$FREE_MB" -lt "$LOW_DISK_MB" ]; then
    notify_once "disk" "⚠️ JAGAA KAMI AAHE — v7 STICK SCANNER

Fakt ${FREE_MB}MB free aahe ($DIR).
Jaga mokli kara (junya backup files kadhun taka).

Tapat kara:  df -h $DIR
Vela: $(ist_now)"
    log "JAGA KAMI: ${FREE_MB}MB free"
  fi
}

# ============================================================
#  CHECK — दर 5 मिनिटाला
# ============================================================
do_check(){

  # ---- 0) रोजच्या अहवालाची वेळ झाली का? (रोज एकदाच) ----
  SOD=$(sod_ist)
  if [ "$SOD" -ge "$DAILY_WINDOW_SEC" ] && [ "$(cat "$DAILY_FLAG" 2>/dev/null)" != "$(ist_today)" ]; then
    ist_today >"$DAILY_FLAG" 2>/dev/null
    do_daily
    log "DAILY (check madhun) pathvla"
    return 0
  fi

  ACTIVE=$(svc_active)

  if [ "$ACTIVE" != "active" ]; then
    notify_once "down" "❌ v7 STICK SCANNER BAND AAHE

Seva: $ACTIVE
Monitor swatahun suru kart nahi (jaanun band kelela asu shakto).

Tapat kara:  sudo systemctl status $SVC
Vela: $(ist_now)"
    log "DOWN: seva $ACTIVE"
    return 0
  fi

  UP=$(svc_uptime_sec)

  if [ "$UP" -lt "$GRACE_SEC" ]; then
    log "OK: seva navin suru ($UP sec) - grace madhe"
    return 0
  fi

  # ---- 1) heartbeat (दर 60 सेकंदाला येतो) ----
  HEARTS=$(count_in "$HEART_SLACK_SEC" 'HEARTBEAT |')
  # ---- 2) पूर्ण scan (दर तासाला) ----
  SCANS=$(count_in "$SCAN_SLACK_SEC" 'Setup scan complete')

  STRUCK=0
  [ "${HEARTS:-0}" -ge 1 ] || { STRUCK=$((STRUCK + 1)); }
  [ "${SCANS:-0}"  -ge 1 ] || { STRUCK=$((STRUCK + 1)); }

  if [ "$STRUCK" -eq 0 ]; then
    rm -f "$STRIKE_FILE" 2>/dev/null
    check_disk
    set_state "ok"
    log "OK: heartbeat $HEARTS (${HEART_SLACK_SEC}s) | scans $SCANS (${SCAN_SLACK_SEC}s)"
    return 0
  fi

  STRIKES=$(cat "$STRIKE_FILE" 2>/dev/null)
  [ -n "$STRIKES" ] || STRIKES=0
  STRIKES=$(( STRIKES + (STRUCK > 0 ? 1 : 0) ))
  echo "$STRIKES" >"$STRIKE_FILE" 2>/dev/null

  if [ "$STRIKES" -lt "$NEED_STRIKES" ]; then
    log "SHANKA: heartbeat=$HEARTS scans=$SCANS ($STRIKES/$NEED_STRIKES) - ajun thambto"
    return 0
  fi

  log "TRAS: heartbeat=$HEARTS scans=$SCANS ($STRIKES/$NEED_STRIKES) - restart karto..."
  $RESTART_CMD >/dev/null 2>&1
  sleep "$RESTART_WAIT"
  NEW=$(svc_active)

  if [ "$NEW" = "active" ]; then
    MSG="⚠️ v7 STICK SCANNER ADKALA HOTA — MONITOR NE PARAT SURU KELA

$(( HEART_SLACK_SEC / 60 )) minit heartbeat nahi aala
aaणि $(( SCAN_SLACK_SEC / 60 )) minit scan pan zala nahi hota
(donhi velya tapasani kelyavar). 

✅ Restart nantar: $NEW
Vela: $(ist_now)"
  else
    MSG="🚨 v7 STICK SCANNER PARAT SURU ZALA NAHI!

Monitor ne restart kela, pan seva aata: $NEW

Lagech tapat kara:
  sudo systemctl status $SVC
  sudo journalctl -u $SVC -n 40 --no-pager"
  fi

  send_tg "$MSG"
  set_state "restarted"
  log "RESTART kela -> $NEW"
}

# ============================================================
#  DAILY — रोज 09:00 IST
# ============================================================
do_daily(){

  ACTIVE=$(svc_active)
  ENABLED=$(svc_enabled)
  UP=$(svc_uptime_sec)
  UP_H=$(( UP / 3600 ))
  RESTARTS=$(svc_restarts)

  W=86400                       # गेले 24 तास
  SCANS=$(count_in "$W" 'Setup scan complete')
  SETUPS=$(count_in "$W" 'SETUP REGISTERED:')
  DELIV=$(count_in "$W" 'ALERT DELIVERED')
  HEARTS=$(count_in "$W" 'HEARTBEAT |')

  LAST_ALERT=$(last_in "$W" 'ALERT DELIVERED' | sed 's/^✅ *//; s/^ALERT DELIVERED: *//')
  [ -n "$LAST_ALERT" ] || LAST_ALERT="-(adhi alert nahi)"

  DISK=$(df -h "$DIR" 2>/dev/null | awk 'NR==2 {print $4}')
  [ -n "$DISK" ] || DISK="?"

  AF=""
  if [ -f "$ALERTS_FILE" ]; then
    AF_KB=$(( $(stat -c %s "$ALERTS_FILE" 2>/dev/null || echo 0) / 1024 ))
    AF_KEYS=$(python3 -c "import json,sys
try: print(len(json.load(open(sys.argv[1]))))
except Exception: print('?')" "$ALERTS_FILE" 2>/dev/null)
    AF="
📄 alerts file : ${AF_KB}KB (${AF_KEYS:-?} keys)"
  fi

  EXPECT_SCANS=24

  if [ "$ACTIVE" = "active" ] && [ "${SCANS:-0}" -gt 0 ]; then
    LIVE="✅ हो — गेल्या 24 तासांत $SCANS scan + $HEARTS heartbeat"
  elif [ "$ACTIVE" = "active" ]; then
    LIVE="⚠️ सेवा चालू आहे, पण scan ची नोंद नाही — पुढच्या तपासणीत कळेल"
  else
    LIVE="❌ नही — सेवा $ACTIVE आहे"
  fi

  EXTRA=""
  if [ "${DELIV:-0}" = "0" ]; then
    EXTRA="
ℹ️ alert आला नाही = नियम पूर्ण झाला नाही (यंत्र ठीक आहे)"
  fi

  MSG="📊 v7 STICK दैनंदिन अहवाल
$(TZ=Asia/Kolkata date '+%d-%m-%Y %H:%M') IST

सेवा        : $ACTIVE (enabled: $ENABLED)
चालू        : ${UP_H} तास | restarts: $RESTARTS

गेल्या 24 तासांत (अपेक्षित $EXPECT_SCANS scan — दर तासाला):
  🔍 scans झाले      : $SCANS
  🧩 setups सापडले   : $SETUPS
  🚨 alerts पाठवले   : $DELIV
  🕐 शेवटचा alert    : $LAST_ALERT

💓 जिवंत       : $LIVE
⏰ पुढचा scan  : $(next_scan_info)
💾 जागा        : $DISK free$AF$EXTRA"

  send_tg "$MSG"
  log "DAILY pathvla (scans=$SCANS setups=$SETUPS alerts=$DELIV hearts=$HEARTS restarts=$RESTARTS)"
}

# ============================================================
#  SELFTEST — offline (network नाही, Telegram नाही)
# ============================================================
do_selftest(){

  T=$(mktemp -d)
  PASS=0; FAIL=0
  ck(){ if [ "$2" = "$3" ]; then echo "  ✅ $1 ($2)"; PASS=$((PASS+1));
        else echo "  ❌ $1 — मिळाले '$2' पाहिजे होते '$3'"; FAIL=$((FAIL+1)); fi; }

  cat >"$T/journal" <<'EOF'
BINANCE FUTURES SCANNER v2
Niyam: 1st body >= 50%  |  final close <= 50% (bearish) / >= 50% (bullish)
Symbols: 731
HEARTBEAT | polls 300 | prices 731 | active setups 3 | alerts sent 2 | disk 38000MB free
SETUP REGISTERED: GTLBUSDT 8h Scanner 3 Bearish Reversal | Confirmation: 26-09-2026 13:30:00 IST to 26-09-2026 17:30:00 IST
MATCH: GTLBUSDT 8h Scanner 3
HEARTBEAT | polls 315 | prices 731 | active setups 3 | alerts sent 2 | disk 38000MB free
🚨 ALERT: GTLBUSDT 8h Scanner 3 46.94 | 26-09-2026 16:47:17 IST
✅ ALERT DELIVERED: GTLBUSDT 8h Scanner 3
Setup scan complete. New setups: 8
HEARTBEAT | polls 330 | prices 731 | active setups 3 | alerts sent 3 | disk 38000MB free
EOF

  cat >"$T/.env" <<'EOF'
TELEGRAM_BOT_TOKEN=TESTTOKEN
TELEGRAM_CHAT_ID=123456
EOF

  V7_DIR="$T" V7_JOURNAL_FILE="$T/journal" V7_MON_STATE_DIR="$T/state" \
  V7_DRY=1 V7_FAKE_ACTIVE=active V7_FAKE_ENABLED=enabled V7_FAKE_UPTIME=7200 \
  V7_FAKE_RESTARTS=1 V7_NOW_EPOCH=1758880000 \
  bash "$0" _counts >"$T/out" 2>&1

  ck "heartbeat आकडा"  "$(grep '^HEARTS=' "$T/out" | cut -d= -f2)" "3"
  ck "scan आकडा"       "$(grep '^SCANS='  "$T/out" | cut -d= -f2)" "1"
  ck "setups आकडा"     "$(grep '^SETUPS=' "$T/out" | cut -d= -f2)" "1"
  ck "alerts आकडा"     "$(grep '^DELIV='  "$T/out" | cut -d= -f2)" "1"
  ck "शेवटचा alert"    "$(grep '^LAST='   "$T/out" | cut -d= -f2)" "GTLBUSDT 8h Scanner 3"

  # daily message + roj ekdach
  V7_DIR="$T" V7_JOURNAL_FILE="$T/journal" V7_MON_STATE_DIR="$T/state2" \
  V7_DRY=1 V7_FAKE_ACTIVE=active V7_FAKE_ENABLED=enabled V7_FAKE_UPTIME=7200 \
  V7_FAKE_RESTARTS=1 V7_NOW_EPOCH=1758880000 \
  bash "$0" daily >"$T/daily1" 2>&1
  ok1=$?
  ck "daily निघतो"            "$(grep -c 'v7 STICK दैनंदिन अहवाल' "$T/daily1")" "1"
  ck "daily मध्ये जिवंत ओळ"   "$(grep -c '💓 जिवंत' "$T/daily1")" "1"
  ck "daily मध्ये पुढचा scan" "$(grep -c '⏰ पुढचा scan' "$T/daily1")" "1"

  # ---- journal रिकामा ठेवल्यास (heartbeat नाही + scan नाही) restart चा इशारा ----
  #     वेळ 06:56 IST ठेवली — म्हणजे रोजच्या अहवालाची खिडकी लागू नये
  STRIKE_ENV="V7_DIR=$T V7_JOURNAL_FILE=$T/empty V7_MON_STATE_DIR=$T/state3
V7_DRY=1 V7_FAKE_ACTIVE=active V7_FAKE_UPTIME=99999 V7_FAKE_RESTARTS=0
V7_NOW_EPOCH=1758850000 V7_RESTART_WAIT=0 V7_RESTART_CMD=true"
  env $STRIKE_ENV bash "$0" _strike_log >"$T/s1" 2>&1
  env $STRIKE_ENV bash "$0" _strike_log >"$T/s2" 2>&1

  ck "पहिली शंका थांबते"    "$(grep -c 'SHANKA' "$T/s1")" "1"
  ck "दुसऱ्यावेळी restart"   "$(grep -c 'TRAS' "$T/s2")" "1"
  ck "restart चा Telegram"   "$(grep -c 'ADKALA HOTA' "$T/s2")" "1"

  # ---- रोजचा अहवाल रोज एकदाच ----
  DAILY_ENV="V7_DIR=$T V7_JOURNAL_FILE=$T/journal V7_MON_STATE_DIR=$T/state4
V7_DRY=1 V7_FAKE_ACTIVE=active V7_FAKE_ENABLED=enabled V7_FAKE_UPTIME=7200
V7_FAKE_RESTARTS=1 V7_NOW_EPOCH=1758880000"
  env $DAILY_ENV bash "$0" _maybe_daily >"$T/md1" 2>&1
  env $DAILY_ENV bash "$0" _maybe_daily >"$T/md2" 2>&1

  ck "खिडकीत अहवाल जातो"     "$(grep -c 'दैनंदिन अहवाल' "$T/md1")" "1"
  ck "दुसऱ्यांदा जात नाही"    "$(grep -c 'दैनंदिन अहवाल' "$T/md2")" "0"
  ck "दुसऱ्यांदा 'adhich'    " "$(grep -c 'adhich pathvla' "$T/md2")" "1"

  rm -rf "$T"
  echo
  echo "================================================================"
  echo " निकाल : $PASS pass, $FAIL fail"
  echo "================================================================"
  [ "$FAIL" -eq 0 ]
}

# ============================================================
case "${1:-}" in
  check)  do_check ;;
  daily)  ist_today >"$DAILY_FLAG" 2>/dev/null; do_daily ;;
  test)   send_tg "🧪 v7 STICK MONITOR TEST

Majkur tech yet aahe - monitor barobar jodlela aahe. ✅
Seva: $(svc_active)
Pudhcha scan: $(next_scan_info)
Vela: $(ist_now)" ; log "TEST majkur pathvla" ;;
  selftest) do_selftest ;;
  # ---- चाचणीचे आतले आदेश (नेहमी वापरायचे नाहीत) ----
  _counts) echo "HEARTS=$(count_in 86400 'HEARTBEAT |')"
           echo "SCANS=$(count_in 86400 'Setup scan complete')"
           echo "SETUPS=$(count_in 86400 'SETUP REGISTERED:')"
           echo "DELIV=$(count_in 86400 'ALERT DELIVERED')"
           echo "LAST=$(last_in 86400 'ALERT DELIVERED' | sed 's/^✅ *//; s/^ALERT DELIVERED: *//')" ;;
  _maybe_daily) SOD=$(sod_ist)
           if [ "$SOD" -ge "$DAILY_WINDOW_SEC" ] && [ "$(cat "$DAILY_FLAG" 2>/dev/null)" != "$(ist_today)" ]; then
             ist_today >"$DAILY_FLAG"; do_daily
           else
             echo "ajun vel nahi / adhich pathvla"
           fi ;;
  _strike_log) : >"$LOG_FILE"
           V7_LOG_QUIET=1; export V7_LOG_QUIET
           do_check; cat "$LOG_FILE" ;;
  *) echo "Use: $0  check | daily | test | selftest" ; exit 2 ;;
esac

