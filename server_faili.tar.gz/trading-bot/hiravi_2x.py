#!/usr/bin/env python3
# ============================================================
#  HIRAVI 2x — NAVIN NIYAM : "hiravi + 80% close + 2x unchi"
#  maagchya 30 divsांcha data
#
#  ⚠️ HA SCANNER NAHI — fakt ABHYAS.
#       • live_scanner.py la haat nahi lavat (fakt tyachе helper vaparतो)
#       • kाहich deploy hot nahi, Telegram/alerts kाहich nahi
#       • nava scanner tayar hot nahi
#
#  NIYAM (yuzar ne sangitlya pramाणे) :
#     ekाच final meणbatti madhe DON meणbattya :
#       1ली  : HIRAVI (band > udghad)  aani  close = unchi chya 80%+ var
#       2री  : HIRAVI (band > udghad)  aani  close = unchi chya 80%+ var
#       aaणि  2री chi UNCHI (high-low) >= 2.00 x 1ली chi unchi
#              (2.2x / 2.5x / 3x / 4x / 5x — kiti-hi mota chalta)
#
#     donhi meणbattya EKाच final meणbatti madhe :
#        2h + 2h  =  4h        ⬅ सधा फक्त हेच
#
#     (kडा = 05:30 IST — scanner sारखाच; june niyamांvar kाहich parिणाम nahi)
#
#  chaalava :
#      ./venv/bin/python hiravi_2x.py --selftest
#      ./venv/bin/python hiravi_2x.py --days 5 --symbols 100      # ozat chaanणी
#      ./venv/bin/python hiravi_2x.py --days 30                   # purna 30 divas
#      ./venv/bin/python hiravi_2x.py --days 30 --min-pat 2.5     # kаटक niyam
#      ./venv/bin/python hiravi_2x.py --days 30 --close-min 0.70  # sowal niyam
# ============================================================

import argparse
import csv
import importlib.util
import os
import sys
import time

SCANNER_FILES = ["live_scanner.py", "live_scanner_v7_stick.py"]

# final timeframe -> component (ardhya) chे minute
TIMEFRAMES = {
    "30m": 15,
    "1h": 30,
    "2h": 60,
    "4h": 120,
    "8h": 240,
    "1d": 720,
}

# SADYA fakt 2h + 2h = 4h  (itar paryay --tf ne ghetat, sadyacha niyam nahi)
DEFAULT_TF = "4h"

MIN_RATIO = 2.00          # 2री unchi >= 2.00 x 1ली unchi
CLOSE_MIN = 0.80          # close = unchi chya 80%+ var

PASS = 0
FAIL = 0

_last = [0.0]


# ============================================================
# SCANNER MODULE (fakt helper sathi)
# ============================================================

def load_scanner(path=None):

    if path is None:
        for f in SCANNER_FILES:
            if os.path.isfile(f):
                path = f
                break

    if path is None:
        print("❌ live_scanner.py sapadli nahi — tya folder madhून chaalava.")
        sys.exit(2)

    spec = importlib.util.spec_from_file_location("live_scanner_mod", path)

    mod = importlib.util.module_from_spec(spec)

    spec.loader.exec_module(mod)

    return mod, path


# ============================================================
# MEणBATTYA — maagchya N divsांचi 15m
# ============================================================

def fetch_15m(ls, symbol, start_ms, end_ms, gap):

    """15m meणbattya — aavashyak तेवढ्या (1000 chi limit paginate kаरून)."""

    out = []
    seen = set()

    cursor = int(start_ms)

    while cursor < end_ms:

        for attempt in range(4):

            wait = gap - (time.time() - _last[0])
            if wait > 0:
                time.sleep(wait)
            _last[0] = time.time()

            try:

                r = ls.get_session().get(
                    f"{ls.BINANCE_BASE}/fapi/v1/klines",
                    params={"symbol": symbol, "interval": "15m",
                            "startTime": cursor, "limit": 1000},
                    timeout=25,
                )

                if r.status_code in (429, 418):

                    print(f"   (rate limit — {20 * (attempt + 1)}s thambto…)",
                          flush=True)

                    time.sleep(20 * (attempt + 1))

                    continue

                r.raise_for_status()

                rows = r.json()

                break

            except Exception:

                if attempt == 3:
                    raise

                time.sleep(2 * (attempt + 1))

        else:

            break

        if not rows:
            break

        current = ls.now_ms()

        for k in rows:

            open_time = int(k[0])

            if open_time in seen:
                continue

            seen.add(open_time)

            if int(k[6]) >= current:          # chaalu meणbatti sodun
                continue

            out.append({
                "open_time": open_time,
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "close_time": int(k[6]),
            })

        cursor = int(rows[-1][0]) + 15 * 60 * 1000

        if len(rows) < 1000:
            break

    out.sort(key=lambda c: c["open_time"])

    return out


# ============================================================
# NIYAM TAPAसणी
# ============================================================

def unchi(c):

    return c["high"] - c["low"]


def hiravi(c):

    return c["close"] > c["open"]


def find_matches(ls, symbol, candles, win_start, win_end, timeframes,
                 min_ratio, close_min):

    """ek symbol sathi sगळे matches (sगळ्या timeframe madhe)."""

    matches = []

    for label, comp_min in timeframes.items():

        final_min = comp_min * 2

        comps = ls.aggregate_candles(candles, comp_min)
        finals = ls.aggregate_candles(candles, final_min)

        if not comps or not finals:
            continue

        comp_ms = comp_min * 60 * 1000
        final_ms = final_min * 60 * 1000

        index = {c["open_time"]: c for c in comps}

        for fc in finals:

            f_start = fc["open_time"]
            f_end = f_start + final_ms

            # jun्या / pudhchya kaलावधीtale sodun टाका
            if f_end > win_end or f_start < win_start:
                continue

            parts = sorted(
                [c for c in comps if f_start <= c["open_time"] < f_end],
                key=lambda x: x["open_time"],
            )

            if len(parts) != 2:
                continue

            first, second = parts

            r1 = unchi(first)
            r2 = unchi(second)

            if r1 <= 0 or r2 <= 0:
                continue                    # unchi zero -> niyam lagu hot nahi

            if not hiravi(first) or not hiravi(second):
                continue

            p1 = ls.close_position(first)
            p2 = ls.close_position(second)

            if p1 is None or p2 is None:
                continue

            if p1 < close_min - 1e-12 or p2 < close_min - 1e-12:
                continue

            if r2 < min_ratio * r1 - 1e-12:
                continue

            matches.append({
                "symbol": symbol,
                "timeframe": label,
                "final_open_time": f_start,
                "final_close_time": f_end - 1,
                # niyam poorण zhाला = 2री component band zhाली tya veles
                "tayar_ms": second["close_time"],
                "first": first,
                "second": second,
                "range1": r1,
                "range2": r2,
                "pat": r2 / r1,
                "pos1": p1,
                "pos2": p2,
                "final": fc,
            })

    return matches


# ============================================================
# AHAVAL
# ============================================================

def report(ls, args):

    days = args.days

    now = ls.now_ms()

    win_end = now
    win_start = now - days * 24 * 60 * 60 * 1000

    # 1d sathi sगळा divas laagto -> 8 divsांchi jasta cushion gheto
    fetch_start = win_start - 2 * 24 * 60 * 60 * 1000
    fetch_start = fetch_start // (15 * 60 * 1000) * (15 * 60 * 1000)

    timeframes = {k: TIMEFRAMES[k] for k in args.tf}

    print("=" * 82)
    print(" HIRAVI 2x — NAVIN NIYAM : 'hiravi + 80% close + 2x unchi'")
    print("=" * 82)
    print(" ⚠️  ha scanner NAHI — kाहich badalat nahi, kाहich deploy hot nahi.")
    print()
    print(" NIYAM :")
    print(f"   • 1ली meणbatti : HIRAVI  aani  close = unchi chya {args.close_min * 100:.0f}%+ var")
    print(f"   • 2री meणbatti : HIRAVI  aani  close = unchi chya {args.close_min * 100:.0f}%+ var")
    print(f"   • 2री chi unchi >= {args.min_pat:.2f} x 1ली chi unchi")
    print("   • donhi EKाच final meणbatti madhe : "
          + " · ".join(f"{k}" for k in timeframes))
    print()
    print(f" kaalावधी : {ls.format_ist(win_start)}  te  {ls.format_ist(win_end)}"
          f"   ({days:g} divas)")
    print()

    symbols = sorted(ls.fetch_active_symbols())

    if args.symbols:
        symbols = symbols[:args.symbols]

    need = int((now - fetch_start) / (15 * 60 * 1000))
    calls = (need // 1000) + 1

    print(f" symbols : {len(symbols)}   |   {need} meणbattya/symbol"
          f"   |   ~{calls} requests/symbol")
    sec_lo = len(symbols) * calls * args.gap
    sec_hi = len(symbols) * calls * (args.gap + 0.25)

    if sec_hi < 120:
        est = f"{sec_lo:.0f}-{sec_hi:.0f} sekand"
    else:
        est = f"{sec_lo / 60:.0f}-{sec_hi / 60:.0f} mint"

    print(f" ⏱️  अंदाज : {est}")
    print()
    print(" meणbattya yet aahеt … (thoda vela lagto, थांबा)")
    print()

    matches = []
    errors = 0
    empty = 0

    for i, symbol in enumerate(symbols, 1):

        try:

            candles = fetch_15m(ls, symbol, fetch_start, now, args.gap)

            if len(candles) < 40:
                empty += 1
            else:
                matches.extend(find_matches(ls, symbol, candles, win_start, win_end,
                                            timeframes, args.min_pat, args.close_min))

        except Exception:
            errors += 1

        if i % 25 == 0 or i == len(symbols):

            print(f"   … {i}/{len(symbols)}   (matches: {len(matches)})", flush=True)

    matches.sort(key=lambda m: m["tayar_ms"])

    print()
    print("=" * 82)
    print(" [1] सारांश")
    print("=" * 82)

    pairs = sorted({m["symbol"] for m in matches})
    tf_hit = sorted({m["timeframe"] for m in matches},
                    key=lambda t: [k for k in timeframes].index(t))

    print(f"  एकूण matches       : {len(matches)}")
    print(f"  वेगवेगळे pairs      : {len(pairs)}")
    print(f"  timeframes         : {', '.join(tf_hit) if tf_hit else '—'}")
    print(f"  दिवस               : {days:g}")

    if matches:

        by_ms = sorted(matches, key=lambda m: m["tayar_ms"])
        days_hit = {ls.format_ist(m["tayar_ms"])[:10] for m in by_ms}

        print(f"  ज्या दिवशी झाली     : {len(days_hit)} दिवस (पैकी "
              f"{ls.format_ist(by_ms[0]['tayar_ms'])[:10]} ते "
              f"{ls.format_ist(by_ms[-1]['tayar_ms'])[:10]})")

        pats = sorted(m["pat"] for m in matches)

        print(f"  पट (2री ÷ 1ली)     : कमी {pats[0]:.2f}x | मधला "
              f"{pats[len(pats) // 2]:.2f}x | जास्तीत जास्त {pats[-1]:.2f}x")

    if empty:
        print(f"  (नवीन/लहान pairs — data कमी : {empty})")

    if not matches:
        print()
        print("  ⚠️ ya niyamांनी ekहI match nahi.  niyam sowal kаरून pahा :")
        print("     --min-pat 1.5   kiva   --close-min 0.70")
        return

    # ---- timeframe निहाय ----
    print()
    print("=" * 82)
    print(" [2] TIMEFRAME निहाय")
    print("=" * 82)
    print("  timeframe | matches | pairs | पट (कमी - जास्त)")
    print("  ----------|---------|-------|----------------")

    for label in [k for k in timeframes if any(m["timeframe"] == k for m in matches)]:

        lst = [m for m in matches if m["timeframe"] == label]

        ps = sorted(m["pat"] for m in lst)

        print(f"  {label:<9} | {len(lst):>7} | {len({m['symbol'] for m in lst}):>5} |"
              f" {ps[0]:.2f}x - {ps[-1]:.2f}x")

    # ---- pairs निहाय ----
    print()
    print("=" * 82)
    print(f" [3] KONTYA PAIRS MADHE  (top {args.top})")
    print("=" * 82)

    per_pair = {}

    for m in matches:
        per_pair.setdefault(m["symbol"], []).append(m)

    ranked = sorted(per_pair.items(), key=lambda kv: (-len(kv[1]), kv[0]))

    print("     #   symbol           matches | timeframes      | सर्वात मोठा पट | शेवटची वेळ")
    print("     ----|------------------|---------|-----------------|----------------|------------")

    for i, (sym, lst) in enumerate(ranked[: args.top], 1):

        tfs = ",".join(sorted({m["timeframe"] for m in lst},
                              key=lambda t: [k for k in timeframes].index(t)))
        best = max(m["pat"] for m in lst)
        last = max(m["tayar_ms"] for m in lst)

        print(f"     {i:>3} | {sym:<16} | {len(lst):>7} | {tfs:<15} |"
              f" {best:>13.2f}x | {ls.format_ist(last)[:16]}")

    if len(ranked) > args.top:
        print(f"     … ajun {len(ranked) - args.top} pairs — CSV madhe")

    # ---- पट वाटप ----
    print()
    print("=" * 82)
    print(" [4] पट वाटप (2री chi unchi ÷ 1ली chi unchi)")
    print("=" * 82)

    bands = [(2.0, 2.2), (2.2, 2.5), (2.5, 3.0), (3.0, 4.0), (4.0, 5.0), (5.0, 1e9)]

    print("     पट            | matches | टक्के")
    print("     --------------|---------|------")

    for lo, hi in bands:

        n = sum(1 for m in matches if lo - 1e-12 <= m["pat"] < hi)

        label = f"{lo:.1f}x - {hi:.1f}x" if hi < 1e8 else f"{lo:.1f}x +"

        print(f"     {label:<13} | {n:>7} | {n / len(matches) * 100:5.1f}%")

    # ---- दिवस निहाय ----
    print()
    print("=" * 82)
    print(" [5] DIVAS निहाय")
    print("=" * 82)

    per_day = {}

    for m in matches:
        per_day.setdefault(ls.format_ist(m["tayar_ms"])[:10], []).append(m)

    print("     दिवस       | matches | pairs | सर्वाधिक पट")
    print("     -----------|---------|-------|-------------")

    for day in sorted(per_day, reverse=True):

        lst = per_day[day]

        print(f"     {day} | {len(lst):>7} | {len({m['symbol'] for m in lst}):>5} |"
              f" {max(m['pat'] for m in lst):>11.2f}x")

    # ---- यादी ----
    print()
    print("=" * 82)
    print(f" [6] YADI — konti vela, kona pair  (top {args.top})")
    print("=" * 82)

    print("     #  कधी (IST)          | symbol        | tf  | 1ली unchi | 2री unchi | पट     |"
          " 1ली close | 2री close")

    shown = matches if args.all else matches[: args.top]

    for i, m in enumerate(shown, 1):

        print(f"     {i:>3} {ls.format_ist(m['tayar_ms'])[:16]} | {m['symbol']:<13} |"
              f" {m['timeframe']:<3} | {m['range1']:>9.6g} | {m['range2']:>9.6g} |"
              f" {m['pat']:>6.2f}x | {m['pos1'] * 100:>7.1f}% | {m['pos2'] * 100:>6.1f}%")

    if not args.all and len(matches) > args.top:
        print(f"     … ajun {len(matches) - args.top} — CSV madhe (--all dya tar ithे pण)")

    # ---- CSV ----
    if args.csv:

        with open(args.csv, "w", newline="", encoding="utf-8-sig") as f:

            w = csv.writer(f)

            w.writerow([
                "kadhi_ist", "symbol", "timeframe",
                "1li_range", "2ri_range", "pat",
                "1li_open", "1li_high", "1li_low", "1li_close", "1li_close_jaga",
                "2ri_open", "2ri_high", "2ri_low", "2ri_close", "2ri_close_jaga",
                "final_open", "final_high", "final_low", "final_close",
            ])

            for m in matches:

                a, b, fin = m["first"], m["second"], m["final"]

                w.writerow([
                    ls.format_ist(m["tayar_ms"]), m["symbol"], m["timeframe"],
                    f"{m['range1']:.8f}", f"{m['range2']:.8f}", f"{m['pat']:.3f}",
                    f"{a['open']:.8f}", f"{a['high']:.8f}", f"{a['low']:.8f}",
                    f"{a['close']:.8f}", f"{m['pos1']:.3f}",
                    f"{b['open']:.8f}", f"{b['high']:.8f}", f"{b['low']:.8f}",
                    f"{b['close']:.8f}", f"{m['pos2']:.3f}",
                    f"{fin['open']:.8f}", f"{fin['high']:.8f}", f"{fin['low']:.8f}",
                    f"{fin['close']:.8f}",
                ])

        print()
        print(f" 📄 CSV tayar : {args.csv}   ({len(matches)} oळi)")

    if errors:
        print()
        print(f" ⚠️ {errors} symbols var error aaला (te sodle)")

    print()
    print("=" * 82)
    print(" MAHATVACHE")
    print("=" * 82)
    print("  • ha FKT abhyas — sadyacha scanner, niyam, server kाहich badalat nahi.")
    print("  • 'कधी' = 2री meणbatti band zhालi tya kshaणी (niyam poorण zhाला).")
    print("  • sadya fakt 2h + 2h = 4h heच pahile jaते.")
    print("  • 'close' chya 80% = meणbatti chya unchi chya 80% var band (varच्या 20% bhagात).")
    print("  • खरी kinnat 2 sekанdarला tapasली jate; ithे meणbattी varun — aakडे hubehu.")
    print("=" * 82)


# ============================================================
# SWATAHCHI CHAचणी (network nahit)
# ============================================================

def selftest(ls):

    global PASS, FAIL

    def check(name, cond, extra=""):
        global PASS, FAIL
        if cond:
            PASS += 1
            print(f"  ✅ {name}" + (f"   {extra}" if extra else ""))
        else:
            FAIL += 1
            print(f"  ❌ {name}" + (f"   {extra}" if extra else ""))

    print("=" * 72)
    print(" SWATAHCHI CHAचणी — network vaparat nahi")
    print("=" * 72)

    B = ls.BASE_INTERVAL_MS

    # 1 DIVAS sariवर — m्हणजे 15m/30m/1h/2h/4h sगळे khaंड purna basतात
    t0 = 1_700_000_000_000 // (24 * 60 * 60 * 1000) * (24 * 60 * 60 * 1000)

    def c15(start, o, h, l, c):
        return {"open_time": start, "open": o, "high": h, "low": l, "close": c,
                "close_time": start + B - 1}

    def make(range1, pos1, range2, pos2, up2=True, up1=True):
        """1h = 2 x 30m ; pratyek 30m = 2 x 15m.  (o=100 varun banवतो)"""

        o1 = 100.0

        if up1:
            h1, l1 = o1 + range1, o1
            c1 = o1 + range1 * pos1
        else:
            h1, l1 = o1, o1 - range1
            c1 = l1 + range1 * pos1

        o2 = c1

        if up2:
            h2, l2 = o2 + range2, o2
            c2 = o2 + range2 * pos2
        else:
            h2, l2 = o2, o2 - range2
            c2 = l2 + range2 * pos2

        return [
            c15(t0 + 0 * B, o1, o1 + range1, o1, o1),          # pahili ardhi sapाट
            c15(t0 + 1 * B, o1, h1, l1, c1),                    # 1ली 30m purna
            c15(t0 + 2 * B, o2, o2, o2, o2),                    # dusरी ardhi sapाट
            c15(t0 + 3 * B, o2, h2, l2, c2),                    # 2री 30m purna
        ]

    win_start = t0
    win_end = t0 + 10 * 60 * 60 * 1000

    TF1 = {"1h": 30}

    # ---- 1) adgadi 2.00x -> chalतो ----
    m = find_matches(ls, "T1", make(1.0, 0.80, 2.0, 1.00), win_start, win_end,
                     TF1, 2.0, 0.80)

    check("1) 2.00x (agadi) -> match zhala", len(m) == 1, f"{len(m)}")

    if m:

        check("   pat = 2.00x", abs(m[0]["pat"] - 2.00) < 1e-9, f"{m[0]['pat']:.3f}x")
        check("   donhi close_jaga 80%+",
              m[0]["pos1"] >= 0.80 - 1e-9 and m[0]["pos2"] >= 0.80 - 1e-9,
              f"{m[0]['pos1'] * 100:.1f}% / {m[0]['pos2'] * 100:.1f}%")
        check("   1ली unchi = 1, 2री unchi = 2",
              abs(m[0]["range1"] - 1.0) < 1e-9 and abs(m[0]["range2"] - 2.0) < 1e-9)

    # ---- 2) 1.99x -> nahi ----
    m2 = find_matches(ls, "T2", make(1.0, 0.80, 1.98, 1.00), win_start, win_end,
                      TF1, 2.0, 0.80)
    check("2) 1.98x -> match nahi (2x peksha kami)", len(m2) == 0, f"{len(m2)}")

    # ---- 3) 2री close 75% -> nahi ----
    m3 = find_matches(ls, "T3", make(1.0, 0.80, 2.0, 0.75, up2=True), win_start, win_end,
                      TF1, 2.0, 0.80)
    check("3) 2री close 75% -> match nahi", len(m3) == 0, f"{len(m3)}")

    # ---- 4) 1ली close 75% -> nahi ----
    m4 = find_matches(ls, "T4", make(1.0, 0.75, 2.0, 1.00), win_start, win_end,
                      TF1, 2.0, 0.80)
    check("4) 1ली close 75% -> match nahi", len(m4) == 0, f"{len(m4)}")

    # ---- 5) laal meणbatti -> nahi (2री laal) ----
    m5 = find_matches(ls, "T5", make(1.0, 0.80, 2.0, 0.80, up2=False), win_start, win_end,
                      TF1, 2.0, 0.80)
    check("5) 2री LAAL -> match nahi", len(m5) == 0, f"{len(m5)}")

    # ---- 6) 5x pण chalta ----
    m6 = find_matches(ls, "T6", make(1.0, 0.80, 5.0, 1.00), win_start, win_end,
                      TF1, 2.0, 0.80)
    check("6) 5.00x -> match zhala (kiti-hi mota chalta)",
          len(m6) == 1 and abs(m6[0]["pat"] - 5.0) < 1e-9)

    # ---- 7) 30m final (15m + 15m) ----
    # pahili 15m : unchi 1, close 80% ; dusरी 15m : unchi 2, close 100%
    data30 = [
        c15(t0 + 0 * B, 100.0, 101.0, 100.0, 100.8),
        c15(t0 + 1 * B, 100.8, 102.8, 100.8, 102.8),
    ]

    m7 = find_matches(ls, "T7", data30, win_start, win_end, {"30m": 15}, 2.0, 0.80)

    check("7) 15m + 15m = 30m -> match zhala",
          len(m7) == 1 and abs(m7[0]["pat"] - 2.0) < 1e-9,
          f"{len(m7)}")

    # ---- 8) unchi zero -> crash nahi, match nahi ----
    zero = [
        c15(t0 + 0 * B, 100.0, 100.0, 100.0, 100.0),
        c15(t0 + 1 * B, 100.0, 102.0, 100.0, 102.0),
    ]

    try:
        m8 = find_matches(ls, "T8", zero, win_start, win_end, {"30m": 15}, 2.0, 0.80)
        ok8 = (len(m8) == 0)
    except Exception:
        ok8 = False

    check("8) unchi zero asलेli meणbatti -> crash nahi, match nahi", ok8)

    # ---- 9) sowal niyam (close 70%, pat 1.5x) -> chalta ----
    m9 = find_matches(ls, "T9", make(1.0, 0.72, 1.6, 0.75), win_start, win_end,
                      TF1, 1.5, 0.70)
    check("9) sowal niyam (1.5x / 70%) -> match zhala", len(m9) == 1, f"{len(m9)}")

    # ---- 10) 2h + 2h = 4h ----
    def c2h(start, range_, pos):
        """2h component = 8 x 15m (pehले 7 sapाट, shevatचa body)."""
        out = [c15(start + i * B, 100.0, 100.0, 100.0, 100.0) for i in range(7)]
        out.append(c15(start + 7 * B, 100.0, 100.0 + range_, 100.0,
                       100.0 + range_ * pos))
        return out

    data4h = (c2h(t0, 1.0, 0.85) + c2h(t0 + 2 * 60 * 60 * 1000, 2.5, 0.90))

    m10 = find_matches(ls, "T10", data4h, win_start, win_end, {"4h": 120}, 2.0, 0.80)

    check("10) 2h + 2h = 4h -> match zhala (pat 2.50x)",
          len(m10) == 1 and abs(m10[0]["pat"] - 2.5) < 1e-9, f"{len(m10)}")

    check("    donhi close_jaga 80%+",
          len(m10) == 1 and m10[0]["pos1"] >= 0.80 - 1e-9
          and m10[0]["pos2"] >= 0.80 - 1e-9,
          f"{m10[0]['pos1'] * 100:.1f}% / {m10[0]['pos2'] * 100:.1f}%" if m10 else "-")

    # ---- 11) sगळे timeframe che aakडे nIट + default = 4h ----
    check("11) TIMEFRAMES madhe 6 paryay aahet", len(TIMEFRAMES) == 6,
          ",".join(TIMEFRAMES))

    check("    sadyaचा default = 4h (2h + 2h)  aani 4h = 120 min",
          DEFAULT_TF == "4h" and TIMEFRAMES["4h"] == 120,
          f"{DEFAULT_TF} = {TIMEFRAMES['4h']} min")

    check("    (aakडे) 15+15=30m, 30+30=1h, 1h+1h=2h, 2h+2h=4h, 4h+4h=8h, 12h+12h=1d",
          TIMEFRAMES == {"30m": 15, "1h": 30, "2h": 60, "4h": 120, "8h": 240, "1d": 720})

    print()
    print("=" * 72)
    print(f" निकाल : {PASS} pass, {FAIL} fail")
    print("=" * 72)

    return 0 if FAIL == 0 else 1


# ============================================================
# MAIN
# ============================================================

def main():

    ap = argparse.ArgumentParser(
        description="hiravi + 80% close + 2x unchi  — maagchya N divsांcha abhyas")

    ap.add_argument("--days", type=float, default=30.0, help="kiti divas (default 30)")
    ap.add_argument("--symbols", type=int, default=0, help="fakt pahlे itke symbols")
    ap.add_argument("--min-pat", type=float, default=MIN_RATIO,
                    help="2री unchi >= itke x 1ली unchi (default 2.0)")
    ap.add_argument("--close-min", type=float, default=CLOSE_MIN,
                    help="close = unchi chya itke% var (default 0.80)")
    ap.add_argument("--tf", default=DEFAULT_TF,
                    help=f"sadya fakt {DEFAULT_TF} (2h+2h=4h). itar : 30m,1h,2h,8h,1d")
    ap.add_argument("--top", type=int, default=30)
    ap.add_argument("--all", action="store_true", help="sagली yadi s्क्रीनवar")
    ap.add_argument("--gap", type=float, default=0.20,
                    help="requests madhla antar (sekand) — rate limit sathi")
    ap.add_argument("--csv", default="")
    ap.add_argument("--selftest", action="store_true")

    args = ap.parse_args()

    # --tf तपासणी
    wanted = [t.strip() for t in args.tf.split(",") if t.strip()]

    bad = [t for t in wanted if t not in TIMEFRAMES]

    if bad:
        print(f"❌ he timeframe mahit nahit : {', '.join(bad)}")
        print(f"   shakya : {', '.join(TIMEFRAMES)}")
        sys.exit(2)

    args.tf = wanted

    ls, path = load_scanner()

    print(f" scanner file : {path}   (fakt helper sathi — niyam ithेच lihilе aahet)")
    print()

    if args.selftest:
        sys.exit(selftest(ls))

    if not args.csv:
        args.csv = f"hiravi_2x_{args.days:g}din.csv"

    try:
        report(ls, args)
    except KeyboardInterrupt:
        print("\n (tumhi थांबवले)")


if __name__ == "__main__":
    main()
