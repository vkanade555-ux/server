#!/usr/bin/env python3
# ============================================================
#  v7 STICK — MAGIL N DIVSANCHA AHWAL   (30 divas default)
# ============================================================
#
#  HE NIYAM VAPARTO (live_scanner_v7_stick.py madhले tech — chek_three
#  sarkhe scanner chi functionच vaprali jaate, mhanun niyam badalalе tar
#  ha abhyas pan aapoaap badalato) :
#
#    Scanner 1 (Bearish Reversal) : 1ली हिरवी body ≥ 50% | 2री लाल | 2री 1लीच्या आत
#                                   | final close ≤ 50%
#    Scanner 2 (Bullish Reversal) : 1ली लाल body ≥ 50% | 2री हिरवी | 2री 1लीच्या आत
#                                   | final close ≥ 50%
#    Scanner 3 (Bearish, high break) : 1ली हिरवी | 2री लाल | 2रीचा high > 1लीचा high
#                                   | final close ≤ 50%
#    Scanner 4 (Bullish, low break)  : 1ली लाल | 2री हिरवी | 2रीचा low < 1लीचा low
#                                   | final close ≥ 50%
#    चौघांना : खांबाचा नियम (उलट दिशा + |खांब 2| ≥ 3.00 × |खांब 1|)
#
#  ⚡ ALERT ची हद्द — DONI PADDHATI SHI TULNA :
#    OLD (2री-बदलाच्या आधी) : final (1ली+2री EKATRA) meणbatti cha low/high tutlyavar
#    NEW (26-09 पासून)        : 2ऱ्या (shevatchya) component meणbatti cha low/high tutlyavar
#    (doni chi aakडे ahwalat shi dाखवली jaतात — nirnay sopalо hoईल)
#
#  KAाहीच PATHवत NAHI · KAाहीच BADALAT NAHI · scanner la haat nahi
#  (fakt data vaachto aani ahwal + CSV tayaar karto; chalू scanner la kाहीच hot nahi)
#
#  CHALAVA (sarvharvar — Binance API ithe chalat nahi) :
#    ./venv/bin/python v7_30din.py --selftest          # chaanणी (network nahit)
#    ./venv/bin/python v7_30din.py                     # magil 30 divas (sगळे pairs)
#    ./venv/bin/python v7_30din.py --days 60           # magil 60 divas
#    ./venv/bin/python v7_30din.py --limit 40          # pahilya 40 pairs (jhalд)
#    ./venv/bin/python v7_30din.py --csv               # + CSV file
#    ./venv/bin/python v7_30din.py --symbol BTCUSDT    # fakt ek pair
# ============================================================

import argparse
import csv
import sys
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone

# ---- scanner chi फाइल कोणत्या नावानं आहे ते शोधून घेतो ----
#      (सर्व्हरवर नाव "live_scanner.py" असतं, इथे "live_scanner_v7_stick.py")
v7 = None

for _nom in ("live_scanner_v7_stick", "live_scanner"):

    try:
        v7 = __import__(_nom)
        SCANNER_FILE = _nom
        break
    except ImportError:
        continue

if v7 is None:
    print("DHOKA: scanner chi file saapadli nahi "
          "(live_scanner_v7_stick.py / live_scanner.py yaach jaagi taka)")
    raise SystemExit(1)

# ---- tya file madhye havi asलेले भाग आहेत का ते तपासतो ----
NEEDED = ("aggregate_candles", "scanner_result", "momentum_sticks", "momentum_ratio",
          "candle_body_ratio", "fetch_active_symbols", "now_ms", "refresh_time_offset",
          "get_session", "BODY_THRESHOLD", "CLOSE_LOW_THRESHOLD", "CLOSE_HIGH_THRESHOLD",
          "MOMENTUM_MULTIPLIER", "TIMEFRAMES", "BINANCE_BASE")

MISSING = [n for n in NEEDED if not hasattr(v7, n)]

if MISSING:
    print("DHOKA: scanner madhe ya goshti saapadlya nahit : " + ", ".join(MISSING))
    raise SystemExit(1)

MIN15_MS = 15 * 60 * 1000
HOUR_MS = 60 * 60 * 1000
DAY_MS = 24 * HOUR_MS
IST = timezone(timedelta(hours=5, minutes=30))

TIMEFRAMES = ["1h", "2h", "4h", "8h"]

OLD = "final"      # 2री-chya badalachya AADHI chi paddhat
NEW = "second"     # 26-09 pasun chi paddhat

CSV_FILE = "v7_30din.csv"


# ============================================================
# VEL / SWARUP
# ============================================================

def ist_str(ms):
    return datetime.fromtimestamp(ms / 1000, IST).strftime("%d-%m-%Y %H:%M")


def hhmm_ist(ms):
    return datetime.fromtimestamp(ms / 1000, IST).strftime("%H:%M")


def ist_date(ms):
    return datetime.fromtimestamp(ms / 1000, IST).strftime("%d-%m-%Y")


# ============================================================
# DATA (15m meणbattya — pagination)
# ============================================================

def fetch_15m(symbol, days, now_ms, session=None):
    """magil 'days' divasanchya 15m meणbattya (chालू meणbatti sodun)."""

    sess = session or v7.get_session()

    start = now_ms - days * DAY_MS
    start = (start // MIN15_MS) * MIN15_MS

    out = []
    cursor = start

    while cursor < now_ms:

        response = sess.get(
            f"{v7.BINANCE_BASE}/fapi/v1/klines",
            params={
                "symbol": symbol,
                "interval": "15m",
                "startTime": cursor,
                "limit": 1500,
            },
            timeout=20,
        )

        response.raise_for_status()

        rows = response.json()

        if not rows:
            break

        for k in rows:

            close_time = int(k[6])

            if close_time >= now_ms:      # chालू meणbatti nako
                continue

            out.append({
                "open_time": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "close_time": close_time,
            })

        last_open = int(rows[-1][0])

        if len(rows) < 1500:
            break

        cursor = last_open + MIN15_MS

    return out


def fetch_symbols(limit=None, only=None):

    if only:
        return [s.strip().upper() for s in only.split(",") if s.strip()]

    symbols = v7.fetch_active_symbols()

    if limit:
        symbols = symbols[:limit]

    return symbols


# ============================================================
# SCANNER NIYAM — tech function vaprun (chek_three sarkhe)
# ============================================================

def aggregate_for(base_candles, timeframe):
    """component (30m/1h/2h/4h) aani final (1h/2h/4h/8h) meणbattya."""

    comp_min = v7.TIMEFRAMES[timeframe]
    final_min = int(timeframe[:-1]) * 60

    comps = v7.aggregate_candles(base_candles, comp_min)
    fins = v7.aggregate_candles(base_candles, final_min)

    return comps, fins, comp_min, final_min


def trios(comps, fins, timeframe):
    """sगळ्या final meणbattyांवar scanner niyam tapasून setup tayaar karto."""

    final_min = int(timeframe[:-1]) * 60
    comp_min = v7.TIMEFRAMES[timeframe]

    index = {c["open_time"]: i for i, c in enumerate(comps)}

    out = []

    for fin in fins:

        fstart = fin["open_time"]
        fend = fstart + final_min * 60 * 1000

        parts = [c for c in comps if fstart <= c["open_time"] < fend]

        if len(parts) != 2:
            continue

        first, second = parts[0], parts[1]

        i = index.get(first["open_time"])

        previous = comps[i - 1] if (i is not None and i > 0) else None

        res = v7.scanner_result(first, second, fin, previous)

        if res is None:
            continue

        bearish = res["direction"].startswith("Bearish")

        out.append({
            "timeframe": timeframe,
            "scanner": res["scanner"],
            "direction": res["direction"],
            "bearish": bearish,
            "comp_min": comp_min,
            "final_min": final_min,
            "first": first,
            "second": second,
            "final": fin,
            "position": res["position"],
            "body1": v7.candle_body_ratio(first),
            "stick1": v7.momentum_sticks(previous, first, second)[0],
            "stick2": v7.momentum_sticks(previous, first, second)[1],
            "stick_ratio": v7.momentum_ratio(previous, first, second),
            # ---- ALERT chi hadd : doni paddhati ----
            "level_old": fin["low"] if bearish else fin["high"],
            "level_new": second["low"] if bearish else second["high"],
        })

    return out


# ============================================================
# ALERT KADHI ZHALA (doni haddi)
# ============================================================

def window_of(setup):
    """confirmation khidaki : final band zalyavar, component-lambiparyant."""

    wstart = setup["final"]["close_time"] + 1
    wend = wstart + setup["comp_min"] * 60 * 1000

    return wstart, wend


def simulate(setup, base_candles):
    """doni haddi sathi : kiti minitanni tutli te."""

    wstart, wend = window_of(setup)
    bearish = setup["bearish"]

    result = {}

    for key, level in (("old", setup["level_old"]), ("new", setup["level_new"])):

        hit = None

        for c in base_candles:

            if c["open_time"] < wstart:
                continue

            if c["open_time"] >= wend:
                break

            if bearish:
                if c["low"] < level:
                    hit = ("low", c)
                    break
            else:
                if c["high"] > level:
                    hit = ("high", c)
                    break

        if hit is None:
            result[key] = None
        else:
            side, c = hit
            result[key] = {
                "hit_ms": c["open_time"],
                "mins": int((c["open_time"] - wstart) // MIN15_MS) * 15,
                "price": level,
            }

    return result


def forward(base_candles, t0, price):
    """alert nantar +1h / +4h / +24h + 24h madhla uсhch aani sarvat kami."""

    def close_after(ms_off):

        target = t0 + ms_off

        for c in base_candles:
            if c["open_time"] <= target <= c["close_time"]:
                return c["close"]

        # tya veli chi candle nasel tar : target chya aadhi-chi shevatची candle
        before = None

        for c in base_candles:
            if c["close_time"] < target:
                before = c
            else:
                break

        if before is not None:
            return before["close"]

        for c in base_candles:
            if c["open_time"] > target:
                return c["close"]

        return None

    def pct(x):
        if x is None or not price:
            return None
        return (x - price) / price * 100.0

    hi = None
    lo = None

    for c in base_candles:

        if c["open_time"] < t0:
            continue

        if c["open_time"] >= t0 + 24 * HOUR_MS:
            break

        hi = c["high"] if hi is None else max(hi, c["high"])
        lo = c["low"] if lo is None else min(lo, c["low"])

    return {
        "chg_1h_pct": pct(close_after(HOUR_MS)),
        "chg_4h_pct": pct(close_after(4 * HOUR_MS)),
        "chg_24h_pct": pct(close_after(24 * HOUR_MS)),
        "max_up_24h_pct": pct(hi),
        "max_down_24h_pct": pct(lo),
    }


# ============================================================
# EK SYMBOL — purna tapaसणी
# ============================================================

def analyse(base_candles):
    """sगळ्या timeframes var setup shodhato (sadyachya niyamांनुसार)."""

    found = []

    for tf in TIMEFRAMES:

        comps, fins, comp_min, final_min = aggregate_for(base_candles, tf)

        if not comps or not fins:
            continue

        found.extend(trios(comps, fins, tf))

    return found


def symbol_worker(symbol, days, now_ms):

    base = fetch_15m(symbol, days, now_ms)

    if not base:
        return symbol, [], {}, 0

    setups = analyse(base)

    rows = []

    for setup in setups:

        hits = simulate(setup, base)

        row = {
            "symbol": symbol,
            "timeframe": setup["timeframe"],
            "scanner": setup["scanner"],
            "direction": setup["direction"],
            "final_ist": ist_str(setup["final"]["open_time"]),
            "day": ist_date(setup["final"]["open_time"]),
            "body1_pct": setup["body1"] * 100,
            "close_final_pct": setup["position"] * 100,
            "stick_ratio": setup["stick_ratio"],
            "level_old": setup["level_old"],
            "level_new": setup["level_new"],
            "hit_old": 1 if hits["old"] else 0,
            "hit_new": 1 if hits["new"] else 0,
            "mins_old": hits["old"]["mins"] if hits["old"] else None,
            "mins_new": hits["new"]["mins"] if hits["new"] else None,
            "alert_price": hits["old"]["price"] if hits["old"] else None,
        }

        if hits["old"]:
            row.update(forward(base, hits["old"]["hit_ms"], hits["old"]["price"]))
        else:
            row.update({
                "chg_1h_pct": None, "chg_4h_pct": None,
                "chg_24h_pct": None, "max_up_24h_pct": None,
                "max_down_24h_pct": None,
            })

        rows.append(row)

    # ---- वेगळ्या आकड्यांवर किती setups ? (what-if) ----
    variant_counts = {}

    saved = (v7.BODY_THRESHOLD, v7.CLOSE_LOW_THRESHOLD,
             v7.CLOSE_HIGH_THRESHOLD, v7.MOMENTUM_MULTIPLIER)

    try:

        for name, patch in VARIANTS:

            v7.BODY_THRESHOLD, v7.CLOSE_LOW_THRESHOLD, \
                v7.CLOSE_HIGH_THRESHOLD, v7.MOMENTUM_MULTIPLIER = saved

            for key, value in patch.items():
                setattr(v7, key, value)

            n = 0

            for tf in TIMEFRAMES:

                comps, fins, _cm, _fm = aggregate_for(base, tf)

                if comps and fins:
                    n += len(trios(comps, fins, tf))

            variant_counts[name] = n

    finally:

        v7.BODY_THRESHOLD, v7.CLOSE_LOW_THRESHOLD, \
            v7.CLOSE_HIGH_THRESHOLD, v7.MOMENTUM_MULTIPLIER = saved

    return symbol, rows, variant_counts, len(base)


VARIANTS = [
    ("आजचे नियम (body 50% · close 50/50 · खांब 3x)", {}),
    ("body 50% → 60%", {"BODY_THRESHOLD": 0.60}),
    ("body 50% → 40%", {"BODY_THRESHOLD": 0.40}),
    ("close 50/50 → 30/70 (कडक)", {"CLOSE_LOW_THRESHOLD": 0.30,
                                   "CLOSE_HIGH_THRESHOLD": 0.70}),
    ("close 50/50 → 40/60", {"CLOSE_LOW_THRESHOLD": 0.40,
                             "CLOSE_HIGH_THRESHOLD": 0.60}),
    ("close 50/50 → 60/40 (सोपे)", {"CLOSE_LOW_THRESHOLD": 0.60,
                                   "CLOSE_HIGH_THRESHOLD": 0.40}),
    ("खांब 3x → 2x", {"MOMENTUM_MULTIPLIER": 2.0}),
    ("खांब 3x → 4x", {"MOMENTUM_MULTIPLIER": 4.0}),
    ("खांब 3x → 5x", {"MOMENTUM_MULTIPLIER": 5.0}),
]


# ============================================================
# AHWAL
# ============================================================

def pct(part, whole):
    if not whole:
        return 0.0
    return part / whole * 100.0


def build_report(rows, variant_totals, symbols, scanned, errors, days, now_ms,
                 csv_name=None):

    lines = []

    def w(s=""):
        lines.append(s)

    total = len(rows)
    hit_old = sum(r["hit_old"] for r in rows)
    hit_new = sum(r["hit_new"] for r in rows)

    w("=" * 70)
    w(" v7 STICK — MAGIL %d DIVASANCHA AHWAL" % days)
    w(f" {scanned}/{symbols} pairs chi data  |  errors {errors}")
    w(f" {ist_str(now_ms - days * DAY_MS)}  te  {ist_str(now_ms)} (IST)")
    w("=" * 70)
    w()
    w("[1] EKUN NIKAL")
    w(f"   setups sapadले (sगळ्या timeframes)   : {total:>7,}")
    w(f"   ⚡ alert झाले — जुनी हद्द (final)     : {hit_old:>7,}   ({pct(hit_old, total):.1f}%)")
    w(f"   ⚡ alert झाले — नवी हद्द (2री)       : {hit_new:>7,}   ({pct(hit_new, total):.1f}%)")
    if hit_old:
        w(f"   नव्या हद्दीनं किती लवकर तुटले        : "
          f"{sum(1 for r in rows if r['hit_new'] and not r['hit_old']):>7,} "
          f"setups (juna hдд tutli nahi pan नवी tutli)")
        w(f"   सरासरी वेळ (minit) — जुनी हद्द       : "
          f"{sum(r['mins_old'] for r in rows if r['mins_old'] is not None) / max(hit_old, 1):.0f}")
        w(f"   सरासरी वेळ (minit) — नवी हद्द        : "
          f"{sum(r['mins_new'] for r in rows if r['mins_new'] is not None) / max(hit_new, 1):.0f}")
    w()

    # ---- [2] scanner wise ----
    w("[2] KONTA SCANNER")
    w(f"   {'scanner':<12}{'setups':>9}{'alert(juni)':>13}{'alert(navi)':>13}   disha")
    for name in ("Scanner 1", "Scanner 2", "Scanner 3", "Scanner 4"):
        sub = [r for r in rows if r["scanner"] == name]
        if not sub:
            continue
        dirn = "खाली" if sub[0]["direction"].startswith("Bearish") else "वर"
        w(f"   {name:<12}{len(sub):>9,}{sum(r['hit_old'] for r in sub):>13,}"
          f"{sum(r['hit_new'] for r in sub):>13,}   {dirn}")
    w()

    # ---- [3] timeframe wise ----
    w("[3] KONTA TIMEFRAME")
    w(f"   {'tf':<6}{'setups':>9}{'alert(juni)':>13}{'alert(navi)':>13}")
    for tf in TIMEFRAMES:
        sub = [r for r in rows if r["timeframe"] == tf]
        w(f"   {tf:<6}{len(sub):>9,}{sum(r['hit_old'] for r in sub):>13,}"
          f"{sum(r['hit_new'] for r in sub):>13,}")
    w()

    # ---- [4] divas wise ----
    w("[4] KONTA DIVAS (top 10 — junya hддne)")

    by_day = Counter()
    alerts_by_day = Counter()

    for r in rows:
        by_day[r["day"]] += 1
        if r["hit_old"]:
            alerts_by_day[r["day"]] += 1

    for day, n in alerts_by_day.most_common(10):
        w(f"   {day}   setups {by_day[day]:>4}   ⚡ alerts {n:>4}")
    w()

    # ---- [5] nantar kay zhala ----
    w("[5] NANTAR KAY ZHALA (fakt जुनी हद्द tutलेल्या alerts वर)")

    done = [r for r in rows if r["hit_old"] and r["chg_24h_pct"] is not None]

    if not done:
        w("   (एकही alert नाही — काहीच सांगता येत नाही)")
    else:
        def avg(key):
            vals = [r[key] for r in done if r[key] is not None]
            return sum(vals) / len(vals) if vals else 0.0

        up24 = sum(1 for r in done if r["chg_24h_pct"] > 0)

        w(f"   nantar tapatलेले alerts               : {len(done):,}")
        bearing = "खाली" if done[0]["direction"].startswith("Bearish") else "वर"

        w(f"   +1  तास nantar : सरासरी {avg('chg_1h_pct'):+.2f}%")
        w(f"   +4  तास nantar : सरासरी {avg('chg_4h_pct'):+.2f}%")
        w(f"   +24 तास nantar : सरासरी {avg('chg_24h_pct'):+.2f}%")
        w(f"   24 तासांत सर्वात जास्त वर : सरासरी {avg('max_up_24h_pct'):+.2f}%")
        w(f"   24 तासांत सर्वात जास्त खाली : सरासरी {avg('max_down_24h_pct'):+.2f}%")
        w(f"   24 तासांनी वर बंद झाले     : {up24}/{len(done)}  ({pct(up24, len(done)):.0f}%)")

        top = sorted(done, key=lambda r: -(r["max_up_24h_pct"] or -999))[:5]
        w("   सर्वात चांगले 5 (24 तासांतले वरचे टोक) :")
        for r in top:
            w(f"      {r['symbol']:<14} {r['timeframe']:<4} {r['scanner']:<10} "
              f"{r['final_ist']}  |  +1 तास {r['chg_1h_pct']:+.2f}%  "
              f"+24 तास {r['chg_24h_pct']:+.2f}%  |  टोक {r['max_up_24h_pct']:+.2f}%")
    w()

    # ---- [6] kay badalala tar kiti ----
    w("[6] KAY BADALAL TAR KITI SETUPS?   (niyam badalण्यासाठी आधार)")
    w()
    w(f"   {'पर्याय':<44}{'setups':>9}")
    base_n = variant_totals.get(VARIANTS[0][0], 0)
    for name, _patch in VARIANTS:
        n = variant_totals.get(name, 0)
        mark = "  ← आजचे" if name == VARIANTS[0][0] else ""
        diff = "" if not base_n else f"   ({n - base_n:+,})"
        w(f"   {name:<44}{n:>9,}{diff}{mark}")
    w()
    w("=" * 70)

    return "\n".join(lines)


def write_csv(name, rows):

    fields = ["symbol", "timeframe", "scanner", "direction", "final_ist", "day",
              "body1_pct", "close_final_pct", "stick_ratio",
              "level_old", "level_new", "hit_old", "hit_new", "mins_old", "mins_new",
              "alert_price", "chg_1h_pct", "chg_4h_pct", "chg_24h_pct",
              "max_up_24h_pct", "max_down_24h_pct"]

    with open(name, "w", newline="") as f:

        wr = csv.DictWriter(f, fieldnames=fields)

        wr.writeheader()

        for r in rows:

            out = {}

            for k in fields:

                val = r.get(k)

                if val is None:
                    out[k] = ""
                elif isinstance(val, float):
                    out[k] = f"{val:.4g}"
                else:
                    out[k] = val

            wr.writerow(out)


# ============================================================
# SWATAHCHI CHAचणी (network nahit)
# ============================================================

PASS = 0
FAIL = 0


def check(label, ok, extra=""):

    global PASS, FAIL

    if ok:
        PASS += 1
        print(f"  ✅ {label}" + (f"   {extra}" if extra else ""))
    else:
        FAIL += 1
        print(f"  ❌ {label}" + (f"   {extra}" if extra else ""))


def mk15(t, o, h, l, c):
    return {"open_time": t, "open": o, "high": h, "low": l, "close": c,
            "close_time": t + MIN15_MS - 1}


def comp_to_15m(t, o, h, l, c):
    """ek component (30m/1h...) meणbatti -> tiच्या don 15m tukडे (agg जसेच राहील)."""

    mid = (o + c) / 2.0

    return [mk15(t, o, h, l, mid), mk15(t + MIN15_MS, mid, h, l, c)]


def fixture():
    """1h timeframe sathi ek jhuणणारा setup (Scanner 1 — bearish)."""

    t0 = 1_700_000_000_000 // DAY_MS * DAY_MS + 4 * HOUR_MS    # 15m-aligned

    prev = comp_to_15m(t0 - 30 * 60 * 1000, 100.0, 101.95, 99.60, 101.90)   # m0 = +1.90
    first = comp_to_15m(t0, 100.0, 102.0, 98.0, 102.0)                      # m1 = +2.00
    second = comp_to_15m(t0 + 30 * 60 * 1000, 101.5, 101.9, 98.5, 99.0)     # m2 = -2.50
    win = [mk15(t0 + 60 * 60 * 1000, 99.5, 99.9, 98.4, 99.2),               # जुनी हद्द 98 ajun nahi
           mk15(t0 + 75 * 60 * 1000, 98.3, 98.6, 97.95, 98.2)]              # aata 98 khali
    # ---- nantar chya 15m meणbattya : +24 तास paryant ----
    #      (body लहान ठेवला — m्हणजे yaतून vеgळे setup honar nahit)
    after = []
    price = 98.2

    for i in range(92):                      # t0+90m pasun 24 तास paryant

        t = t0 + (90 + 15 * i) * 60 * 1000

        o = price
        c = o + (0.06 if i % 3 else -0.06)   # body = 0.12 / 0.42 = 29% < 50% ✗
        h = max(o, c) + 0.15
        l = min(o, c) - 0.15

        after.append(mk15(t, o, h, l, c))

        price = c

    return t0, prev + first + second + win + after


def self_test():

    print("=" * 70)
    print(" SWATAHCHI CHAचणी — network nahit, kाहich pathवत nahi")
    print("=" * 70)

    t0, base = fixture()

    # ---- [1] niyam tech aahet ka ----
    print()
    print("[1] NIYAM (scanner kadun tech)")
    check("body ≥ 50%", abs(v7.BODY_THRESHOLD - 0.50) < 1e-9, f"{v7.BODY_THRESHOLD}")
    check("close (खाली) ≤ 50%", abs(v7.CLOSE_LOW_THRESHOLD - 0.50) < 1e-9)
    check("close (वर) ≥ 50%", abs(v7.CLOSE_HIGH_THRESHOLD - 0.50) < 1e-9)
    check("खांब ≥ 3.00x", abs(v7.MOMENTUM_MULTIPLIER - 3.0) < 1e-9)

    # ---- [2] setup sapadla? ----
    print()
    print("[2] SETUP SHODHणी (fixture var)")

    setups = analyse(base)

    check("एक setup sapadla", len(setups) == 1, f"{len(setups)}")
    check("Scanner 1 (bearish)", setups and setups[0]["scanner"] == "Scanner 1",
          setups[0]["scanner"] if setups else "-")
    check("timeframe 1h", setups and setups[0]["timeframe"] == "1h")
    check("खांबाचा पट 3x पेक्षा जास्त",
          setups and setups[0]["stick_ratio"] and setups[0]["stick_ratio"] >= 3.0,
          f"{setups[0]['stick_ratio']:.2f}x" if setups else "-")

    s = setups[0]

    check("हद्द — जुनी (final cha low) = 98", abs(s["level_old"] - 98.0) < 1e-9,
          f"{s['level_old']:g}")
    check("हद्द — नवी (2री cha low)  = 98.5", abs(s["level_new"] - 98.5) < 1e-9,
          f"{s['level_new']:g}")

    # ---- [3] alert kadhi zhala ----
    print()
    print("[3] ALERT — DONI HADDI")

    hits = simulate(s, base)

    check("जुनी हद्द तुटली (alert झाला)", hits["old"] is not None)
    check("   जुनी : खिडकीच्या पहिल्या 15m मेणबत्तीतच",
          hits["old"] and hits["old"]["mins"] == 15,
          f"{hits['old']['mins']} min" if hits["old"] else "-")
    check("नवी हद्द तुटली (alert झाला)", hits["new"] is not None)
    check("   नवी : त्या खिडकीत लगेच (0 min)",
          hits["new"] and hits["new"]["mins"] == 0,
          f"{hits['new']['mins']} min" if hits["new"] else "-")
    check("नवी हद्द आधी तुटते (aadhi fakri)",
          hits["new"]["mins"] < hits["old"]["mins"])

    # ---- [4] nantar kay zhala ----
    print()
    print("[4] NANTAR KAY ZHALA")

    fw = forward(base, hits["old"]["hit_ms"], hits["old"]["price"])

    check("+1 तास cha aakडा aahe", fw["chg_1h_pct"] is not None,
          f"{fw['chg_1h_pct']:+.2f}%" if fw["chg_1h_pct"] is not None else "-")
    check("+4 तास cha aakडा aahe", fw["chg_4h_pct"] is not None,
          f"{fw['chg_4h_pct']:+.2f}%" if fw["chg_4h_pct"] is not None else "-")
    check("+24 तास cha aakडा aahe", fw["chg_24h_pct"] is not None,
          f"{fw['chg_24h_pct']:+.2f}%" if fw["chg_24h_pct"] is not None else "-")
    check("24 तासांतਲे uсhch aakडले", fw["max_up_24h_pct"] is not None,
          f"{fw['max_up_24h_pct']:+.2f}%" if fw["max_up_24h_pct"] is not None else "-")

    # ---- [5] what-if ----
    print()
    print("[5] WHAT-IF (aakडे badalal tar)")

    saved = (v7.BODY_THRESHOLD, v7.CLOSE_LOW_THRESHOLD,
             v7.CLOSE_HIGH_THRESHOLD, v7.MOMENTUM_MULTIPLIER)

    counts = {}

    try:

        for name, patch in VARIANTS:

            v7.BODY_THRESHOLD, v7.CLOSE_LOW_THRESHOLD, \
                v7.CLOSE_HIGH_THRESHOLD, v7.MOMENTUM_MULTIPLIER = saved

            for key, value in patch.items():
                setattr(v7, key, value)

            counts[name] = len(analyse(base))

    finally:

        v7.BODY_THRESHOLD, v7.CLOSE_LOW_THRESHOLD, \
            v7.CLOSE_HIGH_THRESHOLD, v7.MOMENTUM_MULTIPLIER = saved

    check("आजचे नियम = 1 setup", counts[VARIANTS[0][0]] == 1, f"{counts[VARIANTS[0][0]]}")
    check("body 60% केल्यावर pn aahe (fixture body 50%)",
          counts["body 50% → 60%"] == 0, f"{counts['body 50% → 60%']}")
    check("खांब 5x केल्यावर pn aahe (पट motha aahe)",
          counts["खांब 3x → 5x"] == 1, f"{counts['खांब 3x → 5x']}")
    check("aakडे parat जसेच (restore)",
          (v7.BODY_THRESHOLD, v7.CLOSE_LOW_THRESHOLD, v7.CLOSE_HIGH_THRESHOLD,
           v7.MOMENTUM_MULTIPLIER) == saved)

    # ---- [6] CSV ----
    print()
    print("[6] CSV")

    row = {
        "symbol": "TESTUSDT", "timeframe": "1h", "scanner": "Scanner 1",
        "direction": "Bearish Reversal", "final_ist": ist_str(t0), "day": ist_date(t0),
        "body1_pct": 50.0, "close_final_pct": 25.0, "stick_ratio": 45.0,
        "level_old": 98.0, "level_new": 98.5, "hit_old": 1, "hit_new": 1,
        "mins_old": 30, "mins_new": 15, "alert_price": 98.0,
        "chg_1h_pct": 1.0, "chg_4h_pct": 1.0, "chg_24h_pct": -1.0,
        "max_up_24h_pct": 2.0, "max_down_24h_pct": -1.5,
    }

    tmp = "/tmp/v7_30din_selftest.csv"

    write_csv(tmp, [row])

    with open(tmp) as f:
        data = list(csv.DictReader(f))

    check("CSV madhe 1 row", len(data) == 1, f"{len(data)}")
    check("CSV madhe level_old / hit_old aahet",
          all(k in data[0] for k in ("level_old", "hit_old", "mins_old")))

    import os
    os.remove(tmp)

    # ---- [7] ahwal ----
    print()
    print("[7] AHWAL (report)")

    rep = build_report([row], {VARIANTS[0][0]: 1}, 1, 1, 0, 30, t0 + 30 * DAY_MS)

    for bit in ("[1] EKUN NIKAL", "[2] KONTA SCANNER", "[3] KONTA TIMEFRAME",
                "[4] KONTA DIVAS", "[5] NANTAR KAY ZHALA",
                "[6] KAY BADALAL TAR KITI SETUPS"):
        check(f"report madhe '{bit}'", bit in rep)

    rep0 = build_report([], {}, 1, 1, 0, 30, t0 + 30 * DAY_MS)
    check("setup nसताना pn report yeto", "[1] EKUN NIKAL" in rep0)

    print()
    print("=" * 70)
    print(f" निकाल : {PASS} pass, {FAIL} fail")
    print("=" * 70)

    return FAIL == 0


# ============================================================
# MAIN
# ============================================================

def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("--days", type=int, default=30)
    parser.add_argument("--csv", action="store_true")
    parser.add_argument("--csv-name", default=CSV_FILE)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--symbols", default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--selftest", action="store_true")

    args = parser.parse_args()

    if args.selftest:
        sys.exit(0 if self_test() else 1)

    v7.refresh_time_offset()

    now_ms = v7.now_ms()

    if args.symbol:
        symbols = [args.symbol.strip().upper()]
    else:
        symbols = fetch_symbols(limit=args.limit, only=args.symbols)

    print("=" * 70)
    print(f" v7 STICK — MAGIL {args.days} DIVAS")
    print(f" pairs : {len(symbols)}  |  workers {args.workers}")
    print("=" * 70, flush=True)

    rows = []
    variant_totals = Counter()
    scanned = 0
    errors = 0

    with ThreadPoolExecutor(max_workers=args.workers) as executor:

        futures = {
            executor.submit(symbol_worker, s, args.days, now_ms): s
            for s in symbols
        }

        done = 0

        for future in as_completed(futures):

            symbol = futures[future]
            done += 1

            try:

                _sym, srows, vcounts, nbase = future.result()

                scanned += 1
                rows.extend(srows)

                for name, n in vcounts.items():
                    variant_totals[name] += n

                if done % 25 == 0 or done == len(symbols):
                    print(f"   {done}/{len(symbols)} pairs ... setups {len(rows):,}",
                          flush=True)

            except Exception as e:

                errors += 1
                print(f"   ERROR {symbol}: {e}", flush=True)

    report = build_report(rows, variant_totals, len(symbols), scanned, errors,
                          args.days, now_ms,
                          args.csv_name if args.csv else None)

    print(report)

    if args.csv:
        write_csv(args.csv_name, rows)
        print(f"CSV : {args.csv_name}  ({len(rows)} rows)")


if __name__ == "__main__":
    main()

